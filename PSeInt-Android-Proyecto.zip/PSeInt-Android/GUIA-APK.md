# PSeInt Web → APK (sin Android Studio, desde tu celular)

**Qué es esto:** un proyecto Android listo. Tu web va **dentro** del APK (funciona sin internet) y el APK lo compila GitHub **gratis** en la nube. Tú solo subes el ZIP y descargas el APK.

**Compatibilidad:** Android 5.0 hasta Android 14+ (y más nuevos), celulares y tablets, gama baja/media/alta. Un solo APK sirve para todos.

## Qué hace la app
- Abre tu PSeInt Web completa, a pantalla completa, sin barra de navegador.
- **Abrir archivos** (.psc / .txt) con el explorador del celular.
- **Guardar / exportar** (.psc, .txt, .html, .svg, .png): te abre el selector "Guardar como" de Android, eliges carpeta y nombre.
- **Imprimir** usa el menú de impresión de Android (también sirve para "Guardar como PDF").
- Botón **Atrás**: cierra menús/paneles/ventanas; si no hay nada abierto, pulsa dos veces para salir.
- Teclado no tapa el editor, rotación sin recargar, barra de estado con el color del tema (claro/oscuro).
- Si Android mata el visor por poca RAM (gama baja), la app se reinicia sola en vez de cerrarse.

## Pasos (todo desde Chrome en tu Android)
1. Entra a **github.com** y crea una cuenta gratis. Abre el menú de Chrome (⋮) y activa **"Sitio de escritorio"**.
2. Toca **+ → New repository**. Nombre: `pseint-apk`. Marca **Add a README file**. Toca **Create repository**.
3. **Add file → Upload files** → elige **PSeInt-Android-Proyecto.zip** (el que te pasé, sin descomprimir) → **Commit changes**.
4. **Add file → Create new file**. En el nombre escribe exactamente: `.github/workflows/build.yml` (al escribir las `/` se crean las carpetas). Pega dentro el contenido de **build.yml** (te lo paso como archivo; abre con MT Manager, copia todo) → **Commit changes**.
5. Ve a la pestaña **Actions**. Verás "Build APK" corriendo (círculo amarillo). Tarda **4–8 minutos**. Si termina en ✅ verde, listo. (Si no arrancó solo: Actions → Build APK → **Run workflow**.)
6. Entra a esa ejecución, baja hasta **Artifacts** y toca **PSeInt-Web-APK**. Se descarga un ZIP: ábrelo/extráelo con **MT Manager** y saca **PSeInt-Web.apk**.
7. Instala el APK. Android te pedirá permitir **"Instalar apps desconocidas"** para MT Manager (o Chrome): actívalo.

## Si algo falla
- ❌ rojo en Actions: abre la ejecución → el paso rojo → copia las últimas líneas del error (o captura) y pásamelas; lo corrijo.
- En Android 5/6 viejitos: actualiza **"Android System WebView"** en Play Store, la web lo necesita moderno.
- Para **actualizar** la app en el futuro, instala encima: siempre se firma con la misma llave (`app/release.jks`, clave `tauro2026`). **Guarda ese archivo**; si lo pierdes, tendrías que desinstalar para instalar una versión nueva.
- Cambiar la web: reemplaza los archivos en `app/src/main/assets/www/` (misma estructura que `htdocs`) y sube `versionCode` en `app/build.gradle`.

## Datos técnicos
- Paquete: `com.eltauromods.pseint` · minSdk 21 (Android 5.0) · targetSdk 34 · sin librerías externas.
- Los archivos se sirven desde el APK en `https://appassets.androidplatform.net/` (contexto seguro: portapapeles y almacenamiento local funcionan). El service worker se desactiva dentro de la app porque ya está todo empaquetado.

## Contenido de build.yml
```yaml
name: Build APK

on:
  workflow_dispatch:
  push:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Descomprimir proyecto (si se subio como zip)
        run: |
          for z in *.zip; do if [ -f "$z" ]; then unzip -q -o "$z" -d proyecto_src; fi; done
          S=$(find . -name settings.gradle -not -path './.git/*' | head -1)
          echo "PROJ_DIR=$(dirname "$S")" >> "$GITHUB_ENV"

      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - uses: android-actions/setup-android@v3

      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.7'

      - name: Compilar APK
        working-directory: ${{ env.PROJ_DIR }}
        run: gradle assembleRelease --no-daemon --stacktrace

      - name: Renombrar APK
        run: |
          mkdir -p salida
          cp "$(find . -path '*build/outputs/apk/release/*.apk' | head -1)" salida/PSeInt-Web.apk

      - uses: actions/upload-artifact@v4
        with:
          name: PSeInt-Web-APK
          path: salida/PSeInt-Web.apk
```
