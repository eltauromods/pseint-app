package com.eltauromods.pseint;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * PSeInt Web para Android (El Tauro Mods).
 * Envuelve la web original (carpeta assets/www) en un WebView. Todo funciona sin conexion:
 * los archivos se sirven desde el propio APK bajo https://appassets.androidplatform.net/
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/index.html";
    private static final int REQ_OPEN = 1001;
    private static final int REQ_SAVE = 1002;

    /** Script que se inyecta en la pagina: descargas (blob), imprimir y color de la barra de estado. */
    private static final String INJECT =
        "(function(){"
        + "if(window.__tauroApk)return;window.__tauroApk=1;"
        + "function b64(bl,cb){var r=new FileReader();r.onloadend=function(){var s=String(r.result||'');var i=s.indexOf(',');cb(i>=0?s.substring(i+1):'');};r.readAsDataURL(bl);}"
        + "var oc=HTMLAnchorElement.prototype.click;"
        + "HTMLAnchorElement.prototype.click=function(){"
        +   "var a=this,h=a.href||'';"
        +   "if(a.hasAttribute('download')&&/^(blob:|data:)/.test(h)){"
        +     "var name=a.getAttribute('download')||'archivo';"
        +     "var x=new XMLHttpRequest();x.open('GET',h);x.responseType='blob';"
        +     "x.onload=function(){var bl=x.response;b64(bl,function(d){try{AndroidApp.saveFile(name,bl.type||'',d);}catch(e){}});};"
        +     "x.send();return;"
        +   "}"
        +   "return oc.apply(this,arguments);"
        + "};"
        + "window.print=function(){try{AndroidApp.print();}catch(e){}};"
        + "function tc(){var m=document.querySelector('meta[name=theme-color]');if(m){try{AndroidApp.themeColor(m.getAttribute('content')||'');}catch(e){}}return m;}"
        + "var m=tc();if(m&&window.MutationObserver){new MutationObserver(tc).observe(m,{attributes:true,attributeFilter:['content']});}"
        + "})();";

    /** Script de "atras": cierra paneles, menus y ventanas abiertas. Devuelve 1 si cerro algo. */
    private static final String BACK_JS =
        "(function(){"
        + "function op(id){var e=document.getElementById(id);return !!e&&!e.hidden;}"
        + "var s=document.getElementById('shade');"
        + "if(s&&s.style.display==='block'){s.click();return 1;}"
        + "var b=document.getElementById('bd');"
        + "if(b&&b.classList.contains('on')){b.click();return 1;}"
        + "if(op('flowWin')){var f=document.getElementById('flowClose');if(f){f.click();return 1;}}"
        + "if(op('conWin')){var c=document.getElementById('conClose');if(c){c.click();return 1;}}"
        + "return 0;})()";

    private WebView web;
    private ValueCallback<Uri[]> openCallback;
    private byte[] pendingSave;
    private long lastBack = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyBars("#ffffff");

        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(web, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Bridge(), "AndroidApp");
        web.setWebViewClient(new AppClient());
        web.setWebChromeClient(new AppChrome());
        web.loadUrl(START_URL);
    }

    // ---------------------------------------------------------------- WebViewClient

    private class AppClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            WebResourceResponse r = serve(request.getUrl());
            return r != null ? r : super.shouldInterceptRequest(view, request);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return handleNav(request.getUrl());
        }

        @SuppressWarnings("deprecation")
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handleNav(Uri.parse(url));
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            view.evaluateJavascript(INJECT, null);
        }

        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            // El sistema mato el proceso del WebView (poca RAM): reiniciamos la pantalla en vez de cerrar la app.
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    recreate();
                }
            });
            return true;
        }
    }

    private boolean handleNav(Uri u) {
        if (u == null) return true;
        String sch = u.getScheme();
        if (HOST.equals(u.getHost())) return false;
        if ("blob".equals(sch) || "data".equals(sch) || "about".equals(sch) || "javascript".equals(sch)) return false;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (Exception ignored) {
            // sin app para abrir el enlace
        }
        return true;
    }

    private WebResourceResponse serve(Uri u) {
        if (u == null || !HOST.equals(u.getHost())) return null;
        String p = u.getPath();
        if (p == null || p.length() == 0 || "/".equals(p)) p = "/index.html";
        p = p.substring(1);
        if (p.contains("..") || "sw.js".equals(p)) return notFound();
        try {
            InputStream in = getAssets().open("www/" + p);
            String mime = mimeFor(p);
            boolean text = mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json") || mime.contains("xml");
            WebResourceResponse r = new WebResourceResponse(mime, text ? "UTF-8" : null, in);
            Map<String, String> h = new HashMap<String, String>();
            h.put("Cache-Control", "no-cache");
            r.setResponseHeaders(h);
            return r;
        } catch (IOException e) {
            return notFound();
        }
    }

    private WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    private static String ext(String name) {
        int i = name.lastIndexOf('.');
        return i < 0 ? "" : name.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    private static String mimeFor(String path) {
        String e = ext(path);
        if (e.equals("html") || e.equals("htm")) return "text/html";
        if (e.equals("js")) return "text/javascript";
        if (e.equals("css")) return "text/css";
        if (e.equals("png")) return "image/png";
        if (e.equals("jpg") || e.equals("jpeg")) return "image/jpeg";
        if (e.equals("svg")) return "image/svg+xml";
        if (e.equals("ico")) return "image/x-icon";
        if (e.equals("webp")) return "image/webp";
        if (e.equals("json") || e.equals("webmanifest")) return "application/json";
        if (e.equals("txt")) return "text/plain";
        if (e.equals("woff2")) return "font/woff2";
        if (e.equals("woff")) return "font/woff";
        return "application/octet-stream";
    }

    // ---------------------------------------------------------------- WebChromeClient (abrir archivos)

    private class AppChrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (openCallback != null) {
                openCallback.onReceiveValue(null);
                openCallback = null;
            }
            openCallback = callback;
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            if (params != null && params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            }
            try {
                startActivityForResult(Intent.createChooser(i, "Abrir archivo"), REQ_OPEN);
            } catch (Exception e) {
                openCallback = null;
                callback.onReceiveValue(null);
                toast("No hay un explorador de archivos disponible");
            }
            return true;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_OPEN) {
            if (openCallback != null) {
                Uri[] r = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                openCallback.onReceiveValue(r);
                openCallback = null;
            }
            return;
        }
        if (requestCode == REQ_SAVE) {
            byte[] b = pendingSave;
            pendingSave = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null && b != null) {
                writeTo(data.getData(), b);
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    // ---------------------------------------------------------------- Puente JS -> Android

    private class Bridge {
        @JavascriptInterface
        public void saveFile(final String name, final String mime, final String base64) {
            try {
                final byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        startSave(name, mime, bytes);
                    }
                });
            } catch (Exception e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        toast("No se pudo guardar el archivo");
                    }
                });
            }
        }

        @JavascriptInterface
        public void print() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    doPrint();
                }
            });
        }

        @JavascriptInterface
        public void themeColor(final String color) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    applyBars(color);
                }
            });
        }
    }

    private void startSave(String name, String mime, byte[] bytes) {
        pendingSave = bytes;
        String n = (name == null || name.length() == 0) ? "archivo.txt" : name;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(saveMime(n, mime));
        i.putExtra(Intent.EXTRA_TITLE, n);
        try {
            startActivityForResult(i, REQ_SAVE);
        } catch (Exception e) {
            pendingSave = null;
            toast("No hay un explorador de archivos disponible");
        }
    }

    private static String saveMime(String name, String mime) {
        String e = ext(name);
        if (e.equals("psc") || e.equals("pseint")) return "application/octet-stream";
        if (e.equals("txt")) return "text/plain";
        if (e.equals("html") || e.equals("htm")) return "text/html";
        if (e.equals("svg")) return "image/svg+xml";
        if (e.equals("png")) return "image/png";
        if (mime != null && mime.length() > 0 && mime.indexOf('/') > 0) {
            int semi = mime.indexOf(';');
            return semi > 0 ? mime.substring(0, semi) : mime;
        }
        return "application/octet-stream";
    }

    private void writeTo(Uri uri, byte[] bytes) {
        OutputStream os = null;
        try {
            os = getContentResolver().openOutputStream(uri, "w");
            if (os == null) throw new IOException("sin salida");
            os.write(bytes);
            os.flush();
            toast("Archivo guardado");
        } catch (Exception e) {
            toast("No se pudo guardar el archivo");
        } finally {
            if (os != null) {
                try {
                    os.close();
                } catch (IOException ignored) {
                    // nada
                }
            }
        }
    }

    private void doPrint() {
        try {
            PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
            pm.print("PSeInt Web", web.createPrintDocumentAdapter("PSeInt Web"), new PrintAttributes.Builder().build());
        } catch (Exception e) {
            toast("No se pudo abrir la impresion");
        }
    }

    // ---------------------------------------------------------------- Barras del sistema

    private void applyBars(String c) {
        try {
            int col = Color.parseColor(c.trim());
            boolean light = (0.299 * Color.red(col) + 0.587 * Color.green(col) + 0.114 * Color.blue(col)) > 160;
            int grey = 0xFF757575;
            Window w = getWindow();
            w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            w.setStatusBarColor((light && Build.VERSION.SDK_INT < 23) ? grey : col);
            w.setNavigationBarColor((light && Build.VERSION.SDK_INT < 26) ? grey : col);
            if (Build.VERSION.SDK_INT >= 23) {
                View d = w.getDecorView();
                int f = d.getSystemUiVisibility();
                if (light) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                else f &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (Build.VERSION.SDK_INT >= 26) {
                    if (light) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    else f &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                }
                d.setSystemUiVisibility(f);
            }
        } catch (Exception ignored) {
            // color invalido: se deja el actual
        }
    }

    // ---------------------------------------------------------------- Ciclo de vida y boton atras

    @Override
    public void onBackPressed() {
        if (web == null) {
            super.onBackPressed();
            return;
        }
        web.evaluateJavascript(BACK_JS, new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if ("1".equals(value)) return;
                long now = System.currentTimeMillis();
                if (now - lastBack < 2000) {
                    finish();
                } else {
                    lastBack = now;
                    toast("Presiona atras otra vez para salir");
                }
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            ViewGroup parent = (ViewGroup) web.getParent();
            if (parent != null) parent.removeView(web);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
