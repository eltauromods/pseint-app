/*! PSeInt Web - ejemplos incluidos (menú Ayuda > Ejemplos) */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.EXAMPLES = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  return [
    { name: 'Hola mundo', level: 'Básico', inputs: [], code:
'Algoritmo HolaMundo\n  Escribir "¡Hola mundo!"\nFinAlgoritmo\n' },

    { name: 'Suma de dos números', level: 'Básico', inputs: ['8', '4'], code:
'Algoritmo SumaDosNumeros\n  Definir a, b, suma Como Real\n  Escribir "Ingrese el primer número:"\n  Leer a\n  Escribir "Ingrese el segundo número:"\n  Leer b\n  suma <- a + b\n  Escribir "La suma es: ", suma\nFinAlgoritmo\n' },

    { name: 'Par o impar', level: 'Básico', inputs: ['7'], code:
'Algoritmo ParOImpar\n  Definir n Como Entero\n  Escribir "Ingrese un número entero:"\n  Leer n\n  Si n MOD 2 = 0 Entonces\n    Escribir n, " es par"\n  SiNo\n    Escribir n, " es impar"\n  FinSi\nFinAlgoritmo\n' },

    { name: 'Tabla de multiplicar', level: 'Básico', inputs: ['7'], code:
'Algoritmo TablaMultiplicar\n  Definir n, i Como Entero\n  Escribir "¿Qué tabla desea ver?"\n  Leer n\n  Para i <- 1 Hasta 10 Con Paso 1 Hacer\n    Escribir n, " x ", i, " = ", n * i\n  FinPara\nFinAlgoritmo\n' },

    { name: 'Factorial (función)', level: 'Funciones', inputs: ['6'], code:
'Funcion res <- Factorial(n)\n  Definir i Como Entero\n  res <- 1\n  Para i <- 2 Hasta n Hacer\n    res <- res * i\n  FinPara\nFinFuncion\n\nAlgoritmo PruebaFactorial\n  Definir n Como Entero\n  Escribir "Ingrese un número:"\n  Leer n\n  Escribir "El factorial de ", n, " es ", Factorial(n)\nFinAlgoritmo\n' },

    { name: 'Serie de Fibonacci', level: 'Ciclos', inputs: ['12'], code:
'Algoritmo Fibonacci\n  Definir n, a, b, c, i Como Entero\n  Escribir "¿Cuántos términos?"\n  Leer n\n  a <- 0\n  b <- 1\n  Para i <- 1 Hasta n Hacer\n    Escribir Sin Saltar a, " "\n    c <- a + b\n    a <- b\n    b <- c\n  FinPara\n  Escribir ""\nFinAlgoritmo\n' },

    { name: 'Promedio con arreglo', level: 'Arreglos', inputs: ['4', '14', '17', '12', '19'], code:
'Algoritmo PromedioNotas\n  Definir n, i Como Entero\n  Definir suma, prom Como Real\n  Escribir "¿Cuántas notas?"\n  Leer n\n  Dimension notas[n]\n  suma <- 0\n  Para i <- 1 Hasta n Hacer\n    Escribir "Nota ", i, ":"\n    Leer notas[i]\n    suma <- suma + notas[i]\n  FinPara\n  prom <- suma / n\n  Escribir "Promedio: ", prom\n  Si prom >= 13 Entonces\n    Escribir "Aprobado"\n  SiNo\n    Escribir "Desaprobado"\n  FinSi\nFinAlgoritmo\n' },

    { name: 'Ordenamiento burbuja', level: 'Arreglos', inputs: [], code:
'Algoritmo Burbuja\n  Definir i, j, aux Como Entero\n  Dimension v[8]\n  v[1] <- 64\n  v[2] <- 25\n  v[3] <- 12\n  v[4] <- 90\n  v[5] <- 3\n  v[6] <- 47\n  v[7] <- 18\n  v[8] <- 71\n  Para i <- 1 Hasta 7 Hacer\n    Para j <- 1 Hasta 8 - i Hacer\n      Si v[j] > v[j + 1] Entonces\n        aux <- v[j]\n        v[j] <- v[j + 1]\n        v[j + 1] <- aux\n      FinSi\n    FinPara\n  FinPara\n  Escribir "Arreglo ordenado:"\n  Para i <- 1 Hasta 8 Hacer\n    Escribir Sin Saltar v[i], " "\n  FinPara\n  Escribir ""\nFinAlgoritmo\n' },

    { name: 'Matriz 3x3', level: 'Arreglos', inputs: [], code:
'Algoritmo Matriz\n  Definir i, j Como Entero\n  Dimension m[3, 3]\n  Para i <- 1 Hasta 3 Hacer\n    Para j <- 1 Hasta 3 Hacer\n      m[i, j] <- i * j\n    FinPara\n  FinPara\n  Para i <- 1 Hasta 3 Hacer\n    Para j <- 1 Hasta 3 Hacer\n      Escribir Sin Saltar m[i, j], "\\t"\n    FinPara\n    Escribir ""\n  FinPara\nFinAlgoritmo\n' },

    { name: 'Número primo', level: 'Funciones', inputs: ['29'], code:
'Funcion r <- EsPrimo(n)\n  Definir d Como Entero\n  r <- n > 1\n  d <- 2\n  Mientras r Y d * d <= n Hacer\n    Si n MOD d = 0 Entonces\n      r <- Falso\n    FinSi\n    d <- d + 1\n  FinMientras\nFinFuncion\n\nAlgoritmo Primos\n  Definir n Como Entero\n  Escribir "Ingrese un número:"\n  Leer n\n  Si EsPrimo(n) Entonces\n    Escribir n, " es primo"\n  SiNo\n    Escribir n, " no es primo"\n  FinSi\nFinAlgoritmo\n' },

    { name: 'Adivina el número', level: 'Ciclos', inputs: ['50', '25', '37', '1000'], code:
'Algoritmo Adivina\n  Definir secreto, intento, cuenta Como Entero\n  secreto <- aleatorio(1, 100)\n  cuenta <- 0\n  Escribir "Adivine el número entre 1 y 100"\n  Repetir\n    Leer intento\n    cuenta <- cuenta + 1\n    Si intento < secreto Entonces\n      Escribir "Muy bajo"\n    SiNo\n      Si intento > secreto Entonces\n        Escribir "Muy alto"\n      FinSi\n    FinSi\n  Hasta Que intento = secreto O cuenta >= 4\n  Escribir "Fin del juego tras ", cuenta, " intentos. El número era ", secreto\nFinAlgoritmo\n' },

    { name: 'Menú con Según', level: 'Selección', inputs: ['2', '10', '5'], code:
'Algoritmo MenuCalculadora\n  Definir op Como Entero\n  Definir a, b Como Real\n  Escribir "1) Sumar   2) Restar   3) Multiplicar   4) Dividir"\n  Leer op\n  Escribir "Primer número:"\n  Leer a\n  Escribir "Segundo número:"\n  Leer b\n  Segun op Hacer\n    1: Escribir "Resultado: ", a + b\n    2: Escribir "Resultado: ", a - b\n    3: Escribir "Resultado: ", a * b\n    4:\n      Si b = 0 Entonces\n        Escribir "No se puede dividir entre cero"\n      SiNo\n        Escribir "Resultado: ", a / b\n      FinSi\n    De Otro Modo:\n      Escribir "Opción no válida"\n  FinSegun\nFinAlgoritmo\n' },

    { name: 'Texto: invertir palabra', level: 'Cadenas', inputs: ['pseint'], code:
'Algoritmo InvertirTexto\n  Definir t, inv Como Caracter\n  Definir i Como Entero\n  Escribir "Escriba una palabra:"\n  Leer t\n  inv <- ""\n  Para i <- Longitud(t) - 1 Hasta 0 Con Paso -1 Hacer\n    inv <- inv + Subcadena(t, i, i)\n  FinPara\n  Escribir "Al revés: ", Mayusculas(inv)\nFinAlgoritmo\n' },

    { name: 'Paso por referencia', level: 'Funciones', inputs: [], code:
'SubProceso Intercambiar(a Por Referencia, b Por Referencia)\n  Definir t Como Entero\n  t <- a\n  a <- b\n  b <- t\nFinSubProceso\n\nAlgoritmo Intercambio\n  Definir p, q Como Entero\n  p <- 10\n  q <- 99\n  Escribir "Antes:   p=", p, "  q=", q\n  Intercambiar(p, q)\n  Escribir "Después: p=", p, "  q=", q\nFinAlgoritmo\n' }
  ];
});
