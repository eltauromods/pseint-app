/*!
 * PSeInt Web - editor de código (textarea + capa de resaltado, sin dependencias).
 * Escrito en ES5 para máxima compatibilidad con navegadores móviles antiguos.
 */
(function (root) {
  'use strict';

  function strip(s) { try { return s.normalize('NFD').replace(/[̀-ͯ]/g, ''); } catch (e) { return s; } }
  function H(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

  var KW = {}, TY = {}, BO = {}, OPW = {};
  ('ALGORITMO FINALGORITMO PROCESO FINPROCESO SUBPROCESO FINSUBPROCESO FUNCION FINFUNCION DEFINIR COMO DIMENSION LEER ESCRIBIR IMPRIMIR MOSTRAR SIN SALTAR BAJAR ' +
    'SI ENTONCES SINO FINSI SEGUN HACER DE OTRO MODO FINSEGUN MIENTRAS FINMIENTRAS REPETIR HASTA QUE PARA CON PASO FINPARA ESPERAR TECLA SEGUNDOS SEGUNDO MILISEGUNDOS ' +
    'MILISEGUNDO LIMPIAR BORRAR PANTALLA POR VALOR REFERENCIA RETORNAR').split(' ').forEach(function (k) { KW[k] = 1; });
  'ENTERO REAL NUMERO NUMERICO LOGICO CARACTER TEXTO CADENA'.split(' ').forEach(function (k) { TY[k] = 1; });
  BO.VERDADERO = 1; BO.FALSO = 1; BO.PI = 1;
  OPW.Y = 1; OPW.O = 1; OPW.NO = 1; OPW.MOD = 1;
  var FN = {};
  'ABS TRUNC REDON RAIZ RC SEN COS TAN ASEN ACOS ATAN LN EXP AZAR ALEATORIO LONGITUD SUBCADENA MAYUSCULAS MINUSCULAS CONCATENAR CONVERTIRANUMERO CONVERTIRATEXTO'.split(' ').forEach(function (k) { FN[k] = 1; });

  var NAMEPRE = /^\s*(?:algoritmo|proceso)\s+$/i;
  var TOKEN = /(\/\/[^\n]*|\/\*[\s\S]*?(?:\*\/|$))|("(?:[^"\n\\]|\\.)*"?|'(?:[^'\n\\]|\\.)*'?)|(\d+(?:\.\d+)?|\.\d+)|([A-Za-zÁÉÍÓÚÜÑáéíóúüñ_][A-Za-zÁÉÍÓÚÜÑáéíóúüñ_0-9]*)|(<-|←|<=|>=|<>|[=<>+\-*\/^%&|~!])/g;

  function highlight(text) {
    var out = '', last = 0, m;
    TOKEN.lastIndex = 0;
    while ((m = TOKEN.exec(text)) !== null) {
      if (m.index > last) out += H(text.slice(last, m.index));
      var s = m[0], cls = '';
      if (m[1]) cls = 'c';
      else if (m[2]) cls = 's';
      else if (m[3]) cls = 'n';
      else if (m[4]) {
        var u = strip(s.toUpperCase());
        if (KW[u]) cls = 'k';
        else if (TY[u]) cls = 't';
        else if (BO[u]) cls = 'b';
        else if (OPW[u]) cls = 'o';
        else if (FN[u]) cls = 'f';
        if (!cls) { var ls = text.lastIndexOf('\n', m.index - 1) + 1; if (ls <= m.index && NAMEPRE.test(text.slice(ls, m.index))) cls = 'nm'; }
      } else if (m[5]) cls = 'p';
      out += cls ? '<span class="' + cls + '">' + H(s) + '</span>' : H(s);
      last = m.index + s.length;
      if (s.length === 0) TOKEN.lastIndex++;
    }
    if (last < text.length) out += H(text.slice(last));
    return out + '\n';
  }

  /* -------------------------------------------------------------- estructura / indentado */
  var OPENERS = { ALGORITMO: 1, PROCESO: 1, SUBPROCESO: 1, FUNCION: 1, SI: 1, MIENTRAS: 1, REPETIR: 1, PARA: 1, SEGUN: 1 };
  var CLOSE_OF = { ALGORITMO: 'FinAlgoritmo', PROCESO: 'FinProceso', SUBPROCESO: 'FinSubProceso', FUNCION: 'FinFuncion', SI: 'FinSi', MIENTRAS: 'FinMientras', REPETIR: 'Hasta Que ', PARA: 'FinPara', SEGUN: 'FinSegun' };
  var CLOSERS = { FINALGORITMO: 1, FINPROCESO: 1, FINSUBPROCESO: 1, FINFUNCION: 1, FINSI: 1, FINMIENTRAS: 1, FINPARA: 1, FINSEGUN: 1, HASTA: 1 };

  function words(line) {
    var l = strip(line.replace(/\/\/.*$/, '')).trim().toUpperCase();
    var m = /^([A-Z_0-9]+)(?:\s+([A-Z_0-9]+))?/.exec(l);
    return m ? [m[1], m[2] || ''] : ['', ''];
  }
  function isCaseLabel(line) {
    var q = null, i, c;
    for (i = 0; i < line.length; i++) {
      c = line.charAt(i);
      if (q) { if (c === q) q = null; continue; }
      if (c === '"' || c === "'") { q = c; continue; }
      if (c === '/' && line.charAt(i + 1) === '/') return false;
      if (c === ':' && line.charAt(i + 1) !== '=') {
        var pre = line.slice(0, i).trim();
        if (!pre) return false;
        var w = words(pre)[0];
        if (/^DE\s+OTRO\s+MODO$/i.test(strip(pre))) return true;
        return !(KW[w] && w !== 'DE') && pre.indexOf('<-') < 0;
      }
    }
    return false;
  }

  function reindent(text, unit) {
    var lines = text.replace(/\r\n?/g, '\n').split('\n'), stack = [], out = [], i, ind = function (n) { var s = ''; while (n-- > 0) s += unit; return s; };
    var inBlock = false;
    for (i = 0; i < lines.length; i++) {
      var raw = lines[i], line = raw.trim();
      if (inBlock) { out.push(raw.replace(/\s+$/, '')); if (raw.indexOf('*/') >= 0) inBlock = false; continue; }
      if (!line) { out.push(''); continue; }
      if (line.indexOf('/*') === 0 && line.indexOf('*/') < 0) { inBlock = true; out.push(ind(stack.length ? stack[stack.length - 1].inner : 0) + line); continue; }
      var w = words(line), f = w[0], top = stack[stack.length - 1], lvl;
      if (top && top.t === 'SEGUN') {
        if (f === 'FINSEGUN') { stack.pop(); lvl = top.base; }
        else if (isCaseLabel(line)) lvl = top.base + 1;
        else lvl = top.base + 2;
      } else if (CLOSERS[f] || (f === 'MIENTRAS' && w[1] === 'QUE' && top && top.t === 'REPETIR')) {
        if (top) { stack.pop(); lvl = top.base; } else lvl = 0;
      } else if (f === 'SINO' && top && top.t === 'SI') lvl = top.base;
      else lvl = top ? top.inner : 0;
      out.push(ind(lvl) + line);
      if (OPENERS[f] && !(f === 'MIENTRAS' && w[1] === 'QUE' && top && top.t === 'REPETIR')) {
        stack.push({ t: f, base: lvl, inner: lvl + 1 });
      }
    }
    return out.join('\n');
  }

  function countBalance(text, kind) {
    var closers = { ALGORITMO: ['FINALGORITMO'], PROCESO: ['FINPROCESO'], SUBPROCESO: ['FINSUBPROCESO'], FUNCION: ['FINFUNCION'], SI: ['FINSI'], MIENTRAS: ['FINMIENTRAS', 'MIENTRAS QUE'], REPETIR: ['HASTA'], PARA: ['FINPARA'], SEGUN: ['FINSEGUN'] }[kind];
    var lines = text.split('\n'), o = 0, c = 0, i, stack = [];
    for (i = 0; i < lines.length; i++) {
      var w = words(lines[i]), f = w[0];
      if (!f) continue;
      if (f === kind) {
        if (kind === 'MIENTRAS' && w[1] === 'QUE' && stack.length) { c++; continue; }
        o++;
      }
      else if (closers.indexOf(f) >= 0) c++;
      else if (f === 'MIENTRAS' && w[1] === 'QUE' && closers.indexOf('MIENTRAS QUE') >= 0) c++;
    }
    return o - c;
  }


  /* -------------------------------------------------------------- autocompletado (palabras clave y ayuda flotante) */
  /* flags: s = sin espacio final, a = en cualquier parte de la línea (si no, solo al inicio), d = solo en líneas Definir, f = función */
  var LST = [
    ['Algoritmo', '{nombre del algoritmo}', ''], ['FinAlgoritmo', '', 's'], ['Proceso', '{nombre del proceso}', ''], ['FinProceso', '', 's'],
    ['SubProceso', '{variable de retorno} <- {nombre}({argumentos})', ''], ['FinSubProceso', '', 's'], ['Funcion', '{variable de retorno} <- {nombre}({argumentos})', ''], ['FinFuncion', '', 's'],
    ['Definir', '{una o mas variables, separadas por comas}', ''],
    ['Como Caracter', '', 'ds'], ['Como Entero', '', 'ds'], ['Como Logico', '', 'ds'], ['Como Real', '', 'ds'],
    ['Dimension', '{nombre}[{cantidad}]  o  {nombre}[{filas},{columnas}]', ''],
    ['Leer', '{una o mas variables, separadas por comas}', ''],
    ['Escribir', '{una o mas expresiones, separadas por comas}', ''], ['Escribir Sin Saltar', '{una o mas expresiones, separadas por comas}', ''],
    ['Si', '{condicion} Entonces', ''], ['Entonces', '', 'sa'], ['Sino', '', 's'], ['FinSi', '', 's'],
    ['Segun', '{variable numerica} Hacer', ''], ['De Otro Modo:', '', 's'], ['FinSegun', '', 's'],
    ['Mientras', '{condicion} Hacer', ''], ['Mientras Que', '{condicion}', ''], ['Hacer', '', 'sa'], ['FinMientras', '', 's'],
    ['Repetir', '', 's'], ['Hasta Que', '{condicion}', ''], ['Hasta', '{valor final}', 'a'],
    ['Para', '{variable} <- {valor inicial} Hasta {valor final} Con Paso {paso} Hacer', ''], ['Con Paso', '{paso}', 'a'], ['FinPara', '', 's'],
    ['Esperar', '{tiempo} Segundos  o  {tiempo} Milisegundos', ''], ['Esperar Tecla', '', 's'],
    ['Limpiar Pantalla', '', 's'], ['Borrar Pantalla', '', 's'], ['Retornar', '{valor}', ''],
    ['Verdadero', '', 'sa'], ['Falso', '', 'sa'],
    ['abs', 'abs({valor})', 'af'], ['trunc', 'trunc({valor})', 'af'], ['redon', 'redon({valor})', 'af'], ['raiz', 'raiz({valor})', 'af'],
    ['sen', 'sen({angulo en radianes})', 'af'], ['cos', 'cos({angulo en radianes})', 'af'], ['tan', 'tan({angulo en radianes})', 'af'],
    ['asen', 'asen({valor})', 'af'], ['acos', 'acos({valor})', 'af'], ['atan', 'atan({valor})', 'af'], ['ln', 'ln({valor})', 'af'], ['exp', 'exp({valor})', 'af'],
    ['azar', 'azar({valor maximo})', 'af'], ['aleatorio', 'aleatorio({minimo}, {maximo})', 'af'],
    ['longitud', 'longitud({cadena})', 'af'], ['subcadena', 'subcadena({cadena}, {desde}, {hasta})', 'af'], ['mayusculas', 'mayusculas({cadena})', 'af'], ['minusculas', 'minusculas({cadena})', 'af'],
    ['concatenar', 'concatenar({cadena1}, {cadena2})', 'af'], ['convertirANumero', 'convertirANumero({cadena})', 'af'], ['convertirATexto', 'convertirATexto({numero})', 'af']
  ];
  var ACL = [], HINTS = [], FNHINT = {};
  (function () {
    LST.forEach(function (r) {
      var it = { l: r[0], k: strip(r[0]).toLowerCase(), h: r[1], s: r[2].indexOf('s') >= 0, a: r[2].indexOf('a') >= 0, d: r[2].indexOf('d') >= 0, f: r[2].indexOf('f') >= 0 };
      if (it.l.charAt(it.l.length - 1) === ':') it.k = it.k.slice(0, -1);
      ACL.push(it);
      if (it.f) FNHINT[it.k] = it.h;
      else if (it.h) {
        it.re = new RegExp((it.a ? '(?:^|\\s)' : '^\\s*') + it.k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/ /g, '\\s+') + '\\s+$');
        HINTS.push(it);
      }
    });
    ACL.sort(function (x, y) { return x.k < y.k ? -1 : x.k > y.k ? 1 : 0; });
    HINTS.sort(function (x, y) { return y.k.length - x.k.length; });
  })();

  /* -------------------------------------------------------------- editor */
  function create(opt) {
    var ta = opt.ta, hl = opt.hl, layer = opt.layer, gin = opt.gutterIn, gutter = opt.gutter, wrap = opt.wrap;
    var cb = opt.callbacks || {}, S = opt.settings;
    var cur = null, errLines = {}, runLine = 0, cursorMark = opt.cursorMark, marks = opt.marks;
    var LH = 24, charW = 9, raf = 0, lastLines = -1, PADT = 8, PADL = 10;
    var api = {};

    function measure() {
      var sp = document.createElement('span');
      sp.style.cssText = 'position:absolute;visibility:hidden;white-space:pre;font:inherit;left:-9999px';
      sp.textContent = new Array(101).join('M');
      wrap.appendChild(sp); charW = sp.getBoundingClientRect().width / 100 || 9; wrap.removeChild(sp);
    }
    function applySettings() {
      var fs = S.fontSize; LH = Math.round(fs * 1.5);
      wrap.style.setProperty('--fs', fs + 'px'); wrap.style.setProperty('--lh', LH + 'px');
      wrap.style.fontSize = fs + 'px'; wrap.style.lineHeight = LH + 'px'; gutter.style.fontSize = fs + 'px'; gutter.style.lineHeight = LH + 'px';
      gutter.style.display = S.lineNumbers ? '' : 'none';
      acEl.style.fontSize = tipEl.style.fontSize = Math.max(12, fs - 1) + 'px'; acEl.style.lineHeight = tipEl.style.lineHeight = '1.45';
      measure(); lastLines = -1; refresh(); renderMarks();
    }
    function lineCount() { var m = ta.value.match(/\n/g); return (m ? m.length : 0) + 1; }
    var vFirst = 0, vLast = 0, virt = false, VMIN = 700;
    function paintHL(force) {
      var v = ta.value, n = lineCount();
      if (n < VMIN) { if (virt || force) { virt = false; hl.style.paddingTop = ''; hl.innerHTML = highlight(v); } else hl.innerHTML = highlight(v); return n; }
      // archivos grandes: solo se resaltan las líneas visibles (más un margen)
      var vis = Math.ceil((ta.clientHeight || 600) / LH), first = Math.max(0, Math.floor((ta.scrollTop - PADT) / LH) - 80), last = Math.min(n, first + vis + 200);
      if (!force && virt && first >= vFirst - 40 && last <= vLast + 40 && first >= vFirst && last <= vLast) return n;
      var lines = v.split('\n'); virt = true; vFirst = first; vLast = last;
      hl.style.paddingTop = (PADT + first * LH) + 'px';
      hl.innerHTML = highlight(lines.slice(first, last).join('\n'));
      return n;
    }
    function refresh() {
      var n = paintHL(true);
      if (n !== lastLines) {
        lastLines = n; var s = '', i;
        for (i = 1; i <= n; i++) s += i + '\n';
        gin.textContent = s;
        var digits = String(n).length; gutter.style.width = (Math.max(2, digits) * charW + 26) + 'px';
        renderGutterMarks();
      }
      syncScroll();
    }
    function schedule() { if (!raf) raf = (window.requestAnimationFrame || window.setTimeout)(function () { raf = 0; refresh(); }); }
    function syncScroll() {
      var st = ta.scrollTop, sl = ta.scrollLeft;
      if (virt) { var f = Math.floor((st - PADT) / LH), vis = Math.ceil((ta.clientHeight || 600) / LH); if (f < vFirst + 20 || f + vis > vLast - 20) paintHL(true); }
      layer.style.transform = 'translate3d(' + (-sl) + 'px,' + (-st) + 'px,0)';
      gin.style.transform = 'translate3d(0,' + (-st) + 'px,0)';
    }
    function renderGutterMarks() {
      // los números de línea con error se marcan con una capa aparte
      var gm = opt.gutterMarks; if (!gm) return;
      var h = '', k;
      for (k in errLines) if (errLines.hasOwnProperty(k)) h += '<i style="top:' + (PADT + (k - 1) * LH) + 'px;height:' + LH + 'px"></i>';
      gm.innerHTML = h; gm.style.transform = gin.style.transform;
    }
    function renderMarks() {
      var h = '', k;
      for (k in errLines) if (errLines.hasOwnProperty(k)) h += '<div class="mk err" style="top:' + (PADT + (k - 1) * LH) + 'px;height:' + LH + 'px"></div>';
      if (runLine) h += '<div class="mk run" style="top:' + (PADT + (runLine - 1) * LH) + 'px;height:' + LH + 'px"></div>';
      marks.innerHTML = h;
      renderGutterMarks();
    }
    function caretInfo() {
      var v = ta.value, p = ta.selectionStart, before = v.slice(0, p), line = (before.match(/\n/g) || []).length + 1, col = p - before.lastIndexOf('\n');
      return { line: line, col: col };
    }
    function updateCursor() {
      var c = caretInfo();
      cursorMark.style.top = (PADT + (c.line - 1) * LH) + 'px'; cursorMark.style.height = LH + 'px';
      cursorMark.style.display = ta.selectionStart === ta.selectionEnd ? '' : 'none';
      if (cb.cursor) cb.cursor(c.line, c.col);
      if (acOpen) acUpdate();
      tipUpdate(c.line);
    }

    /* ---- historial ---- */
    function snap() { return { t: ta.value, s: ta.selectionStart, e: ta.selectionEnd }; }
    function pushUndo(prev) { cur.undo.push(prev); if (cur.undo.length > 500) cur.undo.shift(); cur.redo.length = 0; }
    function changed(force) {
      var v = ta.value;
      if (v === cur.last.t) { cur.last = snap(); updateCursor(); return; }
      var now = Date.now();
      if (force || now - cur.lastPush > 900 || !cur.undo.length) { pushUndo(cur.last); cur.lastPush = now; }
      cur.last = snap();
      schedule(); updateCursor();
      if (cb.change) cb.change();
    }
    function applyState(st) {
      ta.value = st.t; ta.setSelectionRange(st.s, st.e); cur.last = snap(); cur.lastPush = 0;
      refresh(); updateCursor(); ensureVisible(); if (cb.change) cb.change();
    }
    api.undo = function () { if (!cur || !cur.undo.length) return; cur.redo.push(snap()); applyState(cur.undo.pop()); };
    api.redo = function () { if (!cur || !cur.redo.length) return; cur.undo.push(snap()); applyState(cur.redo.pop()); };
    api.canUndo = function () { return !!(cur && cur.undo.length); };
    api.canRedo = function () { return !!(cur && cur.redo.length); };

    function edit(a, b, str, s1, s2) {
      var v = ta.value, st = ta.scrollTop, sl = ta.scrollLeft;
      ta.value = v.slice(0, a) + str + v.slice(b);
      if (s1 === undefined) s1 = a + str.length;
      ta.setSelectionRange(s1, s2 === undefined ? s1 : s2);
      ta.scrollTop = st; ta.scrollLeft = sl;
      changed(true); ensureVisible();
    }
    api.edit = edit;

    function ensureVisible() {
      var c = caretInfo(), y = PADT + (c.line - 1) * LH, ch = ta.clientHeight;
      if (y < ta.scrollTop) ta.scrollTop = Math.max(0, y - LH);
      else if (y + LH * 2 > ta.scrollTop + ch) ta.scrollTop = y + LH * 2 - ch;
      var x = PADL + (c.col - 1) * charW, cw = ta.clientWidth;
      if (x < ta.scrollLeft) ta.scrollLeft = Math.max(0, x - 40);
      else if (x + 20 > ta.scrollLeft + cw) ta.scrollLeft = x + 60 - cw;
      syncScroll();
    }

    /* ---- carga de pestañas ---- */
    api.load = function (tab) {
      cur = tab; hideAssist();
      if (!cur.undo) { cur.undo = []; cur.redo = []; }
      ta.value = tab.text || '';
      var s = tab.sel || [0, 0]; try { ta.setSelectionRange(s[0], s[1]); } catch (e) { /* noop */ }
      cur.last = snap(); cur.lastPush = 0; lastLines = -1; refresh();
      ta.scrollTop = tab.st || 0; ta.scrollLeft = tab.sl || 0; syncScroll(); updateCursor();
    };
    api.save = function () { if (!cur) return; cur.text = ta.value; cur.sel = [ta.selectionStart, ta.selectionEnd]; cur.st = ta.scrollTop; cur.sl = ta.scrollLeft; };
    api.getText = function () { return ta.value; };
    api.setText = function (t) { edit(0, ta.value.length, t, 0, 0); };
    api.focus = function () { try { ta.focus({ preventScroll: true }); } catch (e) { ta.focus(); } };
    api.refresh = function () { lastLines = -1; refresh(); };
    api.applySettings = applySettings;
    api.setErrors = function (lines) { errLines = {}; (lines || []).forEach(function (l) { errLines[l] = 1; }); renderMarks(); };
    api.setRunLine = function (l) { runLine = l || 0; renderMarks(); if (l) goLine(l, true); };
    function goLine(n, noSelect) {
      var lines = ta.value.split('\n'), pos = 0, i;
      n = Math.max(1, Math.min(n, lines.length));
      for (i = 0; i < n - 1; i++) pos += lines[i].length + 1;
      if (!noSelect) ta.setSelectionRange(pos, pos + lines[n - 1].length);
      var y = PADT + (n - 1) * LH, ch = ta.clientHeight;
      if (y < ta.scrollTop + LH || y + LH * 2 > ta.scrollTop + ch) ta.scrollTop = Math.max(0, y - ch / 3);
      syncScroll(); updateCursor();
    }
    api.goLine = function (n) { goLine(n, false); };
    api.insert = function (str, caretBack) {
      var a = ta.selectionStart, b = ta.selectionEnd, p = a + str.length - (caretBack || 0);
      edit(a, b, str, p, p); api.focus();
    };
    api.selection = function () { return ta.value.slice(ta.selectionStart, ta.selectionEnd); };
    api.selectAll = function () { api.focus(); ta.setSelectionRange(0, ta.value.length); updateCursor(); };
    api.deleteSelection = function () { var a = ta.selectionStart, b = ta.selectionEnd; if (a !== b) edit(a, b, ''); };

    /* ---- operaciones sobre líneas ---- */
    function lineRange() {
      var v = ta.value, a = ta.selectionStart, b = ta.selectionEnd;
      var s = v.lastIndexOf('\n', a - 1) + 1;
      if (b > a && v.charAt(b - 1) === '\n') b--;
      var e = v.indexOf('\n', b); if (e < 0) e = v.length;
      return { s: s, e: e, a: a, b: ta.selectionEnd };
    }
    api.duplicate = function () {
      var r = lineRange(), chunk = ta.value.slice(r.s, r.e);
      edit(r.e, r.e, '\n' + chunk, r.a + chunk.length + 1, r.b + chunk.length + 1);
    };
    api.deleteLines = function () {
      var r = lineRange(), v = ta.value, e = r.e < v.length ? r.e + 1 : r.e, s = r.s;
      if (e === v.length && s > 0) s--;
      edit(s, e, '', s);
    };
    api.moveLines = function (dir) {
      var r = lineRange(), v = ta.value, chunk = v.slice(r.s, r.e);
      if (dir < 0) {
        if (r.s === 0) return;
        var ps = v.lastIndexOf('\n', r.s - 2) + 1, prev = v.slice(ps, r.s - 1);
        edit(ps, r.e, chunk + '\n' + prev, r.a - (prev.length + 1), r.b - (prev.length + 1));
      } else {
        if (r.e >= v.length) return;
        var ne = v.indexOf('\n', r.e + 1); if (ne < 0) ne = v.length;
        var next = v.slice(r.e + 1, ne);
        edit(r.s, ne, next + '\n' + chunk, r.a + next.length + 1, r.b + next.length + 1);
      }
    };
    api.comment = function (on) {
      var r = lineRange(), lines = ta.value.slice(r.s, r.e).split('\n');
      var res = lines.map(function (l) {
        if (on) { delta += 3; return l.replace(/^(\s*)/, '$1// '); }
        var m = /^(\s*)\/\/ ?/.exec(l); if (m) { return l.replace(/^(\s*)\/\/ ?/, '$1'); }
        return l;
      }).join('\n');
      edit(r.s, r.e, res, r.s, r.s + res.length);
    };
    api.toggleComment = function () {
      var r = lineRange(), lines = ta.value.slice(r.s, r.e).split('\n');
      var all = lines.every(function (l) { return !l.trim() || /^\s*\/\//.test(l); });
      api.comment(!all);
    };
    api.reindent = function () {
      var t = ta.value, n = reindent(t, S.indent === 'tab' ? '\t' : new Array((S.indent || 4) + 1).join(' '));
      if (n === t) return false;
      var c = caretInfo(), lines = n.split('\n'), pos = 0, i;
      for (i = 0; i < c.line - 1 && i < lines.length; i++) pos += lines[i].length + 1;
      edit(0, t.length, n, Math.min(pos + lines[Math.min(c.line, lines.length) - 1].length, n.length));
      return true;
    };
    function unit() { return S.indent === 'tab' ? '\t' : new Array((S.indent || 4) + 1).join(' '); }


    /* ---- autocompletado y ayuda flotante ---- */
    var host = wrap.parentNode, acEl = document.createElement('div'), tipEl = document.createElement('div');
    var acOpen = false, acItems = [], acSel = 0, acStart = 0, acKey = '';
    acEl.className = 'ac'; tipEl.className = 'actip'; acEl.style.display = 'none'; tipEl.style.display = 'none';
    acEl.setAttribute('role', 'listbox'); host.appendChild(acEl); host.appendChild(tipEl);
    function acOn() { return S.autoComplete !== false; }
    function lineBefore() { var v = ta.value, p = ta.selectionStart; return v.slice(v.lastIndexOf('\n', p - 1) + 1, p); }
    function visCol(t) { var c = 0, i; for (i = 0; i < t.length; i++) c += t.charAt(i) === '\t' ? 4 - (c % 4) : 1; return c; }
    function inCode(t) {
      var q = null, i, c;
      for (i = 0; i < t.length; i++) { c = t.charAt(i); if (q) { if (c === q) q = null; continue; } if (c === '"' || c === "'") { q = c; continue; } if (c === '/' && t.charAt(i + 1) === '/') return false; }
      return !q;
    }
    function place(el, col, ln) {
      var y = PADT + ln * LH - ta.scrollTop;
      if (y < -LH || y > ta.clientHeight) { el.style.display = 'none'; return false; }
      el.style.display = 'block'; el.style.left = '0px'; el.style.top = '0px';
      var left = wrap.offsetLeft + PADL + col * charW - ta.scrollLeft, top = wrap.offsetTop + y + LH, w = el.offsetWidth, h = el.offsetHeight;
      var hr = host.getBoundingClientRect(), vv = window.visualViewport, vw = window.innerWidth, vh = vv ? vv.offsetTop + vv.height : window.innerHeight;
      if (hr.left + left + w > vw - 6) left = vw - 6 - w - hr.left;
      if (hr.left + left < 4) left = 4 - hr.left;
      if (hr.top + top + h > vh - 6 && hr.top + top - LH - h > 4) top = top - LH - h;
      el.style.left = Math.round(left) + 'px'; el.style.top = Math.round(top) + 'px';
      return true;
    }
    function tipHide() { tipEl.style.display = 'none'; }
    function acHide() { if (acOpen) { acOpen = false; acKey = ''; } acEl.style.display = 'none'; }
    function hideAssist() { acHide(); tipHide(); }
    function acSetSel(i) {
      var n = acItems.length, kids = acEl.children, on;
      if (!n) return;
      acSel = (i + n) % n;
      for (var j = 0; j < kids.length; j++) kids[j].className = 'ai' + (j === acSel ? ' on' : '');
      on = kids[acSel];
      if (on) { if (on.offsetTop < acEl.scrollTop) acEl.scrollTop = on.offsetTop; else if (on.offsetTop + on.offsetHeight > acEl.scrollTop + acEl.clientHeight) acEl.scrollTop = on.offsetTop + on.offsetHeight - acEl.clientHeight; }
    }
    function acUpdate() {
      if (!acOn() || ta.selectionStart === undefined || ta.selectionStart !== ta.selectionEnd) { acHide(); return; }
      var v = ta.value, p = ta.selectionStart;
      if (/[A-Za-z0-9_À-ÿ]/.test(v.charAt(p))) { acHide(); return; }
      var lb = lineBefore(), m = /[A-Za-zÁÉÍÓÚÜÑáéíóúüñ_][A-Za-zÁÉÍÓÚÜÑáéíóúüñ_0-9]*$/.exec(lb);
      if (!m || m[0].length < 3 || !inCode(lb)) { acHide(); return; }
      var word = strip(m[0]).toLowerCase(), atStart = /^\s*$/.test(lb.slice(0, m.index)), inDef = words(lb)[0] === 'DEFINIR', list = [], i, it;
      for (i = 0; i < ACL.length; i++) {
        it = ACL[i];
        if (it.d ? !inDef : (!it.a && !atStart)) continue;
        if (it.k.indexOf(word) === 0) list.push(it);
      }
      if (!list.length || (list.length === 1 && list[0].k === word)) { acHide(); return; }
      var key = list.map(function (x) { return x.l; }).join('|'), same = acOpen && key === acKey, h = '';
      acKey = key; acItems = list; acStart = p - m[0].length; if (!same) acSel = 0;
      for (i = 0; i < list.length; i++) h += '<div class="ai' + (i === acSel ? ' on' : '') + '" data-i="' + i + '">' + H(list[i].l) + '</div>';
      acEl.innerHTML = h; acOpen = true; tipHide();
      var col = visCol(lb.slice(0, m.index)), ln = caretInfo().line - 1;
      if (!place(acEl, col, ln)) { acOpen = false; return; }
      acSetSel(acSel);
    }
    function acAccept(i) {
      var it = acItems[i]; if (!acOpen || !it) return false;
      var a = acStart, b = ta.selectionStart, txt = it.l + (it.s ? '' : (it.f ? '(' : ' '));
      acHide(); edit(a, b, txt, a + txt.length); api.focus(); return true;
    }
    function tipFor(lb) {
      var t = strip(lb).toLowerCase(), fm = /([a-z_][a-z_0-9]*)\($/.exec(t), i;
      if (fm && FNHINT.hasOwnProperty(fm[1])) return FNHINT[fm[1]];
      if (!/\s$/.test(t)) return '';
      for (i = 0; i < HINTS.length; i++) if (HINTS[i].re.test(t)) return HINTS[i].h;
      return '';
    }
    function tipUpdate(line) {
      if (!acOn() || acOpen || ta.selectionStart !== ta.selectionEnd) { tipHide(); return; }
      var lb = lineBefore(), t = lb && inCode(lb) ? tipFor(lb) : '';
      if (!t) { tipHide(); return; }
      tipEl.textContent = t; place(tipEl, visCol(lb), line - 1);
    }
    function acKeys(e, k, ctrl) {
      if (!acOpen) return false;
      if (k === 'ArrowDown') { e.preventDefault(); acSetSel(acSel + 1); return true; }
      if (k === 'ArrowUp') { e.preventDefault(); acSetSel(acSel - 1); return true; }
      if ((k === 'Enter' || k === 'Tab') && !ctrl && !e.shiftKey && !e.altKey) { e.preventDefault(); acAccept(acSel); return true; }
      if (k === 'Escape') { e.preventDefault(); e.stopPropagation(); acHide(); return true; }
      return false;
    }
    function acPick(e) {
      var t = e.target; while (t && t !== acEl && !(t.getAttribute && t.getAttribute('data-i') !== null)) t = t.parentNode;
      if (!t || t === acEl) return;
      e.preventDefault(); acAccept(parseInt(t.getAttribute('data-i'), 10));
    }
    acEl.addEventListener('mousedown', acPick); acEl.addEventListener('touchstart', acPick);
    tipEl.addEventListener('mousedown', function (e) { e.preventDefault(); });
    ta.addEventListener('blur', function () { setTimeout(function () { if (document.activeElement !== ta) hideAssist(); }, 150); });

    /* ---- eventos de teclado ---- */
    function onEnter() {
      if (acOpen) { acAccept(acSel); return; }
      var v = ta.value, a = ta.selectionStart, b = ta.selectionEnd;
      var ls = v.lastIndexOf('\n', a - 1) + 1, before = v.slice(ls, a), lead = /^[ \t]*/.exec(before)[0];
      var rest = '', extra = '', w = words(before), f = w[0];
      if (!S.autoIndent) { edit(a, b, '\n', a + 1); return; }
      var isOpen = !!(OPENERS[f] && !(f === 'MIENTRAS' && w[1] === 'QUE') && before.trim());
      if (isOpen || f === 'SINO') extra = unit();
      if (f === 'SEGUN') extra = unit() + unit();
      var ins = '\n' + lead + extra, caret = a + ins.length;
      var restOfLine = v.slice(a, v.indexOf('\n', a) < 0 ? v.length : v.indexOf('\n', a));
      if (S.autoClose && isOpen && !restOfLine.trim() && countBalance(v.slice(0, a) + v.slice(a), f) > 0) {
        ins += '\n' + lead + CLOSE_OF[f];
      }
      edit(a, b, ins, caret);
    }
    function indentSel(out) {
      var v = ta.value, a = ta.selectionStart, b = ta.selectionEnd, u = unit();
      if (a === b && !out) { edit(a, b, u, a + u.length); return; }
      var r = lineRange(), lines = v.slice(r.s, r.e).split('\n'), first = 0, total = 0;
      var res = lines.map(function (l, i) {
        if (out) { var m = l.indexOf(u) === 0 ? u.length : (/^ {1,3}/.exec(l) || [''])[0].length; if (i === 0) first = -m; total -= m; return l.slice(m); }
        if (i === 0) first = u.length; total += u.length; return u + l;
      }).join('\n');
      edit(r.s, r.e, res, Math.max(r.s, a + first), Math.max(r.s, b + total));
    }
    ta.addEventListener('keydown', function (e) {
      var k = e.key, ctrl = e.ctrlKey || e.metaKey;
      if (e.isComposing || e.keyCode === 229) return;
      if (acKeys(e, k, ctrl)) return;
      if (k === 'Enter' && !ctrl && !e.shiftKey) { e.preventDefault(); onEnter(); return; }
      if (k === 'Tab' && !ctrl) { e.preventDefault(); indentSel(e.shiftKey); return; }
      if (ctrl && !e.altKey) {
        var lk = (k || '').toLowerCase();
        if (lk === 'z') { e.preventDefault(); if (e.shiftKey) api.redo(); else api.undo(); }
        else if (lk === 'y') { e.preventDefault(); api.redo(); }
        else if (lk === 't') { e.preventDefault(); api.moveLines(e.shiftKey ? 1 : -1); }
        else if (lk === 'l') { e.preventDefault(); if (e.shiftKey) api.deleteLines(); else api.duplicate(); }
        else if (lk === 'd') { e.preventDefault(); api.comment(!e.shiftKey); }
        else if (lk === 'i') { e.preventDefault(); api.reindent(); }
      }
    });
    ta.addEventListener('beforeinput', function (e) {
      var t = e.inputType;
      if (t === 'historyUndo') { e.preventDefault(); api.undo(); }
      else if (t === 'historyRedo') { e.preventDefault(); api.redo(); }
      else if (t === 'insertLineBreak' || (t === 'insertParagraph') || (t === 'insertText' && e.data === '\n')) { e.preventDefault(); onEnter(); }
    });
    ta.addEventListener('input', function (e) {
      changed(false);
      var t = e && e.inputType;
      if (!t || /^insert(Text|CompositionText|ReplacementText)$/.test(t)) acUpdate(); else if (/^(insertFrom|history)/.test(t)) hideAssist();
    });
    ta.addEventListener('scroll', function () { syncScroll(); if (acOpen) acUpdate(); else if (tipEl.style.display !== 'none') tipUpdate(caretInfo().line); });
    ['keyup', 'click', 'focus', 'touchend', 'select', 'mouseup'].forEach(function (ev) { ta.addEventListener(ev, function () { setTimeout(updateCursor, 0); }); });

    /* ---- buscar y reemplazar ---- */
    function findAll(q, o) {
      var v = ta.value, out = [], hay = o.cs ? v : v.toLowerCase(), nd = o.cs ? q : q.toLowerCase(), i = 0;
      if (!q) return out;
      while ((i = hay.indexOf(nd, i)) >= 0) {
        var okw = true;
        if (o.word) { var pc = v.charAt(i - 1), nc = v.charAt(i + q.length); okw = !/[A-Za-z0-9_À-ÿ]/.test(pc || ' ') && !/[A-Za-z0-9_À-ÿ]/.test(nc || ' '); }
        if (okw) out.push(i);
        i += Math.max(1, q.length);
      }
      return out;
    }
    api.count = function (q, o) { return findAll(q, o).length; };
    api.find = function (q, o, dir) {
      var all = findAll(q, o); if (!all.length) return false;
      var a = ta.selectionStart, b = ta.selectionEnd, pick, i;
      if (dir < 0) { pick = all[all.length - 1]; for (i = all.length - 1; i >= 0; i--) if (all[i] < a) { pick = all[i]; break; } }
      else { pick = all[0]; for (i = 0; i < all.length; i++) if (all[i] >= b) { pick = all[i]; break; } }
      ta.setSelectionRange(pick, pick + q.length); ensureVisible(); updateCursor(); return true;
    };
    api.replaceCurrent = function (q, r, o) {
      var sel = ta.value.slice(ta.selectionStart, ta.selectionEnd);
      if (sel && (o.cs ? sel === q : sel.toLowerCase() === q.toLowerCase())) { var a = ta.selectionStart; edit(a, ta.selectionEnd, r, a + r.length); }
      return api.find(q, o, 1);
    };
    api.replaceAll = function (q, r, o) {
      var all = findAll(q, o); if (!all.length) return 0;
      var v = ta.value, out = '', last = 0;
      all.forEach(function (i) { out += v.slice(last, i) + r; last = i + q.length; });
      out += v.slice(last); edit(0, v.length, out, 0); return all.length;
    };

    wrap.addEventListener('mousedown', function (e) { if (e.target === wrap) { e.preventDefault(); api.focus(); } });
    return api;
  }

  root.PSEditor = { create: create, highlight: highlight, reindent: reindent, strip: strip };
})(typeof self !== 'undefined' ? self : this);
