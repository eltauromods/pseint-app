/*!
 * PSeInt Web - generador de diagramas de flujo (SVG) a partir del árbol del programa.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Flow = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var THEMES = {
    light: { line: '#8b1a1a', text: '#10105a', bg: '#fffdf7', start: '#fde9b8', box: '#fff7dc', io: '#fff1c2', dec: '#fff7dc', loop: '#fbe9d2', label: '#555' },
    dark: { line: '#ff8a80', text: '#dfe6ff', bg: '#161a26', start: '#4a3f1f', box: '#2a2f45', io: '#33384f', dec: '#2d3350', loop: '#3a2f45', label: '#aab' }
  };
  var CH = 8.3, LH = 17, G = 24;

  function x(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function pretty(s) { return String(s).replace(/<-/g, '←').replace(/<=/g, '≤').replace(/>=/g, '≥').replace(/<>/g, '≠').replace(/\s+/g, ' '); }
  function clip(s, n) { s = pretty(s); return s.length > n ? s.slice(0, Math.max(1, n - 1)) + '…' : s; }

  function build(unit, themeName) {
    var T = THEMES[themeName] || THEMES.light;
    var uid = 0;

    function txt(cx, cy, s, size, extra) {
      return '<text x="' + cx + '" y="' + (cy + 5) + '" text-anchor="middle" font-family="Consolas,Menlo,monospace" font-size="' + (size || 14) + '" fill="' + (extra || T.text) + '">' + x(s) + '</text>';
    }
    function line(x1, y1, x2, y2, arrow) {
      return '<path d="M' + x1 + ' ' + y1 + 'L' + x2 + ' ' + y2 + '" stroke="' + T.line + '" stroke-width="1.6" fill="none"' + (arrow ? ' marker-end="url(#ah)"' : '') + '/>';
    }
    function poly(pts, arrow) {
      var d = 'M' + pts.map(function (p) { return p[0] + ' ' + p[1]; }).join('L');
      return '<path d="' + d + '" stroke="' + T.line + '" stroke-width="1.6" fill="none" stroke-linejoin="round"' + (arrow ? ' marker-end="url(#ah)"' : '') + '/>';
    }
    function g(l, inner) { return '<g class="fl" data-l="' + (l || 0) + '">' + inner + '</g>'; }

    /* ----- nodos simples ----- */
    function simple(kind, text, l) {
      var s = pretty(text), w = Math.max(90, Math.min(520, s.length * CH + 44)), h = 40;
      var shown = clip(text, Math.floor((w - 30) / CH));
      return {
        w: w, h: h, ax: w / 2,
        draw: function (X, Y) {
          var cx = X + w / 2, cy = Y + h / 2, sh;
          if (kind === 'start') sh = '<rect x="' + X + '" y="' + Y + '" width="' + w + '" height="' + h + '" rx="20" fill="' + T.start + '" stroke="' + T.line + '" stroke-width="1.6"/>';
          else if (kind === 'io') sh = '<path d="M' + (X + 14) + ' ' + Y + 'L' + (X + w) + ' ' + Y + 'L' + (X + w - 14) + ' ' + (Y + h) + 'L' + X + ' ' + (Y + h) + 'Z" fill="' + T.io + '" stroke="' + T.line + '" stroke-width="1.6"/>';
          else if (kind === 'call') sh = '<rect x="' + X + '" y="' + Y + '" width="' + w + '" height="' + h + '" fill="' + T.box + '" stroke="' + T.line + '" stroke-width="1.6"/><path d="M' + (X + 9) + ' ' + Y + 'V' + (Y + h) + 'M' + (X + w - 9) + ' ' + Y + 'V' + (Y + h) + '" stroke="' + T.line + '" stroke-width="1.2"/>';
          else sh = '<rect x="' + X + '" y="' + Y + '" width="' + w + '" height="' + h + '" fill="' + T.box + '" stroke="' + T.line + '" stroke-width="1.6"/>';
          return g(l, sh + txt(cx, cy, shown));
        }
      };
    }
    function shapeDec(hex, text, l) {
      var s = pretty(text), tw = s.length * CH;
      var w = hex ? Math.min(Math.max(120, tw + 50), 560) : Math.min(Math.max(120, tw * 1.25 + 56), 420);
      var h = hex ? 46 : Math.max(60, Math.min(90, w * 0.4));
      var maxc = Math.floor((hex ? w - 44 : w * 0.66 - 8) / CH);
      return {
        w: w, h: h, text: clip(text, maxc),
        draw: function (X, Y) {
          var cx = X + w / 2, cy = Y + h / 2, sh;
          if (hex) sh = '<path d="M' + (X + 18) + ' ' + Y + 'L' + (X + w - 18) + ' ' + Y + 'L' + (X + w) + ' ' + cy + 'L' + (X + w - 18) + ' ' + (Y + h) + 'L' + (X + 18) + ' ' + (Y + h) + 'L' + X + ' ' + cy + 'Z" fill="' + T.loop + '" stroke="' + T.line + '" stroke-width="1.6"/>';
          else sh = '<path d="M' + cx + ' ' + Y + 'L' + (X + w) + ' ' + cy + 'L' + cx + ' ' + (Y + h) + 'L' + X + ' ' + cy + 'Z" fill="' + T.dec + '" stroke="' + T.line + '" stroke-width="1.6"/>';
          return g(l, sh + txt(cx, cy, this.text, 13));
        }
      };
    }
    function lab(X, Y, s) { return txt(X, Y, s, 12, T.label); }

    /* ----- secuencia ----- */
    function empty() {
      return { w: 24, h: 24, ax: 12, draw: function (X, Y) { return line(X + 12, Y, X + 12, Y + 24); } };
    }
    function seq(list) {
      if (!list || !list.length) return empty();
      var ch = list.map(one), L = 0, Rr = 0, h = 0;
      ch.forEach(function (c) { L = Math.max(L, c.ax); Rr = Math.max(Rr, c.w - c.ax); h += c.h; });
      h += G * (ch.length - 1);
      return {
        w: L + Rr, h: h, ax: L,
        draw: function (X, Y) {
          var out = '', yy = Y;
          ch.forEach(function (c, i) {
            out += c.draw(X + L - c.ax, yy);
            yy += c.h;
            if (i < ch.length - 1) { out += line(X + L, yy, X + L, yy + G, true); yy += G; }
          });
          return out;
        }
      };
    }

    function one(n) {
      var l = n.line;
      switch (n.k) {
        case 'start': return simple('start', n.text, n.line);
        case 'end': return simple('start', n.text, n.line);
        case 'def': return simple('box', 'Definir ' + (n.shownNames || n.names).join(', ') + ' Como ' + ({ I: 'Entero', R: 'Real', L: 'Logico', S: 'Texto' }[n.type] || ''), l);
        case 'dim': return simple('box', 'Dimension ' + n.items.map(function (i) { return i.n + '[' + i.dims.length + 'D]'; }).join(', '), l);
        case 'asg': return simple('box', n.text, l);
        case 'out': return simple('io', n.text, l);
        case 'in': return simple('io', 'Leer ' + n.targets.map(function (t) { return t.shown || t.n; }).join(', '), l);
        case 'call': return simple('call', (n.shown || n.n) + '(' + (n.args.length ? '…' : '') + ')', l);
        case 'ret': return simple('box', 'Retornar', l);
        case 'wait': return simple('box', n.key ? 'Esperar Tecla' : 'Esperar', l);
        case 'cls': return simple('box', 'Limpiar Pantalla', l);
        case 'if': return ifB(n);
        case 'wh': return loopB(n, false);
        case 'for': return loopB(n, true);
        case 'rp': return repB(n);
        case 'sw': return swB(n);
      }
      return simple('box', '?', l);
    }

    function ifB(n) {
      var D = shapeDec(false, n.ctext, n.line), A = seq(n.a), B = seq(n.b || []), gap = 40;
      var bw = A.w + gap + B.w, W = Math.max(bw, D.w + 20), bx = (W - bw) / 2;
      var axA = bx + A.ax, axB = bx + A.w + gap + B.ax, cx = W / 2, top = D.h + 30, bh = Math.max(A.h, B.h), h = top + bh + 26;
      return {
        w: W, h: h, ax: cx,
        draw: function (X, Y) {
          var o = D.draw(X + cx - D.w / 2, Y), cy = Y + D.h / 2;
          o += poly([[X + cx - D.w / 2, cy], [X + axA, cy], [X + axA, Y + top]], true) + lab(X + (cx - D.w / 2 + axA) / 2, cy - 7, 'V');
          o += poly([[X + cx + D.w / 2, cy], [X + axB, cy], [X + axB, Y + top]], true) + lab(X + (cx + D.w / 2 + axB) / 2, cy - 7, 'F');
          o += A.draw(X + bx, Y + top) + B.draw(X + bx + A.w + gap, Y + top);
          var yb = Y + top + bh, ym = Y + h;
          if (A.h < bh) o += line(X + axA, Y + top + A.h, X + axA, yb);
          if (B.h < bh) o += line(X + axB, Y + top + B.h, X + axB, yb);
          o += poly([[X + axA, yb], [X + axA, ym], [X + cx, ym]]) + poly([[X + axB, yb], [X + axB, ym], [X + cx, ym]]);
          return o;
        }
      };
    }

    function loopB(n, hex) {
      var text = hex ? ('Para ' + n.vshown + ' ← ' + n.atext + ' Hasta ' + n.btext + (n.stext ? ' Paso ' + n.stext : '')) : n.ctext;
      var D = shapeDec(hex, text, n.line), B = seq(n.body);
      var left = Math.max(B.ax, D.w / 2) + 26, right = Math.max(B.w - B.ax, D.w / 2) + 26, W = left + right, cx = left;
      var y0 = D.h + 30, y1 = y0 + B.h, h = y1 + 22;
      return {
        w: W, h: h, ax: cx,
        draw: function (X, Y) {
          var o = D.draw(X + cx - D.w / 2, Y), cy = Y + D.h / 2, xl = X + 8, xr = X + W - 8;
          o += line(X + cx, Y + D.h, X + cx, Y + y0, true) + lab(X + cx + 12, Y + D.h + 14, 'V');
          o += B.draw(X + cx - B.ax, Y + y0);
          o += poly([[X + cx, Y + y1], [X + cx, Y + y1 + 14], [xl, Y + y1 + 14], [xl, cy], [X + cx - D.w / 2, cy]], true);
          o += poly([[X + cx + D.w / 2, cy], [xr, cy], [xr, Y + h], [X + cx, Y + h]]) + lab(X + cx + D.w / 2 + 14, cy - 7, 'F');
          if (hex) return o;
          return o;
        }
      };
    }

    function repB(n) {
      var D = shapeDec(false, n.ctext, n.condLine), B = seq(n.body);
      var left = Math.max(B.ax, D.w / 2) + 26, right = Math.max(B.w - B.ax, D.w / 2) + 26, W = left + right, cx = left;
      var yb = 22, yd = yb + B.h + G, h = yd + D.h;
      return {
        w: W, h: h, ax: cx,
        draw: function (X, Y) {
          var o = line(X + cx, Y, X + cx, Y + yb, true) + B.draw(X + cx - B.ax, Y + yb);
          o += line(X + cx, Y + yb + B.h, X + cx, Y + yd, true) + D.draw(X + cx - D.w / 2, Y + yd);
          var cy = Y + yd + D.h / 2, xl = X + 8;
          o += poly([[X + cx - D.w / 2, cy], [xl, cy], [xl, Y + 9], [X + cx, Y + 9]], true);
          o += lab(X + cx - D.w / 2 - 14, cy - 7, n.until ? 'F' : 'V') + lab(X + cx + 14, Y + h + 10, n.until ? 'V' : 'F');
          return o;
        }
      };
    }

    function swB(n) {
      var D = shapeDec(false, n.ctext, n.line), cols = [], gap = 26;
      n.cases.forEach(function (c) { cols.push({ label: c.ltext.replace(/\s*:\s*$/, ''), b: seq(c.body) }); });
      if (n.def) cols.push({ label: 'De Otro Modo', b: seq(n.def) });
      if (!cols.length) cols.push({ label: '', b: empty() });
      var bw = 0, bh = 0;
      cols.forEach(function (c, i) { c.x = bw; bw += c.b.w + (i < cols.length - 1 ? gap : 0); bh = Math.max(bh, c.b.h); c.ax = c.x + c.b.ax; });
      var W = Math.max(bw, D.w + 20), bx = (W - bw) / 2, cx = W / 2, bus = D.h + 16, top = bus + 40, h = top + bh + 26;
      return {
        w: W, h: h, ax: cx,
        draw: function (X, Y) {
          var o = D.draw(X + cx - D.w / 2, Y), first = bx + cols[0].ax, last = bx + cols[cols.length - 1].ax;
          o += line(X + cx, Y + D.h, X + cx, Y + bus);
          o += line(X + Math.min(first, cx), Y + bus, X + Math.max(last, cx), Y + bus);
          cols.forEach(function (c) {
            var ax = X + bx + c.ax;
            o += line(ax, Y + bus, ax, Y + top, true) + lab(ax, Y + bus + 14, clip(c.label, Math.max(4, Math.floor((c.b.w + gap) / 7.4))));
            o += c.b.draw(X + bx + c.x, Y + top);
            var yb = Y + top + bh;
            if (c.b.h < bh) o += line(ax, Y + top + c.b.h, ax, yb);
            o += poly([[ax, yb], [ax, Y + h], [X + cx, Y + h]]);
          });
          return o;
        }
      };
    }

    /* ----- ensamblado ----- */
    var title = unit.node.text || ('Algoritmo ' + unit.name);
    var list = [{ k: 'start', text: title, line: unit.node.line }].concat(unit.body).concat([{
      k: 'end', line: unit.node.endLine,
      text: unit.kind === 'main' ? 'FinAlgoritmo' : (unit.node.isFun ? 'FinFuncion' : 'FinSubProceso')
    }]);
    var root = seq(list), pad = 28, W = root.w + pad * 2, H = root.h + pad * 2;
    var body = root.draw(pad, pad);
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H + '">' +
      '<defs><marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="' + T.line + '"/></marker></defs>' +
      '<rect width="100%" height="100%" fill="' + T.bg + '"/>' + body + '</svg>';
    return { svg: svg, w: W, h: H };
  }

  /* devuelve la lista de diagramas disponibles del programa */
  function units(an) {
    return (an && an.units || []).map(function (u) { return { name: u.kind === 'main' ? u.node.name : u.node.shown, unit: u, main: u.kind === 'main' }; });
  }

  return { build: build, units: units, THEMES: THEMES };
});
