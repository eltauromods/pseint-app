/*!
 * PSeInt Web - núcleo del lenguaje (analizador, verificador y ejecutor de pseudocódigo)
 * Desarrollado por El Tauro Mods. Implementación independiente inspirada en el lenguaje de PSeInt.
 * Compatible con navegadores ES2017 (Android 5+ con WebView/Chrome actualizado, iOS 11+, etc.)
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PSC = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ------------------------------------------------------------------ perfiles */
  var PROFILES = {
    flexible: { id: 'flexible', name: 'Flexible', implicitVars: true, eqAssign: true, optKw: true, base: 1, strictTypes: false },
    estricto: { id: 'estricto', name: 'Estricto', implicitVars: false, eqAssign: false, optKw: false, base: 1, strictTypes: true }
  };

  /* ------------------------------------------------------------------ utilidades */
  function strip(s) {
    try { return s.normalize('NFD').replace(/[̀-ͯ]/g, ''); } catch (e) { return s; }
  }
  function esc(s) {
    return JSON.stringify(s).split('\u2028').join('\\u2028').split('\u2029').join('\\u2029');
  }
  function fmt(t, args) {
    return t.replace(/\{(\d)\}/g, function (_, i) { return args && args[i] !== undefined ? args[i] : ''; });
  }

  /* ------------------------------------------------------------------ catálogo de errores */
  var EC = {
    100: ['Carácter no válido: "{0}"', 'Ese carácter no forma parte del lenguaje. Elimínelo o colóquelo dentro de un texto entre comillas.'],
    101: ['Falta cerrar las comillas del texto', 'Todo texto debe empezar y terminar con comillas del mismo tipo. Ejemplo: Escribir "Hola".'],
    102: ['Falta cerrar el comentario /* ... */', 'Un comentario de varias líneas se cierra con */.'],
    110: ['Instrucción no reconocida: "{0}"', 'La línea no empieza con ninguna instrucción válida (Escribir, Leer, Si, Mientras, Para, una asignación, etc.). Revise la ortografía.'],
    111: ['Se esperaba {0}', 'La estructura de la instrucción no está completa. Revise la sintaxis en la ayuda (menú Ayuda > Índice).'],
    112: ['Falta cerrar paréntesis ")"', 'Cada paréntesis abierto "(" debe cerrarse con ")".'],
    113: ['Falta cerrar corchete "]"', 'Cada corchete abierto "[" debe cerrarse con "]".'],
    114: ['Se esperaba una expresión o valor', 'Falta un operando: un número, texto, variable o cálculo. Por ejemplo en "x <- " falta el valor a asignar.'],
    115: ['Sobran símbolos al final de la instrucción ("{0}") o falta un operador', 'Después de una instrucción completa solo puede haber un salto de línea o un punto y coma. Si quería sumar o concatenar, falta el operador (+, -, *, /) o una coma en Escribir.'],
    120: ['Falta {0} para cerrar el {1} de la línea {2}', 'Todo bloque (Si, Mientras, Para, Segun, Algoritmo...) debe terminar con su palabra de cierre.'],
    121: ['"{0}" no tiene su apertura correspondiente', 'Se encontró una palabra de cierre o de continuación sin la estructura que la inicia.'],
    122: ['No se encontró el Algoritmo (o Proceso) principal', 'El programa debe tener la forma:\nAlgoritmo nombre\n   ...instrucciones...\nFinAlgoritmo'],
    123: ['Hay más de un Algoritmo principal', 'Solo puede haber un Algoritmo/Proceso por programa. Los demás deben ser SubProceso o Funcion.'],
    124: ['Instrucción fuera del Algoritmo o SubProceso', 'Todas las instrucciones deben estar dentro de Algoritmo ... FinAlgoritmo o dentro de un SubProceso.'],
    130: ['La variable "{0}" no ha sido definida (el perfil es estricto)', 'En el perfil Estricto toda variable debe declararse antes con Definir. Cambie el perfil en Configurar > Opciones del Lenguaje o agregue Definir {0} Como Tipo.'],
    131: ['La variable "{0}" se usa pero nunca recibe un valor', 'La variable no está definida ni asignada en ninguna parte (con <-, Leer, Para o Definir). Puede ser un error de escritura en el nombre.'],
    132: ['No coinciden los tipos: "{0}" es de tipo {1} y se le asigna un valor {2}', 'El tipo declarado con Definir no coincide con el valor asignado.'],
    140: ['No existe la función o subproceso "{0}"', 'El nombre no corresponde a una función del lenguaje ni a un SubProceso/Funcion definido, ni a un arreglo.'],
    141: ['{0} espera {1} argumento(s) y se le pasaron {2}', 'La cantidad de argumentos de la llamada no coincide con la definición.'],
    142: ['El subproceso "{0}" no retorna un valor y no puede usarse dentro de una expresión', 'Para devolver un valor defínalo como: Funcion resultado <- nombre(parámetros).'],
    143: ['Nombre de función repetido o reservado: "{0}"', 'Cada SubProceso/Funcion debe tener un nombre único que no coincida con las funciones del lenguaje.'],
    144: ['Falta el subíndice del arreglo "{0}"', 'Un arreglo debe usarse con su posición. Ejemplo: {0}[1]. Solo puede pasarse completo como argumento de una función.'],
    145: ['El arreglo "{0}" tiene {1} dimensión(es) y se usó con {2} subíndice(s)', 'La cantidad de subíndices debe coincidir con la de Dimension.'],
    146: ['El arreglo "{0}" no ha sido dimensionado', 'Antes de usarlo debe declararse con Dimension {0}[tamaño].'],
    147: ['La función "{0}" nunca asigna valor a su variable de retorno "{1}"', 'Dentro de la función debe asignarse un valor a la variable de retorno.'],
    150: ['Palabra reservada usada como nombre: "{0}"', 'Las palabras del lenguaje no pueden ser nombres de variables ni de funciones.'],
    399: ['Error interno: {0}', 'Ocurrió un fallo inesperado. Intente simplificar el código y repórtelo.']
  };
  var RC = {
    300: ['La variable "{0}" no está inicializada (no tiene valor)', 'Antes de usar una variable debe asignársele un valor (con <- o Leer).'],
    301: ['División por cero', 'No es posible dividir ni calcular el resto entre cero.'],
    302: ['Subíndice fuera de rango: {0}[{1}] (válido de {2} a {3})', 'El índice excede el tamaño dado en Dimension.'],
    303: ['Los operandos de "{0}" no son compatibles ({1} y {2})', 'No se pueden mezclar tipos distintos (por ejemplo comparar un número con un texto).'],
    304: ['La condición debe ser un valor lógico (Verdadero/Falso), no {0}', 'Use una comparación (=, <, >, <=, >=, <>) o variables lógicas.'],
    305: ['Se esperaba un valor numérico y se recibió {0}', 'Esta operación solo funciona con números.'],
    306: ['Argumento inválido para {0}: {1}', 'Revise el valor que pasa a la función.'],
    307: ['Desbordamiento de pila: demasiadas llamadas recursivas', 'Probablemente la recursión no tiene caso base o no termina.'],
    309: ['La función "{0}" terminó sin asignar valor a su variable de retorno', 'Asigne un valor a la variable de retorno antes de terminar.'],
    310: ['No se puede asignar un valor {1} a la variable "{0}" de tipo {2}', 'El valor no coincide con el tipo declarado con Definir.'],
    311: ['El paso del Para no puede ser cero', 'Use un paso distinto de 0 (puede ser negativo).'],
    312: ['El elemento {0} del arreglo no tiene valor asignado', 'Asigne un valor a esa posición antes de leerla.'],
    313: ['No se puede mostrar un arreglo completo; use sus posiciones', 'Muestre elemento por elemento, por ejemplo con Para.'],
    314: ['El arreglo es demasiado grande ({0} elementos)', 'Reduzca las dimensiones.'],
    399: ['Error interno: {0}', 'Ocurrió un fallo inesperado.']
  };
  function mkErr(code, tok, args) {
    var e = EC[code] || ['Error', ''];
    return { code: code, line: tok.line, inst: tok.inst || 1, msg: fmt(e[0], args), help: fmt(e[1], args) };
  }
  function errorHelp(code) { return (EC[code] || RC[code] || ['', ''])[1]; }

  function PscError(code, args, line) {
    var e = RC[code] || ['Error', ''];
    this.name = 'PscError'; this.code = code; this.line = line; this.msg = fmt(e[0], args); this.help = fmt(e[1], args);
    this.message = this.msg; this.runtime = true;
  }
  PscError.prototype = Object.create(Error.prototype);
  var STOP = { stopped: true };

  /* ------------------------------------------------------------------ léxico */
  var RESERVED = {};
  ('ALGORITMO PROCESO FINALGORITMO FINPROCESO SUBPROCESO FUNCION FINSUBPROCESO FINFUNCION DEFINIR DIMENSION LEER ESCRIBIR IMPRIMIR MOSTRAR ' +
   'SI ENTONCES SINO FINSI SEGUN FINSEGUN MIENTRAS FINMIENTRAS REPETIR HASTA PARA FINPARA HACER ESPERAR VERDADERO FALSO Y O NO MOD RETORNAR LIMPIAR BORRAR')
    .split(' ').forEach(function (k) { RESERVED[k] = 1; });

  var KEYWORDS = ['Algoritmo', 'FinAlgoritmo', 'Proceso', 'FinProceso', 'SubProceso', 'FinSubProceso', 'Funcion', 'FinFuncion', 'Definir', 'Como', 'Dimension',
    'Leer', 'Escribir', 'Imprimir', 'Mostrar', 'Sin', 'Saltar', 'Bajar', 'Si', 'Entonces', 'SiNo', 'FinSi', 'Segun', 'Hacer', 'De', 'Otro', 'Modo', 'FinSegun',
    'Mientras', 'FinMientras', 'Repetir', 'Hasta', 'Que', 'Para', 'Con', 'Paso', 'FinPara', 'Esperar', 'Tecla', 'Segundos', 'Milisegundos', 'Limpiar', 'Borrar', 'Pantalla',
    'Por', 'Valor', 'Referencia', 'Retornar', 'Verdadero', 'Falso', 'Y', 'O', 'NO', 'MOD', 'Entero', 'Real', 'Numero', 'Numerico', 'Logico', 'Caracter', 'Texto', 'Cadena'];
  var FUNCS = {
    ABS: [1, 1], TRUNC: [1, 1], REDON: [1, 1], RAIZ: [1, 1], RC: [1, 1], SEN: [1, 1], COS: [1, 1], TAN: [1, 1], ASEN: [1, 1], ACOS: [1, 1], ATAN: [1, 1],
    LN: [1, 1], EXP: [1, 1], AZAR: [1, 1], ALEATORIO: [2, 2], LONGITUD: [1, 1], SUBCADENA: [3, 3], MAYUSCULAS: [1, 1], MINUSCULAS: [1, 1],
    CONCATENAR: [2, 2], CONVERTIRANUMERO: [1, 1], CONVERTIRATEXTO: [1, 1]
  };
  var TYPES = { ENTERO: 'I', REAL: 'R', NUMERO: 'R', NUMERICO: 'R', LOGICO: 'L', CARACTER: 'S', TEXTO: 'S', CADENA: 'S' };
  var TYPENAME = { I: 'Entero', R: 'Real', L: 'Lógico', S: 'Texto' };

  function lex(src, errors) {
    var toks = [], i = 0, n = src.length, line = 1, inst = 1, c;
    var idStart = /[A-Za-zÁÉÍÓÚÜÑáéíóúüñ_]/, idPart = /[A-Za-zÁÉÍÓÚÜÑáéíóúüñ_0-9]/;
    function push(t, v, s, e) {
      var tk = { t: t, v: v, line: line, inst: inst, pos: s, end: e };
      if (t === 'id') { tk.u = v.toUpperCase(); tk.k = strip(tk.u); }
      toks.push(tk); return tk;
    }
    var map1 = { '←': '<-', '≤': '<=', '≥': '>=', '≠': '<>' };
    var single = '=<>+-*/^%&|~!()[],:';
    while (i < n) {
      c = src.charAt(i);
      if (c === '\n') { push('nl', '\n', i, i + 1); line++; inst = 1; i++; continue; }
      if (c === ' ' || c === '\t' || c === '\r' || c === ' ' || c === '﻿') { i++; continue; }
      if (c === '/' && src.charAt(i + 1) === '/') { while (i < n && src.charAt(i) !== '\n') i++; continue; }
      if (c === '/' && src.charAt(i + 1) === '*') {
        var j = src.indexOf('*/', i + 2), endi = j < 0 ? n : j + 2;
        if (j < 0) errors.push(mkErr(102, { line: line, inst: inst }));
        line += (src.slice(i, endi).match(/\n/g) || []).length; i = endi; continue;
      }
      if (c === '"' || c === "'" || c === '“' || c === '”' || c === '‘' || c === '’') {
        var dq = (c === '"' || c === '“' || c === '”');
        var s = '', k = i + 1, closed = false;
        while (k < n) {
          var d = src.charAt(k);
          if (d === '\n') break;
          if (d === '\\' && k + 1 < n) {
            var e2 = src.charAt(k + 1);
            if (e2 === 'n') { s += '\n'; k += 2; continue; }
            if (e2 === 't') { s += '\t'; k += 2; continue; }
            if (e2 === '\\' || e2 === '"' || e2 === "'") { s += e2; k += 2; continue; }
          }
          if (dq ? (d === '"' || d === '“' || d === '”') : (d === "'" || d === '‘' || d === '’')) { closed = true; break; }
          s += d; k++;
        }
        if (!closed) errors.push(mkErr(101, { line: line, inst: inst }));
        push('str', s, i, closed ? k + 1 : k); i = closed ? k + 1 : k; continue;
      }
      if ((c >= '0' && c <= '9') || (c === '.' && /[0-9]/.test(src.charAt(i + 1)))) {
        var m = /^(\d+(\.\d+)?|\.\d+)/.exec(src.slice(i, i + 64));
        push('num', parseFloat(m[0]), i, i + m[0].length); i += m[0].length; continue;
      }
      if (idStart.test(c)) {
        var q = i + 1; while (q < n && idPart.test(src.charAt(q))) q++;
        push('id', src.slice(i, q), i, q); i = q; continue;
      }
      if (map1[c]) { push('op', map1[c], i, i + 1); i++; continue; }
      var two = src.substr(i, 2);
      if (two === '<-' || two === '<=' || two === '>=' || two === '<>' || two === '!=' || two === '==' || two === '&&' || two === '||' || two === ':=') {
        push('op', two, i, i + 2); i += 2; continue;
      }
      if (c === ';') { push('nl', ';', i, i + 1); inst++; i++; continue; }
      if (single.indexOf(c) >= 0) { push('op', c, i, i + 1); i++; continue; }
      errors.push(mkErr(100, { line: line, inst: inst }, [c])); i++;
    }
    push('eof', '', n, n);
    return toks;
  }

  /* ------------------------------------------------------------------ sintaxis */
  var CLOSERS = { FINALGORITMO: 1, FINPROCESO: 1, FINSUBPROCESO: 1, FINFUNCION: 1, FINSI: 1, FINSEGUN: 1, FINMIENTRAS: 1, FINPARA: 1, SINO: 1, HASTA: 1 };
  var CLOSER_NAMES = { FINALGORITMO: 'FinAlgoritmo', FINPROCESO: 'FinProceso', FINSUBPROCESO: 'FinSubProceso', FINFUNCION: 'FinFuncion', FINSI: 'FinSi', FINSEGUN: 'FinSegun', FINMIENTRAS: 'FinMientras', FINPARA: 'FinPara', SINO: 'SiNo', HASTA: 'Hasta Que' };

  function Parser(src, toks, errors, prof) {
    this.src = src; this.t = toks; this.p = 0; this.e = errors; this.prof = prof; this.stack = [];
  }
  var P = Parser.prototype;
  P.peek = function (o) { return this.t[Math.min(this.p + (o || 0), this.t.length - 1)]; };
  P.next = function () { var t = this.t[this.p]; if (this.p < this.t.length - 1) this.p++; return t; };
  P.isNlTok = function (t) { return t.t === 'nl' || t.t === 'eof'; };
  P.isKw = function (t, k) { return t.t === 'id' && t.k === k; };
  P.isOp = function (t, v) { return t.t === 'op' && t.v === v; };
  P.add = function (code, tok, args) { this.e.push(mkErr(code, tok, args)); };
  P.fail = function (code, tok, args) { this.add(code, tok, args); throw { __syn: true }; };
  P.skipLine = function () { while (!this.isNlTok(this.peek())) this.next(); };
  P.skipNl = function () { while (this.peek().t === 'nl') this.next(); };
  P.endStmt = function () {
    var t = this.peek();
    if (!this.isNlTok(t)) this.fail(115, t, [this.src.slice(t.pos, t.end)]);
  };
  P.txt = function (i0) {
    var a = this.t[i0], b = this.t[Math.max(this.p - 1, i0)];
    return this.src.slice(a.pos, b.end).trim();
  };
  P.lineTxt = function (i0) {
    var j = i0; while (this.t[j + 1] && !this.isNlTok(this.t[j + 1])) j++;
    return this.src.slice(this.t[i0].pos, this.t[j].end).trim();
  };
  P.termAt = function (terms) {
    for (var i = 0; i < terms.length; i++) {
      var parts = terms[i].split(' '), ok = true;
      for (var j = 0; j < parts.length; j++) { var tk = this.peek(j); if (!(tk.t === 'id' && tk.k === parts[j])) { ok = false; break; } }
      if (ok) return terms[i];
    }
    return null;
  };
  P.outerTerm = function () {
    for (var i = this.stack.length - 2; i >= 0; i--) if (this.termAt(this.stack[i].terms)) return this.stack[i];
    return null;
  };
  P.errMissing = function (frame) {
    this.add(120, frame.open, [frame.name, frame.openName, frame.open.line]);
  };

  P.program = function () {
    var prog = { main: null, subs: [] }, strayFlagged = false;
    for (;;) {
      this.skipNl();
      var t = this.peek();
      if (t.t === 'eof') break;
      if (t.t === 'id' && (t.k === 'ALGORITMO' || t.k === 'PROCESO')) {
        strayFlagged = false;
        try {
          var m = this.main();
          if (prog.main) this.add(123, t); else prog.main = m;
        } catch (e) { if (!e.__syn) throw e; this.skipLine(); }
      } else if (t.t === 'id' && (t.k === 'SUBPROCESO' || t.k === 'FUNCION')) {
        strayFlagged = false;
        try { prog.subs.push(this.sub()); } catch (e) { if (!e.__syn) throw e; this.skipLine(); }
      } else {
        if (t.t === 'id' && CLOSERS[t.k]) this.add(121, t, [t.v]);
        else if (!strayFlagged) { this.add(124, t); strayFlagged = true; }
        this.skipLine();
      }
    }
    return prog;
  };

  P.main = function () {
    var h = this.next(), i0 = this.p, name = 'SIN_TITULO';
    if (!this.isNlTok(this.peek())) {
      var a = this.peek();
      if (a.t !== 'id' || RESERVED[a.k]) this.fail(111, a, ['el nombre del algoritmo']);
      this.next(); name = a.v;
      if (this.isOp(this.peek(), '<-') || this.isOp(this.peek(), '=')) {
        this.next(); var b = this.peek();
        if (b.t !== 'id') this.fail(111, b, ['el nombre del algoritmo']);
        this.next(); name = b.v;
      }
      this.endStmt();
    }
    var node = { k: 'main', line: h.line, name: name, body: [], endLine: h.line, text: this.src.slice(h.pos, this.t[this.p - 1].end) };
    var frame = { terms: ['FINALGORITMO', 'FINPROCESO'], open: h, name: 'FinAlgoritmo', openName: h.v };
    var res = this.block(frame);
    node.body = res.stmts;
    if (res.term) { node.endLine = this.peek().line; this.next(); this.skipLine(); }
    else node.endLine = this.t[this.p].line;
    return node;
  };

  P.sub = function () {
    var h = this.next(), t = this.peek();
    if (t.t !== 'id' || RESERVED[t.k]) this.fail(111, t, ['el nombre del subproceso']);
    this.next();
    var ret = null, name = t.u, shown = t.v;
    if (this.isOp(this.peek(), '<-') || this.isOp(this.peek(), '=')) {
      this.next(); var n2 = this.peek();
      if (n2.t !== 'id' || RESERVED[n2.k]) this.fail(111, n2, ['el nombre de la función']);
      this.next(); ret = t.u; name = n2.u; shown = n2.v;
    }
    var params = [];
    if (this.isOp(this.peek(), '(')) {
      this.next();
      if (!this.isOp(this.peek(), ')')) {
        for (;;) {
          var pt = this.peek();
          if (pt.t === 'id' && RESERVED[pt.k]) this.fail(150, pt, [pt.v]);
          if (pt.t !== 'id') this.fail(111, pt, ['el nombre del argumento']);
          this.next();
          var ref = false;
          if (this.isKw(this.peek(), 'POR')) {
            this.next(); var md = this.peek();
            if (this.isKw(md, 'REFERENCIA')) ref = true;
            else if (!this.isKw(md, 'VALOR')) this.fail(111, md, ['Valor o Referencia']);
            this.next();
          }
          params.push({ n: pt.u, ref: ref });
          if (this.isOp(this.peek(), ',')) { this.next(); continue; }
          break;
        }
      }
      if (!this.isOp(this.peek(), ')')) this.fail(112, this.peek());
      this.next();
    }
    this.endStmt();
    var node = { k: 'sub', line: h.line, name: name, shown: shown, ret: ret, params: params, body: [], endLine: h.line, isFun: h.k === 'FUNCION',
      text: this.src.slice(h.pos, this.t[this.p - 1].end) };
    var frame = { terms: ['FINSUBPROCESO', 'FINFUNCION'], open: h, name: h.k === 'FUNCION' ? 'FinFuncion' : 'FinSubProceso', openName: h.v };
    var res = this.block(frame);
    node.body = res.stmts;
    if (res.term) { node.endLine = this.peek().line; this.next(); this.skipLine(); }
    else node.endLine = this.t[this.p].line;
    return node;
  };

  P.block = function (frame) {
    var list = [], res = { stmts: list, term: null };
    this.stack.push(frame);
    for (;;) {
      this.skipNl();
      var t = this.peek();
      if (t.t === 'eof') { this.errMissing(frame); break; }
      var m = this.termAt(frame.terms);
      if (m) { res.term = m; break; }
      if (this.outerTerm()) { this.errMissing(frame); break; }
      if (t.t === 'id' && CLOSERS[t.k]) { this.add(121, t, [CLOSER_NAMES[t.k] || t.v]); this.skipLine(); continue; }
      var s = this.stmtSafe();
      if (s) list.push(s);
    }
    this.stack.pop();
    return res;
  };

  P.stmtSafe = function () {
    try { return this.stmt(); }
    catch (e) { if (e && e.__syn) { this.skipLine(); return null; } throw e; }
  };

  P.lineHasColon = function () {
    for (var j = this.p; j < this.t.length; j++) {
      var t = this.t[j];
      if (t.t === 'nl' || t.t === 'eof') return false;
      if (t.t === 'op' && t.v === ':') return true;
    }
    return false;
  };

  P.lvalue = function () {
    var t = this.peek();
    if (t.t === 'id' && RESERVED[t.k]) this.fail(150, t, [t.v]);
    if (t.t !== 'id') this.fail(111, t, ['una variable']);
    this.next();
    var lv = { n: t.u, shown: t.v, idx: null, line: t.line };
    if (this.isOp(this.peek(), '[') || this.isOp(this.peek(), '(')) {
      var close = this.peek().v === '[' ? ']' : ')';
      this.next(); lv.idx = this.args(close);
      if (!lv.idx.length) this.fail(114, this.peek());
    }
    return lv;
  };

  P.stmt = function () {
    var t = this.peek(), node, i0;
    if (t.t !== 'id') this.fail(110, t, [this.src.slice(t.pos, t.end)]);
    var self = this;
    function header() { // expresión de condición + palabra opcional + fin de encabezado
      var e0 = self.p, e = self.expr();
      return { e: e, text: self.txt(e0) };
    }
    function optKw(kw, shown) {
      if (self.isKw(self.peek(), kw)) self.next();
      else if (!self.prof.optKw) self.fail(111, self.peek(), [shown]);
    }
    switch (t.k) {
      case 'DEFINIR': {
        this.next(); var names = [], shownNames = [];
        for (;;) {
          var nt = this.peek();
          if (nt.t === 'id' && RESERVED[nt.k]) this.fail(150, nt, [nt.v]);
          if (nt.t !== 'id') this.fail(111, nt, ['el nombre de una variable']);
          this.next(); names.push(nt.u); shownNames.push(nt.v);
          if (this.isOp(this.peek(), ',')) { this.next(); continue; }
          break;
        }
        if (!this.isKw(this.peek(), 'COMO')) this.fail(111, this.peek(), ['Como']);
        this.next();
        var ty = this.peek();
        if (ty.t !== 'id' || !TYPES[ty.k]) this.fail(111, ty, ['un tipo de dato (Entero, Real, Logico, Caracter, Texto)']);
        this.next();
        this.endStmt();
        return { k: 'def', line: t.line, endLine: t.line, names: names, shownNames: shownNames, type: TYPES[ty.k] };
      }
      case 'DIMENSION': {
        this.next(); var items = [];
        for (;;) {
          var dt = this.peek();
          if (dt.t !== 'id' || RESERVED[dt.k]) this.fail(111, dt, ['el nombre del arreglo']);
          this.next();
          var op = this.peek();
          if (!(this.isOp(op, '[') || this.isOp(op, '('))) this.fail(111, op, ['"[" y el tamaño']);
          this.next();
          var dims = this.args(op.v === '[' ? ']' : ')');
          if (!dims.length) this.fail(114, this.peek());
          items.push({ n: dt.u, dims: dims });
          if (this.isOp(this.peek(), ',')) { this.next(); continue; }
          break;
        }
        this.endStmt();
        return { k: 'dim', line: t.line, endLine: t.line, items: items };
      }
      case 'ESCRIBIR': case 'IMPRIMIR': case 'MOSTRAR': {
        this.next(); var args = [], nl = true;
        if (this.isKw(this.peek(), 'SIN') && (this.isKw(this.peek(1), 'SALTAR') || this.isKw(this.peek(1), 'BAJAR'))) { this.next(); this.next(); nl = false; }
        if (!this.isNlTok(this.peek()) && !this.isKw(this.peek(), 'SIN')) {
          for (;;) {
            args.push(this.expr());
            if (this.isOp(this.peek(), ',')) { this.next(); continue; }
            break;
          }
        }
        if (this.isKw(this.peek(), 'SIN')) {
          this.next(); var sw = this.peek();
          if (!(this.isKw(sw, 'SALTAR') || this.isKw(sw, 'BAJAR'))) this.fail(111, sw, ['Saltar o Bajar']);
          this.next(); nl = false;
        }
        this.endStmt();
        return { k: 'out', line: t.line, endLine: t.line, args: args, nl: nl, text: this.src.slice(t.pos, this.t[this.p - 1].end) };
      }
      case 'LEER': {
        this.next(); var targets = [];
        for (;;) { targets.push(this.lvalue()); if (this.isOp(this.peek(), ',')) { this.next(); continue; } break; }
        this.endStmt();
        return { k: 'in', line: t.line, endLine: t.line, targets: targets };
      }
      case 'SI': {
        this.next(); var h = header();
        optKw('ENTONCES', 'Entonces'); this.endStmt();
        node = { k: 'if', line: t.line, endLine: t.line, c: h.e, ctext: h.text, a: [], b: null, elseLine: 0 };
        var fr = { terms: ['SINO', 'FINSI'], open: t, name: 'FinSi', openName: 'Si' };
        var r1 = this.block(fr); node.a = r1.stmts;
        if (r1.term === 'SINO') {
          node.elseLine = this.peek().line; this.next(); this.endStmt();
          var r2 = this.block({ terms: ['FINSI'], open: t, name: 'FinSi', openName: 'Si' });
          node.b = r2.stmts;
          if (r2.term) { node.endLine = this.peek().line; this.next(); this.endStmt(); } else node.endLine = this.t[this.p].line;
        } else if (r1.term === 'FINSI') { node.endLine = this.peek().line; this.next(); this.endStmt(); }
        else node.endLine = this.t[this.p].line;
        return node;
      }
      case 'SEGUN': {
        this.next(); var hs = header();
        optKw('HACER', 'Hacer'); this.endStmt();
        node = { k: 'sw', line: t.line, endLine: t.line, e: hs.e, ctext: hs.text, cases: [], def: null, defLine: 0 };
        var sf = { terms: ['FINSEGUN'], open: t, name: 'FinSegun', openName: 'Segun' };
        this.stack.push(sf);
        var cur = null;
        for (;;) {
          this.skipNl(); var x = this.peek();
          if (x.t === 'eof') { this.errMissing(sf); break; }
          if (this.termAt(sf.terms)) { node.endLine = x.line; this.next(); this.skipLine(); break; }
          if (this.outerTerm()) { this.errMissing(sf); break; }
          if (this.isKw(x, 'DE') && this.isKw(this.peek(1), 'OTRO') && this.isKw(this.peek(2), 'MODO')) {
            this.next(); this.next(); this.next();
            if (this.isOp(this.peek(), ':')) this.next();
            node.def = []; node.defLine = x.line; cur = { body: node.def };
            if (!this.isNlTok(this.peek())) { var sd = this.stmtSafe(); if (sd) cur.body.push(sd); }
            continue;
          }
          if (this.lineHasColon()) {
            var vals = [], l0 = this.p;
            try {
              for (;;) { vals.push(this.expr()); if (this.isOp(this.peek(), ',')) { this.next(); continue; } break; }
              if (!this.isOp(this.peek(), ':')) this.fail(111, this.peek(), ['":" después del valor del caso']);
            } catch (er) { if (er.__syn) { this.skipLine(); continue; } throw er; }
            var ltxt = this.txt(l0);
            this.next();
            cur = { vals: vals, body: [], line: x.line, ltext: ltxt };
            node.cases.push(cur);
            if (!this.isNlTok(this.peek())) { var s1 = this.stmtSafe(); if (s1) cur.body.push(s1); }
            continue;
          }
          if (CLOSERS[x.k]) { this.add(121, x, [CLOSER_NAMES[x.k] || x.v]); this.skipLine(); continue; }
          if (!cur) { this.add(111, x, ['un valor de caso seguido de ":" (por ejemplo  1:  )']); this.skipLine(); continue; }
          var s2 = this.stmtSafe(); if (s2) cur.body.push(s2);
        }
        this.stack.pop();
        return node;
      }
      case 'MIENTRAS': {
        this.next(); var hw = header();
        optKw('HACER', 'Hacer'); this.endStmt();
        node = { k: 'wh', line: t.line, endLine: t.line, c: hw.e, ctext: hw.text, body: [] };
        var rw = this.block({ terms: ['FINMIENTRAS'], open: t, name: 'FinMientras', openName: 'Mientras' });
        node.body = rw.stmts;
        if (rw.term) { node.endLine = this.peek().line; this.next(); this.endStmt(); } else node.endLine = this.t[this.p].line;
        return node;
      }
      case 'REPETIR': {
        this.next(); this.endStmt();
        node = { k: 'rp', line: t.line, endLine: t.line, body: [], c: null, until: true, ctext: '', condLine: t.line };
        var rr = this.block({ terms: ['HASTA', 'MIENTRAS QUE'], open: t, name: 'Hasta Que', openName: 'Repetir' });
        node.body = rr.stmts;
        if (rr.term) {
          node.condLine = this.peek().line;
          var isUntil = rr.term === 'HASTA';
          this.next(); if (!isUntil) this.next(); else if (this.isKw(this.peek(), 'QUE')) this.next();
          var hr = header();
          node.c = hr.e; node.ctext = hr.text; node.until = isUntil; node.endLine = node.condLine;
          this.endStmt();
        } else node.endLine = this.t[this.p].line;
        if (!node.c) node.c = { k: 'bool', v: true };
        return node;
      }
      case 'PARA': {
        this.next(); var vt = this.peek();
        if (vt.t === 'id' && RESERVED[vt.k]) this.fail(150, vt, [vt.v]);
        if (vt.t !== 'id') this.fail(111, vt, ['la variable de control del Para']);
        this.next();
        if (!(this.isOp(this.peek(), '<-') || this.isOp(this.peek(), ':=') || this.isOp(this.peek(), '='))) this.fail(111, this.peek(), ['"<-" y el valor inicial']);
        this.next();
        var a0 = this.p, ea = this.expr();
        if (!this.isKw(this.peek(), 'HASTA')) this.fail(111, this.peek(), ['Hasta']);
        var atxt = this.txt(a0);
        this.next(); var b0 = this.p, eb = this.expr(), btxt = this.txt(b0), es = null, stxt = '';
        if (this.isKw(this.peek(), 'CON')) {
          this.next();
          if (!this.isKw(this.peek(), 'PASO')) this.fail(111, this.peek(), ['Paso']);
          this.next(); var s0 = this.p; es = this.expr(); stxt = this.txt(s0);
        }
        optKw('HACER', 'Hacer'); this.endStmt();
        node = { k: 'for', line: t.line, endLine: t.line, v: vt.u, vshown: vt.v, a: ea, b: eb, s: es, atext: atxt, btext: btxt, stext: stxt, body: [] };
        var rf = this.block({ terms: ['FINPARA'], open: t, name: 'FinPara', openName: 'Para' });
        node.body = rf.stmts;
        if (rf.term) { node.endLine = this.peek().line; this.next(); this.endStmt(); } else node.endLine = this.t[this.p].line;
        return node;
      }
      case 'ESPERAR': {
        this.next(); var w = this.peek();
        if (this.isKw(w, 'TECLA')) { this.next(); this.endStmt(); return { k: 'wait', line: t.line, endLine: t.line, key: true }; }
        var we = this.expr(), un = this.peek();
        if (!(un.t === 'id' && /^(SEGUNDOS?|MILISEGUNDOS?)$/.test(un.k))) this.fail(111, un, ['Segundos o Milisegundos']);
        this.next(); this.endStmt();
        return { k: 'wait', line: t.line, endLine: t.line, key: false, e: we, mult: /^MILI/.test(un.k) ? 1 : 1000 };
      }
      case 'LIMPIAR': case 'BORRAR': {
        this.next();
        if (!this.isKw(this.peek(), 'PANTALLA')) this.fail(111, this.peek(), ['Pantalla']);
        this.next(); this.endStmt();
        return { k: 'cls', line: t.line, endLine: t.line };
      }
      case 'RETORNAR': {
        this.next(); var re = null;
        if (!this.isNlTok(this.peek())) re = this.expr();
        this.endStmt();
        return { k: 'ret', line: t.line, endLine: t.line, e: re };
      }
    }
    if (RESERVED[t.k]) this.fail(110, t, [t.v]);
    // asignación o llamada
    var nx = this.peek(1);
    var isAssign = function (o) { return o.t === 'op' && (o.v === '<-' || o.v === ':=' || o.v === '='); };
    if (isAssign(nx) || this.isOp(nx, '[') || this.isOp(nx, '(')) {
      var save = this.p;
      if (this.isOp(nx, '(')) { // ¿llamada o arreglo con paréntesis?
        this.next(); this.next(); var as0 = this.args(')');
        if (isAssign(this.peek())) { this.p = save; }
        else { this.endStmt(); return { k: 'call', line: t.line, endLine: t.line, n: t.u, shown: t.v, args: as0 }; }
      }
      var lv = this.lvalue(), op = this.peek();
      if (!isAssign(op)) this.fail(111, op, ['"<-" (asignación)']);
      if (op.v === '=' && !this.prof.eqAssign) this.fail(111, op, ['"<-" (en el perfil Estricto "=" no es asignación)']);
      this.next();
      var ex = this.expr();
      this.endStmt();
      return { k: 'asg', line: t.line, endLine: t.line, t: lv, e: ex, text: this.src.slice(t.pos, this.t[this.p - 1].end) };
    }
    if (this.isNlTok(nx)) { this.next(); return { k: 'call', line: t.line, endLine: t.line, n: t.u, shown: t.v, args: [] }; }
    this.fail(110, t, [t.v]);
  };
  P.args = function (close) {
    var list = [];
    if (this.isOp(this.peek(), close)) { this.next(); return list; }
    for (;;) {
      list.push(this.expr());
      if (this.isOp(this.peek(), ',')) { this.next(); continue; }
      break;
    }
    if (!this.isOp(this.peek(), close)) this.fail(close === ']' ? 113 : 112, this.peek());
    this.next();
    return list;
  };

  /* expresiones */
  function isBin(t, k, alt) { return (t.t === 'id' && t.k === k) || (t.t === 'op' && alt.indexOf(t.v) >= 0); }
  P.expr = function () { return this.eOr(); };
  P.eOr = function () {
    var l = this.eAnd();
    while (isBin(this.peek(), 'O', ['||', '|'])) { this.next(); l = { k: 'bin', op: 'O', l: l, r: this.eAnd() }; }
    return l;
  };
  P.eAnd = function () {
    var l = this.eNot();
    while (isBin(this.peek(), 'Y', ['&&', '&'])) { this.next(); l = { k: 'bin', op: 'Y', l: l, r: this.eNot() }; }
    return l;
  };
  P.eNot = function () {
    if (isBin(this.peek(), 'NO', ['~', '!'])) { this.next(); return { k: 'un', op: 'NO', e: this.eNot() }; }
    return this.eRel();
  };
  var RELS = { '=': '=', '==': '=', '<>': '<>', '!=': '<>', '<': '<', '>': '>', '<=': '<=', '>=': '>=' };
  P.eRel = function () {
    var l = this.eAdd();
    while (this.peek().t === 'op' && RELS[this.peek().v]) { var o = this.next().v; l = { k: 'bin', op: RELS[o], l: l, r: this.eAdd() }; }
    return l;
  };
  P.eAdd = function () {
    var l = this.eMul();
    while (this.isOp(this.peek(), '+') || this.isOp(this.peek(), '-')) { var o = this.next().v; l = { k: 'bin', op: o, l: l, r: this.eMul() }; }
    return l;
  };
  P.eMul = function () {
    var l = this.eUn();
    for (;;) {
      var t = this.peek();
      if (this.isOp(t, '*') || this.isOp(t, '/') || this.isOp(t, '%') || this.isKw(t, 'MOD')) {
        this.next(); l = { k: 'bin', op: (t.v === '%' || t.k === 'MOD') ? 'MOD' : t.v, l: l, r: this.eUn() };
      } else break;
    }
    return l;
  };
  P.eUn = function () {
    if (this.isOp(this.peek(), '-')) { this.next(); return { k: 'un', op: '-', e: this.eUn() }; }
    if (this.isOp(this.peek(), '+')) { this.next(); return this.eUn(); }
    return this.ePow();
  };
  P.ePow = function () {
    var b = this.prim();
    if (this.isOp(this.peek(), '^')) { this.next(); return { k: 'bin', op: '^', l: b, r: this.eUn() }; }
    return b;
  };
  P.prim = function () {
    var t = this.peek();
    if (t.t === 'num') { this.next(); return { k: 'num', v: t.v }; }
    if (t.t === 'str') { this.next(); return { k: 'str', v: t.v }; }
    if (t.t === 'id') {
      if (t.k === 'VERDADERO') { this.next(); return { k: 'bool', v: true }; }
      if (t.k === 'FALSO') { this.next(); return { k: 'bool', v: false }; }
      if (RESERVED[t.k]) this.fail(114, t);
      this.next();
      if (this.isOp(this.peek(), '(')) { this.next(); return { k: 'call', n: t.u, shown: t.v, args: this.args(')'), line: t.line }; }
      if (this.isOp(this.peek(), '[')) { this.next(); return { k: 'idx', n: t.u, shown: t.v, args: this.args(']'), line: t.line }; }
      return { k: 'var', n: t.u, shown: t.v, line: t.line };
    }
    if (this.isOp(t, '(')) {
      this.next(); var e = this.expr();
      if (!this.isOp(this.peek(), ')')) this.fail(112, this.peek());
      this.next(); return { k: 'par', e: e };
    }
    this.fail(114, t);
  };

  /* ------------------------------------------------------------------ análisis semántico */
  function analyze(prog, prof, errors) {
    var funcs = {}, units = [];
    if (!prog.main) { errors.push(mkErr(122, { line: 1, inst: 1 })); }
    prog.subs.forEach(function (s) {
      if (funcs[s.name] || FUNCS[strip(s.name)] || strip(s.name) === 'PI') errors.push(mkErr(143, { line: s.line }, [s.shown]));
      else funcs[s.name] = s;
    });
    function mkUnit(node, kind) {
      var u = { kind: kind, name: node.name || node.shown, node: node, params: node.params || [], ret: node.ret || null, body: node.body, vars: {} };
      node.unit = u;
      u.params.forEach(function (p) { var v = G(u, p.n, node.line); v.param = true; v.ref = p.ref; v.assigned = true; });
      if (u.ret) { var rv = G(u, u.ret, node.line); rv.isRet = true; rv.defined = true; }
      return u;
    }
    function G(u, n, line) {
      var v = u.vars[n];
      if (!v) v = u.vars[n] = { n: n, type: null, arr: false, dims: null, param: false, ref: false, assigned: false, defined: false, passed: false, isRet: false, line: line };
      return v;
    }
    if (prog.main) units.push(mkUnit(prog.main, 'main'));
    prog.subs.forEach(function (s) { units.push(mkUnit(s, 'sub')); });

    function declExpr(u, e) {
      if (!e) return;
      switch (e.k) {
        case 'bin': declExpr(u, e.l); declExpr(u, e.r); break;
        case 'un': case 'par': declExpr(u, e.e); break;
        case 'idx': G(u, e.n, e.line).arr = true; e.args.forEach(function (a) { declExpr(u, a); }); break;
        case 'call':
          e.args.forEach(function (a) { if (a.k === 'var' && funcs[e.n]) G(u, a.n, a.line).passed = true; declExpr(u, a); });
          break;
      }
    }
    function declWalk(u, list) {
      list.forEach(function (s) {
        switch (s.k) {
          case 'def': s.names.forEach(function (n) { var v = G(u, n, s.line); v.type = s.type; v.defined = true; }); break;
          case 'dim': s.items.forEach(function (it) { var v = G(u, it.n, s.line); v.arr = true; v.dims = it.dims.length; v.defined = true; v.assigned = true; it.dims.forEach(function (d) { declExpr(u, d); }); }); break;
          case 'asg': var v1 = G(u, s.t.n, s.line); if (s.t.idx) { v1.arr = true; s.t.idx.forEach(function (d) { declExpr(u, d); }); } else v1.assigned = true; declExpr(u, s.e); break;
          case 'in': s.targets.forEach(function (lv) { var v2 = G(u, lv.n, s.line); if (lv.idx) { v2.arr = true; lv.idx.forEach(function (d) { declExpr(u, d); }); } else v2.assigned = true; }); break;
          case 'out': s.args.forEach(function (a) { declExpr(u, a); }); break;
          case 'if': declExpr(u, s.c); declWalk(u, s.a); if (s.b) declWalk(u, s.b); break;
          case 'sw': declExpr(u, s.e); s.cases.forEach(function (c) { c.vals.forEach(function (x) { declExpr(u, x); }); declWalk(u, c.body); }); if (s.def) declWalk(u, s.def); break;
          case 'wh': declExpr(u, s.c); declWalk(u, s.body); break;
          case 'rp': declWalk(u, s.body); declExpr(u, s.c); break;
          case 'for': var v3 = G(u, s.v, s.line); v3.assigned = true; declExpr(u, s.a); declExpr(u, s.b); declExpr(u, s.s); declWalk(u, s.body); break;
          case 'wait': declExpr(u, s.e); break;
          case 'ret': declExpr(u, s.e); break;
          case 'call': s.args.forEach(function (a) { if (a.k === 'var' && funcs[s.n]) G(u, a.n, a.line).passed = true; declExpr(u, a); }); break;
        }
      });
    }
    units.forEach(function (u) { declWalk(u, u.body); });

    /* verificación */
    var strictSeen = {};
    function add(code, line, args) { errors.push(mkErr(code, { line: line, inst: 1 }, args)); }
    function litType(e) { return e.k === 'num' ? 'num' : e.k === 'str' ? 'str' : e.k === 'bool' ? 'bool' : null; }

    function resolveCall(u, e, asStmt, line) {
      var nm = e.n, ln = e.line || line, fn = funcs[nm];
      if (fn) {
        e.fn = fn;
        if (fn.params.length !== e.args.length) add(141, ln, [fn.shown, fn.params.length, e.args.length]);
        if (!asStmt && !fn.ret) add(142, ln, [fn.shown]);
        e.args.forEach(function (a) { chkExpr(u, a, true, ln); });
        return;
      }
      var b = FUNCS[strip(nm)];
      if (b) {
        e.bi = strip(nm);
        if (e.args.length < b[0] || e.args.length > b[1]) add(141, ln, [e.shown || nm, b[0], e.args.length]);
        e.args.forEach(function (a) { chkExpr(u, a, false, ln); });
        return;
      }
      var v = u.vars[nm];
      if (!asStmt && v && (v.arr || v.param)) { e.k = 'idx'; chkExpr(u, e, false, ln); return; }
      add(140, ln, [e.shown || nm]);
      e.args.forEach(function (a) { chkExpr(u, a, true, ln); });
    }
    function chkIdx(u, name, shown, args, ln) {
      var v = u.vars[name];
      if (!v || (v.dims === null && !v.param)) add(146, ln, [shown]);
      else if (v.dims !== null && v.dims !== args.length) add(145, ln, [shown, v.dims, args.length]);
      args.forEach(function (a) { chkExpr(u, a, false, ln); });
    }
    function chkExpr(u, e, isArg, line) {
      if (!e) return;
      var ln = e.line || line;
      switch (e.k) {
        case 'num': case 'str': case 'bool': return;
        case 'var': {
          var v = u.vars[e.n];
          if (!v) { if (e.n === 'PI') { e.pi = true; return; } add(prof.implicitVars ? 131 : 130, ln, [e.shown || e.n]); return; }
          if (v.arr && !isArg) add(144, ln, [e.shown || e.n]);
          return;
        }
        case 'idx': chkIdx(u, e.n, e.shown, e.args, ln); return;
        case 'call': resolveCall(u, e, false, ln); return;
        case 'bin': chkExpr(u, e.l, false, ln); chkExpr(u, e.r, false, ln); return;
        case 'un': case 'par': chkExpr(u, e.e, false, ln); return;
      }
    }
    function chkTarget(u, lv, line) {
      var v = u.vars[lv.n];
      if (!prof.implicitVars && v && !v.defined && !v.param && !v.isRet) { /* se reporta aparte */ }
      if (lv.idx) chkIdx(u, lv.n, lv.shown || lv.n, lv.idx, lv.line || line);
      else if (v && v.arr && !v.param) add(144, lv.line || line, [lv.shown || lv.n]);
    }
    function chkBody(u, list) { list.forEach(function (s) { chkStmt(u, s); }); }
    function chkStmt(u, s) {
      switch (s.k) {
        case 'def': return;
        case 'dim': s.items.forEach(function (it) { it.dims.forEach(function (d) { chkExpr(u, d, false, s.line); }); }); return;
        case 'asg': {
          chkTarget(u, s.t, s.line); chkExpr(u, s.e, false, s.line);
          var v = u.vars[s.t.n], lt = litType(s.e);
          if (v && v.type && lt && !s.t.idx || (v && v.type && lt && s.t.idx)) {
            var ok = (v.type === 'I' || v.type === 'R') ? lt === 'num' : v.type === 'L' ? lt === 'bool' : lt === 'str';
            if (!ok) add(132, s.line, [s.t.shown || s.t.n, TYPENAME[v.type], lt === 'num' ? 'numérico' : lt === 'str' ? 'de texto' : 'lógico']);
          }
          return;
        }
        case 'in': s.targets.forEach(function (lv) { chkTarget(u, lv, s.line); }); return;
        case 'out': s.args.forEach(function (a) { chkExpr(u, a, false, s.line); }); return;
        case 'if': chkExpr(u, s.c, false, s.line); chkBody(u, s.a); if (s.b) chkBody(u, s.b); return;
        case 'sw': chkExpr(u, s.e, false, s.line); s.cases.forEach(function (c) { c.vals.forEach(function (x) { chkExpr(u, x, false, c.line); }); chkBody(u, c.body); }); if (s.def) chkBody(u, s.def); return;
        case 'wh': chkExpr(u, s.c, false, s.line); chkBody(u, s.body); return;
        case 'rp': chkBody(u, s.body); chkExpr(u, s.c, false, s.condLine); return;
        case 'for': chkExpr(u, s.a, false, s.line); chkExpr(u, s.b, false, s.line); chkExpr(u, s.s, false, s.line); chkBody(u, s.body); return;
        case 'wait': chkExpr(u, s.e, false, s.line); return;
        case 'ret': chkExpr(u, s.e, false, s.line); return;
        case 'call': resolveCall(u, s, true, s.line); return;
      }
    }
    units.forEach(function (u) {
      if (!prof.implicitVars) {
        Object.keys(u.vars).forEach(function (n) {
          var v = u.vars[n];
          if (!v.defined && !v.param && !v.isRet) add(130, v.line, [n]);
        });
      }
      if (u.ret && !u.vars[u.ret].assigned) { /* la variable de retorno fue creada como definida; ver si se asigna */ }
      chkBody(u, u.body);
    });
    // la variable de retorno debe asignarse
    units.forEach(function (u) {
      if (u.ret) {
        var assigned = false;
        (function look(list) {
          list.forEach(function (s) {
            if ((s.k === 'asg' && s.t.n === u.ret) || (s.k === 'in' && s.targets.some(function (t) { return t.n === u.ret; })) || (s.k === 'for' && s.v === u.ret)) assigned = true;
            if (s.k === 'ret') assigned = true;
            ['a', 'b', 'body', 'def'].forEach(function (key) { if (s[key] && Array.isArray(s[key])) look(s[key]); });
            if (s.cases) s.cases.forEach(function (c) { look(c.body); });
          });
        })(u.body);
        if (!assigned) add(147, u.node.line, [u.node.shown, u.ret]);
      }
    });
    return { units: units, funcs: funcs };
  }

  /* ------------------------------------------------------------------ generación de JavaScript */
  function generate(prog, an, prof, debug) {
    var tmp = 0;
    var BI = { '+': 'add', '-': 'sub', '*': 'mul', '/': 'div', 'MOD': 'mod', '^': 'pow', '=': 'eq', '<>': 'ne', '<': 'lt', '>': 'gt', '<=': 'le', '>=': 'ge' };
    function isRef(v) { return v.param && v.ref && !v.arr; }
    function tcode(v) { return v.type || null; }
    function rawVar(u, n) { var v = u.vars[n]; return v && isRef(v) ? 'R_' + n + '.v' : 'V_' + n; }
    function readVar(u, n) {
      var raw = rawVar(u, n);
      return '(' + raw + '!==undefined?' + raw + ':$.ue(' + esc(u.vars[n].n) + '))';
    }
    function isBool(e) {
      if (e.k === 'bool') return true;
      if (e.k === 'par') return isBool(e.e);
      if (e.k === 'un' && e.op === 'NO') return isBool(e.e);
      if (e.k === 'bin') { if (RELOPS[e.op]) return true; if (e.op === 'Y' || e.op === 'O') return isBool(e.l) && isBool(e.r); }
      return false;
    }
    var RELOPS = { '=': 1, '<>': 1, '<': 1, '>': 1, '<=': 1, '>=': 1 };
    function ex(u, e) {
      switch (e.k) {
        case 'num': return String(e.v);
        case 'str': return esc(e.v);
        case 'bool': return e.v ? 'true' : 'false';
        case 'par': return '(' + ex(u, e.e) + ')';
        case 'var': {
          if (e.pi) return 'Math.PI';
          var v = u.vars[e.n];
          if (v.arr && !isRef(v)) return 'V_' + e.n;
          return readVar(u, e.n);
        }
        case 'idx': {
          var a = rawVar(u, e.n), nm = esc(u.vars[e.n].n);
          if (e.args.length === 1) return '$.ag1(' + a + ',' + nm + ',' + ex(u, e.args[0]) + ')';
          if (e.args.length === 2) return '$.ag2(' + a + ',' + nm + ',' + ex(u, e.args[0]) + ',' + ex(u, e.args[1]) + ')';
          return '$.agn(' + a + ',' + nm + ',[' + e.args.map(function (x) { return ex(u, x); }).join(',') + '])';
        }
        case 'call': return callEx(u, e);
        case 'un': return e.op === 'NO' ? '(!$.b(' + ex(u, e.e) + '))' : '$.neg(' + ex(u, e.e) + ')';
        case 'bin':
          if (e.op === 'Y') return '($.b(' + ex(u, e.l) + ')&&$.b(' + ex(u, e.r) + '))';
          if (e.op === 'O') return '($.b(' + ex(u, e.l) + ')||$.b(' + ex(u, e.r) + '))';
          return '$.' + BI[e.op] + '(' + ex(u, e.l) + ',' + ex(u, e.r) + ')';
      }
      return 'undefined';
    }
    function cond(u, e) { return isBool(e) ? ex(u, e) : '$.c(' + ex(u, e) + ')'; }
    function callEx(u, e) {
      if (e.bi) return '$.f.' + e.bi + '(' + e.args.map(function (a) { return ex(u, a); }).join(',') + ')';
      var fn = e.fn, fu = fn.unit;
      var args = e.args.map(function (a, i) {
        var p = fu.params[i], pv = p && fu.vars[p.n];
        if (pv && isRef(pv)) {
          if (a.k === 'var' && !a.pi) {
            var av = u.vars[a.n];
            if (av.arr && !isRef(av)) return 'V_' + a.n;
            if (isRef(av)) return 'R_' + a.n;
            return 'new $.Ref(function(){return V_' + a.n + '},function(__x){V_' + a.n + '=__x})';
          }
          if (a.k === 'idx') {
            var s = setIdx(u, a, '__x', null);
            return 'new $.Ref(function(){return ' + ex(u, a) + '},function(__x){' + s + '})';
          }
          return 'new $.Box(' + ex(u, a) + ')';
        }
        if (a.k === 'var' && !a.pi) { var v2 = u.vars[a.n]; if (v2.arr && !isRef(v2)) return 'V_' + a.n; }
        return ex(u, a);
      });
      return '$.r(await F_' + fn.name + '(' + args.join(',') + '),' + (e.line || 0) + ')';
    }
    function setIdx(u, lv, valJs, tc) {
      var a = rawVar(u, lv.n), nm = esc(u.vars[lv.n].n), t = tc ? esc(tc) : 'null';
      if (lv.idx ? lv.idx.length === 1 : lv.args.length === 1) { var i1 = (lv.idx || lv.args)[0]; return '$.as1(' + a + ',' + nm + ',' + valJs + ',' + ex(u, i1) + ',' + t + ');'; }
      var ix = lv.idx || lv.args;
      if (ix.length === 2) return '$.as2(' + a + ',' + nm + ',' + valJs + ',' + ex(u, ix[0]) + ',' + ex(u, ix[1]) + ',' + t + ');';
      return '$.asn(' + a + ',' + nm + ',' + valJs + ',[' + ix.map(function (x) { return ex(u, x); }).join(',') + '],' + t + ');';
    }
    function chk(v, val) {
      if (!v.type || v.param) return val;
      return '$.t' + v.type.toLowerCase() + '(' + val + ',' + esc(v.n) + ')';
    }
    var TICK = 'if((++$.t&4095)===0)await $.y();';
    function pre(s) { return '$.l=' + s.line + ';' + (debug ? 'await $.step(' + s.line + ');' : ''); }
    function body(u, list) { return list.map(function (s) { return st(u, s); }).join('\n'); }
    function st(u, s) {
      switch (s.k) {
        case 'def': return pre(s);
        case 'dim': return pre(s) + s.items.map(function (it) {
          var v = u.vars[it.n];
          return 'V_' + it.n + '=$.dim(' + esc(it.n) + ',[' + it.dims.map(function (d) { return ex(u, d); }).join(',') + '],' + (v.type ? esc(v.type) : 'null') + ');';
        }).join('');
        case 'asg': {
          var v = u.vars[s.t.n];
          if (s.t.idx) return pre(s) + setIdx(u, s.t, ex(u, s.e), v.type && !v.param ? v.type : null);
          return pre(s) + rawVar(u, s.t.n) + '=' + chk(v, ex(u, s.e)) + ';';
        }
        case 'out': return pre(s) + '$.out([' + s.args.map(function (a) { return ex(u, a); }).join(',') + '],' + (s.nl ? 'true' : 'false') + ');';
        case 'in': return pre(s) + s.targets.map(function (lv) {
          var v = u.vars[lv.n], ty = v.type && !v.param ? esc(v.type) : 'null';
          var shown = esc(lv.shown || lv.n);
          if (lv.idx) return setIdx(u, lv, 'await $.rd(' + shown + ',' + ty + ')', null);
          return rawVar(u, lv.n) + '=await $.rd(' + shown + ',' + ty + ');';
        }).join('');
        case 'if': return pre(s) + 'if(' + cond(u, s.c) + '){\n' + body(u, s.a) + '\n}' + (s.b ? 'else{\n' + body(u, s.b) + '\n}' : '');
        case 'sw': {
          var id = '__s' + (++tmp), out = pre(s) + '{const ' + id + '=' + ex(u, s.e) + ';', first = true;
          s.cases.forEach(function (c) {
            var test = c.vals.map(function (x) { return '$.eq(' + id + ',' + ex(u, x) + ')'; }).join('||');
            out += (first ? '' : 'else ') + 'if(' + test + '){' + (debug ? '$.l=' + c.line + ';await $.step(' + c.line + ');' : '') + '\n' + body(u, c.body) + '\n}';
            first = false;
          });
          if (s.def) out += (first ? '' : 'else ') + '{' + (debug && s.defLine ? '$.l=' + s.defLine + ';await $.step(' + s.defLine + ');' : '') + '\n' + body(u, s.def) + '\n}';
          return out + '}';
        }
        case 'wh':
          if (debug) return 'while(true){$.l=' + s.line + ';await $.step(' + s.line + ');if(!' + cond(u, s.c) + ')break;' + TICK + '\n' + body(u, s.body) + '\n}';
          return '$.l=' + s.line + ';while(' + cond(u, s.c) + '){' + TICK + '\n' + body(u, s.body) + '\n$.l=' + s.line + ';}';
        case 'rp': {
          var cs = (debug ? '$.l=' + s.condLine + ';await $.step(' + s.condLine + ');' : '$.l=' + s.condLine + ';');
          return 'do{' + TICK + '\n' + body(u, s.body) + '\n' + cs + '}while(' + (s.until ? '!' : '') + cond(u, s.c) + ');';
        }
        case 'for': {
          var n = ++tmp, a = '__a' + n, b = '__b' + n, p = '__p' + n, lv = rawVar(u, s.v);
          var stepJs = s.s ? '$.nm(' + ex(u, s.s) + ')' : '(' + a + '>' + b + '?-1:1)';
          return '$.l=' + s.line + ';{let ' + a + '=$.nm(' + ex(u, s.a) + '),' + b + '=$.nm(' + ex(u, s.b) + '),' + p + '=' + stepJs + ';' +
            'if(' + p + '===0)$.e(311);\n' +
            'for(' + lv + '=' + a + ';' + p + '>0?' + lv + '<=' + b + ':' + lv + '>=' + b + ';' + lv + '+=' + p + '){' + (debug ? '$.l=' + s.line + ';await $.step(' + s.line + ');' : '') + TICK + '\n' +
            body(u, s.body) + '\n}}';
        }
        case 'wait': return pre(s) + (s.key ? 'await $.key();' : 'await $.wait($.nm(' + ex(u, s.e) + ')*' + s.mult + ');');
        case 'cls': return pre(s) + '$.cls();';
        case 'call': return pre(s) + callEx(u, s) + ';';
        case 'ret': return pre(s) + 'return' + (s.e && u.kind !== 'main' ? ' ' + ex(u, s.e) : '') + ';';
      }
      return '';
    }
    function unit(u) {
      var names = Object.keys(u.vars), plist = [], locals = [], prologue = '';
      u.params.forEach(function (p) {
        var v = u.vars[p.n];
        if (isRef(v)) { plist.push('R_' + p.n); prologue += 'R_' + p.n + '=$.rf(R_' + p.n + ');'; }
        else plist.push('V_' + p.n);
      });
      names.forEach(function (n) { if (!u.vars[n].param) locals.push('V_' + n); });
      var snap = '[' + names.map(function (n) {
        var v = u.vars[n];
        return '[' + esc(n) + ',' + (isRef(v) ? 'R_' + n + '.v' : 'V_' + n) + ']';
      }).join(',') + ']';
      var code = (u.kind === 'main' ? 'async function __main(' : 'async function F_' + u.name + '(') + plist.join(',') + '){\n"use strict";' + prologue +
        (locals.length ? 'let ' + locals.join(',') + ';' : '') + 'const __v=function(){return ' + snap + '};';
      var inner = body(u, u.body);
      if (u.kind === 'main') {
        code += (debug ? '$.vs.push(__v);' : '') + 'try{\n' + inner + '\n}finally{$.fin(__v);' + (debug ? '$.vs.pop();' : '') + '}';
      } else {
        var tail = u.ret ? 'if(V_' + u.ret + '===undefined)$.e(309,' + esc(u.node.shown) + ');return V_' + u.ret + ';' : '';
        if (debug) code += '$.vs.push(__v);try{\n' + inner + '\n' + tail + '\n}finally{$.vs.pop();}';
        else code += inner + '\n' + tail;
      }
      return code + '\n}';
    }
    var parts = ['"use strict";'];
    an.units.forEach(function (u) { parts.push(unit(u)); });
    parts.push('return __main();');
    return parts.join('\n');
  }

  /* ------------------------------------------------------------------ explicación (ejecución explicada) */
  function explain(node) {
    if (!node) return '';
    switch (node.k) {
      case 'main': return 'Comienza la ejecución del algoritmo.';
      case 'def': return 'Se declara el tipo de las variables ' + node.names.join(', ') + ' (' + TYPENAME[node.type] + ').';
      case 'dim': return 'Se reserva memoria para el arreglo ' + node.items.map(function (i) { return i.n; }).join(', ') + '.';
      case 'asg': return 'Se calcula la expresión de la derecha y su resultado se guarda en la variable ' + (node.t.shown || node.t.n) + '.';
      case 'out': return 'Se muestra en la pantalla de ejecución el valor de las expresiones indicadas' + (node.nl ? ' y se baja de línea.' : ' sin bajar de línea.');
      case 'in': return 'El programa se detiene y espera que el usuario escriba un valor para ' + node.targets.map(function (t) { return t.shown || t.n; }).join(', ') + '.';
      case 'if': return 'Se evalúa la condición (' + node.ctext + '). Si es verdadera se ejecuta la rama Entonces; si es falsa, la rama SiNo (si existe).';
      case 'sw': return 'Se compara el valor de (' + node.ctext + ') con cada caso hasta encontrar el que coincide.';
      case 'wh': return 'Se evalúa la condición (' + node.ctext + '). Mientras sea verdadera se repite el cuerpo del ciclo.';
      case 'rp': return 'Fin del cuerpo de Repetir: se evalúa la condición (' + node.ctext + ') para decidir si se repite.';
      case 'for': return 'Ciclo Para: la variable ' + node.vshown + ' toma los valores de ' + node.atext + ' hasta ' + node.btext + (node.stext ? ' de a ' + node.stext : '') + '.';
      case 'wait': return node.key ? 'Se espera a que el usuario presione una tecla.' : 'Se pausa la ejecución un tiempo.';
      case 'cls': return 'Se borra la pantalla de ejecución.';
      case 'call': return 'Se invoca el subproceso ' + (node.shown || node.n) + ' con los argumentos indicados.';
      case 'ret': return 'La función devuelve un valor y termina.';
    }
    return '';
  }

  /* ------------------------------------------------------------------ compilación */
  function parse(src, prof) {
    prof = prof || PROFILES.flexible;
    var errors = [], toks = lex(String(src), errors);
    var ps = new Parser(String(src), toks, errors, prof);
    var prog = ps.program();
    return { prog: prog, errors: errors, tokens: toks };
  }
  function sortErrors(errs) {
    var seen = {}, out = [];
    errs.sort(function (a, b) { return a.line - b.line; });
    errs.forEach(function (e) { var k = e.line + ':' + e.code + ':' + e.msg; if (!seen[k]) { seen[k] = 1; out.push(e); } });
    return out;
  }
  function check(src, prof) {
    prof = prof || PROFILES.flexible;
    var r = parse(src, prof), errors = r.errors, an = null;
    if (!errors.length || true) { try { an = analyze(r.prog, prof, errors); } catch (e) { errors.push(mkErr(399, { line: 1 }, [e.message])); } }
    return { errors: sortErrors(errors), prog: r.prog, an: an };
  }
  function compile(src, prof, debug) {
    prof = prof || PROFILES.flexible;
    var c = check(src, prof);
    if (c.errors.length) return { ok: false, errors: c.errors, prog: c.prog };
    var js;
    try {
      js = generate(c.prog, c.an, prof, !!debug);
      var fn = new Function('$', js);
      return { ok: true, errors: [], js: js, fn: fn, prog: c.prog, an: c.an, prof: prof };
    } catch (e) {
      return { ok: false, errors: [mkErr(399, { line: 1 }, [e.message])], prog: c.prog };
    }
  }

  /* ------------------------------------------------------------------ ejecución */
  function Ref(g, s) { this.g = g; this.s = s; }
  Object.defineProperty(Ref.prototype, 'v', { get: function () { return this.g(); }, set: function (x) { this.s(x); } });
  function Box(v) { this.v = v; }

  function PArr(name, dims, base, type, rt) {
    this.name = name; this.dims = dims; this.base = base; this.type = type;
    var n = 1; for (var i = 0; i < dims.length; i++) n *= dims[i];
    if (n > 8000000) rt.e(314, [n]);
    this.d = new Array(n);
  }

  var mc = null;
  function yieldNow() {
    return new Promise(function (r) {
      if (typeof MessageChannel !== 'undefined') {
        if (!mc) mc = new MessageChannel();
        mc.port1.onmessage = function () { r(); };
        mc.port2.postMessage(0);
      } else setTimeout(r, 0);
    });
  }
  function tname(v) { var t = typeof v; return t === 'number' ? 'número' : t === 'string' ? 'texto' : t === 'boolean' ? 'lógico' : v instanceof PArr ? 'arreglo' : 'sin valor'; }

  function Runtime(io, prof) {
    var self = this;
    this.io = io || {}; this.prof = prof || PROFILES.flexible;
    this.l = 0; this.t = 0; this.vs = []; this.last = []; this.stopped = false;
    this.inputs = io && io.inputs ? io.inputs.slice() : [];
    this.stopP = new Promise(function (_, rej) { self._rej = rej; });
    this.stopP.catch(function () {});
    this.Ref = Ref; this.Box = Box;
    this.f = makeFuncs(this);
  }
  var R = Runtime.prototype;
  R.stop = function () { this.stopped = true; if (this._rej) this._rej(STOP); };
  R.e = function (code, args) { throw new PscError(code, args || [], this.l); };
  R.ue = function (n) { this.e(300, [n]); };
  R.r = function (v, line) { this.l = line; return v; };
  R.fin = function (vf) { try { this.last = vf(); } catch (e) { /* ignore */ } };
  R.rf = function (x) { return (x instanceof Ref || x instanceof Box) ? x : new Box(x); };
  R.y = async function () { if (this.stopped) throw STOP; await yieldNow(); if (this.stopped) throw STOP; };
  R.step = async function (line) {
    this.l = line;
    if (this.stopped) throw STOP;
    if (this.io.step) await this.io.step(line, this.vs.length ? this.vs[this.vs.length - 1] : null, this.vs.length);
    if (this.stopped) throw STOP;
  };
  R.snapshot = function () { return this.vs.length ? this.vs[this.vs.length - 1]() : this.last; };
  R.wait = async function (ms) {
    if (this.stopped) throw STOP;
    await Promise.race([new Promise(function (r) { setTimeout(r, Math.max(0, ms)); }), this.stopP]);
  };
  R.key = async function () {
    if (this.stopped) throw STOP;
    if (this.io.key) await Promise.race([this.io.key(), this.stopP]);
  };
  R.cls = function () { if (this.io.clear) this.io.clear(); };
  R.s = function (v) {
    var t = typeof v;
    if (t === 'string') return v;
    if (t === 'number') {
      if (isNaN(v)) return 'NaN';
      if (!isFinite(v)) return v > 0 ? 'Infinito' : '-Infinito';
      if (Math.floor(v) === v) return String(v);
      return String(parseFloat(v.toPrecision(15)));
    }
    if (t === 'boolean') return v ? 'VERDADERO' : 'FALSO';
    if (v instanceof PArr) this.e(313);
    return String(v);
  };
  R.show = function (v) { // para el panel de variables
    if (v === undefined) return '(sin valor)';
    if (v instanceof PArr) {
      var out = [], n = Math.min(v.d.length, 12);
      for (var i = 0; i < n; i++) out.push(v.d[i] === undefined ? '·' : this.s(v.d[i]));
      return 'Arreglo ' + v.dims.join('x') + ': [' + out.join(', ') + (v.d.length > n ? ', …' : '') + ']';
    }
    if (typeof v === 'string') return '"' + v + '"';
    return this.s(v);
  };
  R.out = function (list, nl) {
    var s = '';
    for (var i = 0; i < list.length; i++) s += this.s(list[i]);
    if (this.io.out) this.io.out(s, nl, 'out');
  };
  R.te = function (op, a, b) { this.e(303, [op, tname(a), tname(b)]); };
  R.nm = function (x) { if (typeof x !== 'number') this.e(305, [tname(x)]); return x; };
  R.b = function (x) { if (typeof x !== 'boolean') this.e(303, ['Y/O/NO', tname(x), 'lógico']); return x; };
  R.c = function (x) { if (typeof x !== 'boolean') this.e(304, [tname(x)]); return x; };
  R.add = function (a, b) {
    if (typeof a === 'number' && typeof b === 'number') return a + b;
    if ((typeof a === 'string' || typeof b === 'string') && typeof a !== 'boolean' && typeof b !== 'boolean') return this.s(a) + this.s(b);
    return this.te('+', a, b);
  };
  R.sub = function (a, b) { if (typeof a === 'number' && typeof b === 'number') return a - b; return this.te('-', a, b); };
  R.mul = function (a, b) { if (typeof a === 'number' && typeof b === 'number') return a * b; return this.te('*', a, b); };
  R.div = function (a, b) { if (typeof a !== 'number' || typeof b !== 'number') return this.te('/', a, b); if (b === 0) this.e(301); return a / b; };
  R.mod = function (a, b) { if (typeof a !== 'number' || typeof b !== 'number') return this.te('MOD', a, b); if (b === 0) this.e(301); return a % b; };
  R.pow = function (a, b) { if (typeof a !== 'number' || typeof b !== 'number') return this.te('^', a, b); return Math.pow(a, b); };
  R.neg = function (a) { if (typeof a !== 'number') this.e(305, [tname(a)]); return -a; };
  R.eq = function (a, b) { if (typeof a === typeof b) return a === b; return this.te('=', a, b); };
  R.ne = function (a, b) { if (typeof a === typeof b) return a !== b; return this.te('<>', a, b); };
  R.rel = function (op, a, b) {
    var ta = typeof a;
    if (ta === typeof b && (ta === 'number' || ta === 'string')) {
      return op === '<' ? a < b : op === '>' ? a > b : op === '<=' ? a <= b : a >= b;
    }
    return this.te(op, a, b);
  };
  R.lt = function (a, b) { return this.rel('<', a, b); };
  R.gt = function (a, b) { return this.rel('>', a, b); };
  R.le = function (a, b) { return this.rel('<=', a, b); };
  R.ge = function (a, b) { return this.rel('>=', a, b); };
  /* tipos declarados */
  R.ti = function (v, n) {
    if (typeof v !== 'number') this.e(310, [n, tname(v), 'Entero']);
    if (this.prof.strictTypes && Math.floor(v) !== v) this.e(310, [n, 'real', 'Entero']);
    return v < 0 ? Math.ceil(v) : Math.floor(v);
  };
  R.tr = function (v, n) { if (typeof v !== 'number') this.e(310, [n, tname(v), 'Real']); return v; };
  R.tl = function (v, n) { if (typeof v !== 'boolean') this.e(310, [n, tname(v), 'Lógico']); return v; };
  R.ts = function (v, n) { if (typeof v !== 'string') this.e(310, [n, tname(v), 'Texto']); return v; };
  R.tc = function (v, t, n) { return v; };
  function coerce(rt, t, v, n) {
    return t === 'I' ? rt.ti(v, n) : t === 'R' ? rt.tr(v, n) : t === 'L' ? rt.tl(v, n) : t === 'S' ? rt.ts(v, n) : v;
  }
  /* arreglos */
  R.dim = function (name, sizes, type) {
    for (var i = 0; i < sizes.length; i++) {
      var s = sizes[i];
      if (typeof s !== 'number' || s < 1 || Math.floor(s) !== s) this.e(306, ['Dimension', 'el tamaño de "' + name + '" debe ser un entero positivo']);
    }
    var arr = new PArr(name, sizes, this.prof.base === 0 ? 0 : 1, type, this);
    return arr;
  };
  R.pos = function (a, name, ix) {
    if (!(a instanceof PArr)) this.e(306, ['arreglo', '"' + name + '" no es un arreglo']);
    var flat = 0;
    for (var k = 0; k < ix.length; k++) {
      var i = ix[k];
      if (typeof i !== 'number' || Math.floor(i) !== i) this.e(306, ['subíndice', 'debe ser un número entero']);
      var off = i - a.base;
      if (off < 0 || off >= a.dims[k]) this.e(302, [name, i, a.base, a.dims[k] - 1 + a.base]);
      flat = flat * a.dims[k] + off;
    }
    return flat;
  };
  R.agn = function (a, name, ix) {
    if (a === undefined) this.e(306, ['arreglo', '"' + name + '" no fue dimensionado']);
    var v = a.d[this.pos(a, name, ix)];
    if (v === undefined) this.e(312, [name + '[' + ix.join(',') + ']']);
    return v;
  };
  R.ag1 = function (a, name, i) { return this.agn(a, name, [i]); };
  R.ag2 = function (a, name, i, j) { return this.agn(a, name, [i, j]); };
  R.asn = function (a, name, val, ix, t) {
    if (a === undefined) this.e(306, ['arreglo', '"' + name + '" no fue dimensionado']);
    var p = this.pos(a, name, ix);
    a.d[p] = coerce(this, t || a.type, val, name);
  };
  R.as1 = function (a, name, val, i, t) { this.asn(a, name, val, [i], t); };
  R.as2 = function (a, name, val, i, j, t) { this.asn(a, name, val, [i, j], t); };
  /* lectura */
  R.rd = async function (name, ty) {
    for (;;) {
      if (this.stopped) throw STOP;
      var raw;
      if (this.inputs.length) { raw = this.inputs.shift(); if (this.io.out) this.io.out(raw, true, 'in'); }
      else raw = await Promise.race([this.io.read ? this.io.read(name, ty) : Promise.resolve(''), this.stopP]);
      raw = String(raw === undefined || raw === null ? '' : raw);
      var t = raw.trim(), num = /^[+-]?(\d+([.,]\d*)?|[.,]\d+)$/.test(t);
      if (ty === 'I' || ty === 'R') {
        if (!num) { this.io.out && this.io.out('Dato inválido: se esperaba un número. Intente nuevamente.', true, 'warn'); continue; }
        var v = parseFloat(t.replace(',', '.'));
        if (ty === 'I' && Math.floor(v) !== v) { this.io.out && this.io.out('Dato inválido: se esperaba un número entero. Intente nuevamente.', true, 'warn'); continue; }
        return v;
      }
      if (ty === 'L') {
        var lu = strip(t.toUpperCase());
        if (lu === 'VERDADERO' || lu === 'V' || lu === 'TRUE') return true;
        if (lu === 'FALSO' || lu === 'F' || lu === 'FALSE') return false;
        this.io.out && this.io.out('Dato inválido: escriba Verdadero o Falso. Intente nuevamente.', true, 'warn'); continue;
      }
      if (ty === 'S') return raw;
      if (num) return parseFloat(t.replace(',', '.'));
      var u = strip(t.toUpperCase());
      if (u === 'VERDADERO') return true;
      if (u === 'FALSO') return false;
      return raw;
    }
  };

  function makeFuncs(rt) {
    function num(x, f) { if (typeof x !== 'number') rt.e(306, [f, 'se esperaba un número y se recibió ' + tname(x)]); return x; }
    function str(x, f) { if (typeof x !== 'string') rt.e(306, [f, 'se esperaba un texto y se recibió ' + tname(x)]); return x; }
    function rnd(x) { return x < 0 ? -Math.round(-x) : Math.round(x); }
    var f = {
      ABS: function (x) { return Math.abs(num(x, 'abs')); },
      TRUNC: function (x) { return Math.trunc ? Math.trunc(num(x, 'trunc')) : (x < 0 ? Math.ceil(x) : Math.floor(x)); },
      REDON: function (x) { return rnd(num(x, 'redon')); },
      RAIZ: function (x) { num(x, 'raiz'); if (x < 0) rt.e(306, ['raiz', 'no existe la raíz cuadrada de un número negativo']); return Math.sqrt(x); },
      SEN: function (x) { return Math.sin(num(x, 'sen')); },
      COS: function (x) { return Math.cos(num(x, 'cos')); },
      TAN: function (x) { return Math.tan(num(x, 'tan')); },
      ASEN: function (x) { num(x, 'asen'); if (x < -1 || x > 1) rt.e(306, ['asen', 'el valor debe estar entre -1 y 1']); return Math.asin(x); },
      ACOS: function (x) { num(x, 'acos'); if (x < -1 || x > 1) rt.e(306, ['acos', 'el valor debe estar entre -1 y 1']); return Math.acos(x); },
      ATAN: function (x) { return Math.atan(num(x, 'atan')); },
      LN: function (x) { num(x, 'ln'); if (x <= 0) rt.e(306, ['ln', 'el logaritmo solo existe para números positivos']); return Math.log(x); },
      EXP: function (x) { return Math.exp(num(x, 'exp')); },
      AZAR: function (n) { num(n, 'azar'); if (n < 1) rt.e(306, ['azar', 'el argumento debe ser mayor o igual a 1']); return Math.floor(Math.random() * Math.floor(n)); },
      ALEATORIO: function (a, b) { num(a, 'aleatorio'); num(b, 'aleatorio'); if (a > b) { var t = a; a = b; b = t; } a = Math.ceil(a); b = Math.floor(b); return a + Math.floor(Math.random() * (b - a + 1)); },
      LONGITUD: function (s) { return str(s, 'longitud').length; },
      SUBCADENA: function (s, d, h) {
        str(s, 'subcadena'); num(d, 'subcadena'); num(h, 'subcadena');
        if (d < 0 || h >= s.length || d > h) rt.e(306, ['subcadena', 'posiciones fuera del texto (válidas de 0 a ' + (s.length - 1) + ')']);
        return s.substring(d, h + 1);
      },
      MAYUSCULAS: function (s) { return str(s, 'mayusculas').toUpperCase(); },
      MINUSCULAS: function (s) { return str(s, 'minusculas').toLowerCase(); },
      CONCATENAR: function (a, b) { return str(a, 'concatenar') + str(b, 'concatenar'); },
      CONVERTIRANUMERO: function (s) {
        str(s, 'convertiranumero'); var t = s.trim();
        if (!/^[+-]?(\d+([.,]\d*)?|[.,]\d+)$/.test(t)) rt.e(306, ['convertiranumero', '"' + s + '" no es un número válido']);
        return parseFloat(t.replace(',', '.'));
      },
      CONVERTIRATEXTO: function (v) { return rt.s(v); }
    };
    f.RC = f.RAIZ;
    return f;
  }

  /* ejecuta un programa compilado; devuelve { rt, done } */
  function run(compiled, io, prof) {
    var rt = new Runtime(io, prof || compiled.prof);
    var done = (async function () {
      try {
        await compiled.fn(rt);
        return { ok: true };
      } catch (e) {
        if (e === STOP) return { ok: false, stopped: true };
        if (e instanceof PscError) return { ok: false, error: e };
        if (e instanceof RangeError && /call stack|recursion/i.test(e.message)) return { ok: false, error: new PscError(307, [], rt.l) };
        var pe = new PscError(399, [e && e.message ? e.message : String(e)], rt.l);
        return { ok: false, error: pe };
      }
    })();
    return { rt: rt, done: done };
  }

  return {
    version: '1.0.0', PROFILES: PROFILES, KEYWORDS: KEYWORDS, FUNCS: FUNCS, TYPENAME: TYPENAME,
    check: check, compile: compile, run: run, parse: parse, explain: explain, errorHelp: errorHelp,
    Runtime: Runtime, PscError: PscError, STOP: STOP, strip: strip
  };
});
