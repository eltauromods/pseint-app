/*!
 * PSeInt Web - aplicación (interfaz, archivos, ejecución, diagramas).
 * Desarrollado por El Tauro Mods. Implementación web independiente, inspirada en PSeInt.
 */
(function () {
  'use strict';
  var APP = { name: 'PSeInt Web', version: '1.1.0', tagline: 'Editor e intérprete de pseudocódigo online' };
  var PSC = window.PSC, Flow = window.Flow, ED = window.PSEditor, EXAMPLES = window.EXAMPLES || [];
  function $(id) { return document.getElementById(id); }
  function H(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; }
  function lsGet(k, d) { try { var v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  var IS_IOS = /iP(hone|ad|od)/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  function isNarrow() { return window.innerWidth <= 900; }

  /* ===================================================================== configuración */
  var DEF = {
    ver: 2, theme: 'auto', autoComplete: true, fontSize: IS_IOS ? 16 : 16, indent: 4, autoIndent: true, autoClose: true, lineNumbers: true,
    showLeft: true, showRight: true, profile: 'flexible', custom: { implicitVars: true, eqAssign: true, optKw: true, strictTypes: false, base: 1 },
    speed: 6, stepInto: true, trace: true, desk: false, explain: false, keep: false, usePredef: false, predef: ''
  };
  var S = (function () { var s = lsGet('pseint.settings', {}), o = {}, k; if (!s.ver && (s.theme === 'light' || s.theme === undefined)) s.theme = 'auto'; /* migración: antes 'claro' era el valor por defecto, ahora sigue al sistema */ for (k in DEF) o[k] = s[k] === undefined ? DEF[k] : s[k]; if (!o.custom) o.custom = DEF.custom; return o; })();
  function saveSettings() { lsSet('pseint.settings', S); }
  function getProfile() {
    if (S.profile === 'custom') {
      var c = S.custom; return { id: 'custom', name: 'Personalizado', implicitVars: !!c.implicitVars, eqAssign: !!c.eqAssign, optKw: !!c.optKw, strictTypes: !!c.strictTypes, base: c.base === 0 ? 0 : 1 };
    }
    return PSC.PROFILES[S.profile] || PSC.PROFILES.flexible;
  }

  /* ===================================================================== estado */
  var tabs = [], cur = 0, tabSeq = 0, ed = null, running = null, lastCheck = null, flowOpen = false, deferredInstall = null;
  var ta = null;
  function unitStr() { return S.indent === 'tab' ? '\t' : new Array((S.indent || 4) + 1).join(' '); }
  function blankText() { return 'Algoritmo sin_titulo\n' + unitStr() + '\nFinAlgoritmo\n'; }

  /* ===================================================================== mensajes */
  var stTimer = 0;
  function status(msg, ms) {
    var s = $('stText'); if (!s) return; s.textContent = msg;
    if (stTimer) clearTimeout(stTimer);
    if (ms) stTimer = setTimeout(function () { s.textContent = defaultStatus(); }, ms);
  }
  function defaultStatus() { return 'Bienvenido a ' + APP.name + ' v' + APP.version + ' (su perfil actual es: ' + getProfile().name + ')'; }

  /* ===================================================================== diálogos */
  var openDialogs = [];
  function dialog(o) {
    var ov = el('div', 'ov'), d = el('div', 'dlg' + (o.wide ? ' wide' : ''));
    var head = el('div', 'dh', '<span>' + H(o.title || '') + '</span>'), x = el('button', '', ic('close'));
    x.type = 'button'; x.setAttribute('aria-label', 'Cerrar'); head.appendChild(x);
    var body = el('div', 'db'); if (typeof o.body === 'string') body.innerHTML = o.body; else if (o.body) body.appendChild(o.body);
    d.appendChild(head); d.appendChild(body);
    var api = { el: d, body: body, close: function () { if (ov.parentNode) ov.parentNode.removeChild(ov); var i = openDialogs.indexOf(api); if (i >= 0) openDialogs.splice(i, 1); if (o.onClose) o.onClose(); } };
    if (o.buttons && o.buttons.length) {
      var foot = el('div', 'df');
      o.buttons.forEach(function (b) {
        var bt = el('button', 'btn' + (b.pri ? ' pri' : ''), H(b.t)); bt.type = 'button';
        bt.onclick = function () { var r = b.f ? b.f(api) : undefined; if (r !== false) api.close(); };
        foot.appendChild(bt);
      });
      d.appendChild(foot);
    }
    x.onclick = function () { if (o.onCancel) o.onCancel(); api.close(); };
    ov.addEventListener('mousedown', function (e) { if (e.target === ov && o.dismiss !== false) { if (o.onCancel) o.onCancel(); api.close(); } });
    ov.appendChild(d); document.body.appendChild(ov); openDialogs.push(api);
    if (o.onOpen) o.onOpen(api);
    return api;
  }
  function ic(n, c) { return window.ic ? window.ic(n, c) : ''; }
  function ask(title, msg, buttons) { return dialog({ title: title, body: '<div>' + msg + '</div>', buttons: buttons, dismiss: false }); }
  function promptBox(title, label, value, cb) {
    var inp;
    dialog({
      title: title, body: '<label>' + H(label) + '</label><input type="text" id="pbIn" autocomplete="off" autocapitalize="off" spellcheck="false">',
      buttons: [{ t: 'Cancelar' }, { t: 'Aceptar', pri: true, f: function (d) { cb(inp.value); } }],
      onOpen: function (d) { inp = d.el.querySelector('#pbIn'); inp.value = value || ''; setTimeout(function () { inp.focus(); inp.select(); }, 30); inp.onkeydown = function (e) { if (e.key === 'Enter') { var v = inp.value; d.close(); cb(v); } }; }
    });
  }

  /* ===================================================================== pestañas */
  function curTab() { return tabs[cur]; }
  function tabTitle(t) { return (t.name ? t.name : '<sin_titulo>'); }
  function newTab(text, name, opts) {
    var t = { id: ++tabSeq, name: name || null, text: text, savedText: opts && opts.unsaved ? '' : text, undo: [], redo: [], sel: [0, 0], fh: null };
    if (!name && text === blankText()) { var p = text.indexOf('\n') + 1; t.sel = [p + unitStr().length, p + unitStr().length]; }
    tabs.push(t); selectTab(tabs.length - 1); return t;
  }
  function selectTab(i) {
    if (ed && tabs[cur]) ed.save();
    cur = Math.max(0, Math.min(i, tabs.length - 1));
    ed.load(tabs[cur]); renderTabs(); lastCheck = null; ed.setErrors([]); ed.setRunLine(0);
    liveCheckSoon(); updateUI(); if (flowOpen) renderFlowSoon();
    persistSoon();
  }
  function renderTabs() {
    var box = $('tabs'); box.innerHTML = '';
    tabs.forEach(function (t, i) {
      var d = el('div', 'tab' + (i === cur ? ' on' : ''));
      d.innerHTML = '<span class="tx">' + H(tabTitle(t)) + (t.dirty ? ' *' : '') + '</span>';
      var cl = el('button', 'cl', ic('close')); cl.type = 'button'; cl.title = 'Cerrar'; cl.setAttribute('aria-label', 'Cerrar pestaña');
      cl.querySelector('svg').setAttribute('width', 13); cl.querySelector('svg').setAttribute('height', 13);
      cl.onclick = function (e) { e.stopPropagation(); closeTab(i); };
      d.appendChild(cl); d.onclick = function () { if (i !== cur) selectTab(i); }; box.appendChild(d);
    });
    var plus = el('div', 'tab plus', '+'); plus.title = 'Nuevo archivo'; plus.onclick = newFile; box.appendChild(plus);
    var on = box.querySelector('.tab.on'); if (on && on.scrollIntoView) { try { box.scrollLeft = Math.max(0, on.offsetLeft - 40); } catch (e) { /* noop */ } }
    var ct = tabs[cur];
    document.title = ct && ct.name ? ct.name + (ct.dirty ? ' *' : '') + ' - ' + APP.name : APP.name + ' - ' + APP.tagline;
  }
  function newFile() {
    var t = curTab();
    newTab(blankText()); status('Nuevo archivo creado.', 2500); ed.focus();
  }
  function closeTab(i) {
    if (i === undefined) i = cur;
    var t = tabs[i]; if (!t) return;
    if (i === cur) ed.save();
    function doClose() {
      stopRun();
      tabs.splice(i, 1);
      if (!tabs.length) { newTab(blankText()); return; }
      if (cur >= tabs.length) cur = tabs.length - 1; else if (i < cur) cur--;
      ed.load(tabs[cur]); renderTabs(); lastCheck = null; ed.setErrors([]); liveCheckSoon(); updateUI(); persistSoon(); if (flowOpen) renderFlowSoon();
    }
    if (t.dirty && t.text.trim()) {
      ask('Cerrar archivo', '¿Desea guardar los cambios de <b>' + H(tabTitle(t)) + '</b> antes de cerrarlo?', [
        { t: 'Cancelar' },
        { t: 'No guardar', f: function () { doClose(); } },
        { t: 'Guardar', pri: true, f: function () { if (i !== cur) selectTab(i); save(function (ok) { if (ok) doClose(); }); } }
      ]);
    } else doClose();
  }
  function onEditorChange() {
    var t = curTab(); if (!t) return;
    var txt = ta.value, d = txt !== t.savedText;
    if (d !== !!t.dirty) { t.dirty = d; renderTabs(); }
    liveCheckSoon(); persistSoon(); updateUI();
    if (flowOpen) renderFlowSoon();
  }

  /* ===================================================================== persistencia de sesión */
  var persistTimer = 0;
  function persistSoon() { if (persistTimer) clearTimeout(persistTimer); persistTimer = setTimeout(persist, 700); }
  function persist() {
    if (!ed || !tabs.length) return; ed.save();
    var data = { cur: cur, tabs: tabs.map(function (t) { return { name: t.name, text: t.text, savedText: t.savedText, sel: t.sel }; }) };
    if (!lsSet('pseint.session', data)) { /* cuota excedida: guardar solo la pestaña activa */ lsSet('pseint.session', { cur: 0, tabs: [{ name: tabs[cur].name, text: tabs[cur].text, savedText: tabs[cur].savedText, sel: tabs[cur].sel }] }); }
  }
  function addRecent(name, text) {
    if (!name || text.length > 150000) return;
    var r = lsGet('pseint.recent', []).filter(function (x) { return x.name !== name; });
    r.unshift({ name: name, text: text }); r = r.slice(0, 5); lsSet('pseint.recent', r);
  }

  /* ===================================================================== archivos */
  function download(blob, name) {
    var url = (window.URL || window.webkitURL).createObjectURL(blob), a = document.createElement('a');
    if ('download' in a) { a.href = url; a.download = name; a.style.display = 'none'; document.body.appendChild(a); a.click(); setTimeout(function () { document.body.removeChild(a); URL.revokeObjectURL(url); }, 1500); }
    else { window.open(url, '_blank'); setTimeout(function () { URL.revokeObjectURL(url); }, 60000); }
  }
  function textBlob(t) { return new Blob([t.replace(/\n/g, '\r\n')], { type: 'text/plain;charset=utf-8' }); }
  function safeName(n, ext) {
    n = String(n || '').replace(/[\\\/:*?"<>|\u0000-\u001f]/g, '_').trim();
    if (!n) n = 'sin_titulo';
    if (ext && !new RegExp('\\.' + ext.replace('.', '') + '$', 'i').test(n)) n += ext;
    return n;
  }
  function suggestName() {
    var t = curTab(); if (t.name) return t.name;
    var m = /^\s*(?:algoritmo|proceso)\s+([A-Za-z0-9_À-ÿ]+)/i.exec(ta.value);
    return (m ? m[1] : 'sin_titulo') + '.psc';
  }
  function decodeBuf(buf) {
    var u8 = new Uint8Array(buf);
    try { return new TextDecoder('utf-8', { fatal: true }).decode(u8).replace(/^﻿/, ''); }
    catch (e) { try { return new TextDecoder('windows-1252').decode(u8); } catch (e2) { var s = ''; for (var i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i]); return s; } }
  }
  function openFiles(list) {
    var files = Array.prototype.slice.call(list || []);
    files.forEach(function (f) {
      if (f.size > 4 * 1024 * 1024) { status('El archivo "' + f.name + '" es demasiado grande para abrirlo.', 5000); return; }
      var rd = new FileReader();
      rd.onload = function () {
        var text = decodeBuf(rd.result).replace(/\r\n?/g, '\n');
        var t = curTab();
        if (!t.dirty && !t.name && t.text === blankText() && tabs.length === 1) { // reemplazar la pestaña vacía
          t.text = text; t.savedText = text; t.name = f.name; t.undo = []; t.redo = []; t.sel = [0, 0]; t.dirty = false; ed.load(t); renderTabs(); liveCheckSoon(); updateUI();
        } else newTab(text, f.name);
        addRecent(f.name, text); persistSoon(); status('Archivo abierto: ' + f.name, 3500); ed.focus();
      };
      rd.onerror = function () { status('No se pudo leer el archivo "' + f.name + '".', 5000); };
      rd.readAsArrayBuffer(f);
    });
  }
  function openDlg() { var fi = $('fileIn'); fi.value = ''; fi.click(); }
  function markSaved(t, name) { t.name = name; t.savedText = ta.value; t.dirty = false; addRecent(name, ta.value); renderTabs(); persistSoon(); updateUI(); }
  function save(cb) {
    var t = curTab(); ed.save();
    if (t.fh && t.fh.createWritable) {
      t.fh.createWritable().then(function (w) { return w.write(textBlob(ta.value)).then(function () { return w.close(); }); })
        .then(function () { markSaved(t, t.name); status('Archivo guardado: ' + t.name, 3000); if (cb) cb(true); })
        .catch(function () { t.fh = null; saveAs(cb); });
      return;
    }
    if (t.name && !window.showSaveFilePicker) { download(textBlob(ta.value), safeName(t.name, '.psc')); markSaved(t, t.name); status('Archivo descargado: ' + t.name, 3000); if (cb) cb(true); return; }
    saveAs(cb);
  }
  function saveAs(cb) {
    var t = curTab(); ed.save(); var sug = suggestName();
    if (window.showSaveFilePicker && !isNarrow()) {
      window.showSaveFilePicker({ suggestedName: sug, types: [{ description: 'Pseudocódigo PSeInt', accept: { 'text/plain': ['.psc', '.txt'] } }] })
        .then(function (fh) { t.fh = fh; return fh.createWritable().then(function (w) { return w.write(textBlob(ta.value)).then(function () { return w.close(); }); }).then(function () { markSaved(t, fh.name); status('Archivo guardado: ' + fh.name, 3000); if (cb) cb(true); }); })
        .catch(function (e) { if (e && e.name === 'AbortError') { if (cb) cb(false); } else { fallback(); } });
      return;
    }
    fallback();
    function fallback() {
      promptBox('Guardar como', 'Nombre del archivo:', sug, function (v) {
        var n = safeName(v, '.psc'); download(textBlob(ta.value), n); t.fh = null; markSaved(t, n); status('Archivo descargado: ' + n, 3500); if (cb) cb(true);
      });
    }
  }
  function exportAs(kind) {
    ed.save(); var base = suggestName().replace(/\.[^.]+$/, '');
    if (kind === 'txt') download(textBlob(ta.value), safeName(base, '.txt'));
    else if (kind === 'html') {
      var css = 'body{font-family:Consolas,Menlo,monospace;font-size:14px;line-height:1.5}.k{color:#1b1f8f;font-weight:700}.t{color:#0a6a8a}.c{color:#8b93a8;font-style:italic}.s{color:#a3411c}.n{color:#0b7a3b}.b{color:#7b2d9b}.f{color:#0a5a9c}';
      var html = '<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><title>' + H(base) + '</title><style>' + css + '</style></head><body><pre>' + ED.highlight(ta.value) + '</pre></body></html>';
      download(new Blob([html], { type: 'text/html;charset=utf-8' }), safeName(base, '.html'));
    } else if (kind === 'svg' || kind === 'png') {
      var r = buildFlow(true); if (!r) return;
      if (kind === 'svg') download(new Blob([r.svg], { type: 'image/svg+xml;charset=utf-8' }), safeName(base + '_diagrama', '.svg'));
      else svgToPng(r, function (blob) { download(blob, safeName(base + '_diagrama', '.png')); });
    }
    status('Exportado correctamente.', 3000);
  }
  function svgToPng(r, cb) {
    var sc = Math.min(2, Math.sqrt(16000000 / (r.w * r.h))), img = new Image();
    img.onload = function () {
      var cv = document.createElement('canvas'); cv.width = Math.round(r.w * sc); cv.height = Math.round(r.h * sc);
      var c = cv.getContext('2d'); c.fillStyle = '#fff'; c.fillRect(0, 0, cv.width, cv.height); c.drawImage(img, 0, 0, cv.width, cv.height);
      if (cv.toBlob) cv.toBlob(function (b) { cb(b); }, 'image/png');
      else { var d = cv.toDataURL('image/png').split(',')[1], bin = atob(d), u = new Uint8Array(bin.length), i; for (i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); cb(new Blob([u], { type: 'image/png' })); }
    };
    img.onerror = function () { status('No se pudo generar la imagen PNG.', 4000); };
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(r.svg);
  }
  function doPrint() {
    var lines = ta.value.split('\n'), w = String(lines.length).length, out = [(curTab().name || '<sin_titulo>') + '\n'];
    lines.forEach(function (l, i) { var n = String(i + 1); while (n.length < w) n = ' ' + n; out.push(n + '  ' + l); });
    $('printArea').textContent = out.join('\n'); setTimeout(function () { window.print(); }, 80);
  }
  function exitApp() {
    ask('Salir', '¿Desea cerrar PSeInt Web? Sus archivos se conservan en esta sesión del navegador.', [{ t: 'Cancelar' }, { t: 'Salir', pri: true, f: function () { persist(); window.close(); setTimeout(function () { status('Puede cerrar esta pestaña o ventana del navegador.', 6000); }, 300); } }]);
  }

  /* ===================================================================== edición */
  function clipCopy(cut) {
    var s = ed.selection(); if (!s) { status('No hay texto seleccionado.', 2000); return; }
    ed.focus(); var ok = false;
    try { ok = document.execCommand(cut ? 'cut' : 'copy'); } catch (e) { ok = false; }
    if (!ok && navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(s).then(function () { if (cut) ed.deleteSelection(); }); }
  }
  function clipPaste() {
    ed.focus();
    if (navigator.clipboard && navigator.clipboard.readText) navigator.clipboard.readText().then(function (t) { if (t) ed.insert(t.replace(/\r\n?/g, '\n')); }, function () { status('Permita el acceso al portapapeles, o pegue manteniendo presionado el editor (Ctrl+V).', 5000); });
    else status('Use Ctrl+V o mantenga presionado el editor para pegar.', 5000);
  }
  var FS = { q: '', cs: false, word: false };
  function showFind(replaceFocus) {
    var fb = $('findbar'); fb.hidden = false;
    var sel = ed.selection(); if (sel && sel.indexOf('\n') < 0 && sel.length < 80) $('fq').value = sel;
    var f = replaceFocus ? $('fr') : $('fq'); f.focus(); f.select(); findCount();
  }
  function fOpts() { return { cs: $('fCase').checked, word: $('fWord').checked }; }
  function findCount() { var q = $('fq').value; $('fCnt').textContent = q ? ed.count(q, fOpts()) + ' coincidencias' : ''; }
  function findGo(dir) {
    var q = $('fq').value; if (!q) { showFind(); return; }
    if ($('findbar').hidden) $('findbar').hidden = false;
    var ok = ed.find(q, fOpts(), dir); if (!ok) status('No se encontró "' + q + '".', 3000); findCount();
  }

  /* ===================================================================== verificación de sintaxis */
  var liveTimer = 0;
  function liveCheckSoon() { if (liveTimer) clearTimeout(liveTimer); liveTimer = setTimeout(liveCheck, 700); }
  function liveCheck() {
    if (running) return;
    var t = ta.value; if (t.length > 300000) return;
    try { var c = PSC.check(t, getProfile()); ed.setErrors(c.errors.map(function (e) { return e.line; })); lastCheck = c; } catch (e) { /* nunca romper la edición */ }
  }
  var rTab = 'res';
  function showResults(open) { $('results').hidden = !open; if (open) selectRTab(rTab); }
  function selectRTab(n) {
    rTab = n;
    var tabsEl = $('results').querySelectorAll('.phead .ptab'), i;
    for (i = 0; i < tabsEl.length; i++) tabsEl[i].classList.toggle('on', tabsEl[i].getAttribute('data-r') === n);
    $('rList').hidden = (n === 'desk' || n === 'help'); $('rDesk').hidden = n !== 'desk';
    $('rHelp').style.display = n === 'desk' ? 'none' : '';
    $('results').classList.toggle('showhelp', n === 'help');
  }
  function errRow(e, onrow) {
    var r = el('div', 'rrow', ic('err') + '<span>Lin ' + e.line + ' (inst ' + (e.inst || 1) + '): ERROR ' + e.code + ': ' + H(e.msg) + '</span>');
    r.onclick = function () {
      var all = $('rList').querySelectorAll('.rrow'), i; for (i = 0; i < all.length; i++) all[i].classList.remove('on'); r.classList.add('on');
      ed.goLine(e.line); showHelp(e); if (isNarrow()) { /* en móvil el panel de ayuda se alterna manualmente */ }
    };
    return r;
  }
  function showHelp(e) {
    $('rHelpTab').classList.add('has');
    $('rHelp').innerHTML = '<h4>ERROR ' + e.code + ': ' + H(e.msg) + '</h4><div>' + H(e.help || PSC.errorHelp(e.code) || 'No se encontró descripción para este error.').replace(/\n/g, '<br>') + '</div>';
  }
  function doCheck(quiet) {
    var c = PSC.check(ta.value, getProfile()); lastCheck = c; var name = tabTitle(curTab()), list = $('rList');
    ed.setErrors(c.errors.map(function (e) { return e.line; }));
    list.innerHTML = '';
    if (!c.errors.length) {
      list.appendChild(el('div', 'rrow', ic('ok') + '<span>&lt;' + H(name.replace(/[<>]/g, '')) + '&gt;: Sintaxis Correcta.</span>'));
      status('Sintaxis correcta.', 4000); $('rHelpTab').classList.remove('has'); $('rHelp').innerHTML = '';
    } else {
      list.appendChild(el('div', 'rrow', ic('err') + '<span><b>&lt;' + H(name.replace(/[<>]/g, '')) + '&gt;: Sintaxis Incorrecta: ' + c.errors.length + ' error' + (c.errors.length > 1 ? 'es' : '') + '.</b></span>'));
      c.errors.forEach(function (e) { list.appendChild(errRow(e)); });
      status('Seleccione un error para ver su descripción.');
      showHelp(c.errors[0]);
    }
    if (!(quiet && !c.errors.length)) { rTab = 'res'; showResults(true); }
    return c;
  }

  /* ===================================================================== consola de ejecución */
  var con = { buf: [], raf: 0, pend: null };
  function conEl() { return $('conOut'); }
  function conFlush() {
    con.raf = 0; var o = conEl(), parts = con.buf; if (!parts.length) return; con.buf = [];
    var near = o.scrollHeight - o.scrollTop - o.clientHeight < 60, frag = document.createDocumentFragment();
    parts.forEach(function (p) { var s = document.createElement('span'); if (p.c) s.className = p.c; s.textContent = p.t; frag.appendChild(s); });
    o.appendChild(frag);
    while (o.childNodes.length > 4000) o.removeChild(o.firstChild);
    if (near) o.scrollTop = o.scrollHeight;
  }
  function conWrite(t, cls) { con.buf.push({ t: t, c: cls }); if (!con.raf) con.raf = (window.requestAnimationFrame || setTimeout)(conFlush); }
  function conClear() { conEl().innerHTML = ''; con.buf = []; }
  var zTop = 2000;
  function front(w) { w.style.zIndex = ++zTop; }
  function drag(win, handle) {
    var sx, sy, ox, oy, on = false;
    handle.addEventListener('pointerdown', function (e) {
      if (e.target.closest && e.target.closest('button')) return;
      if (window.innerWidth <= 700 || win.classList.contains('maxwin')) return;
      on = true; var r = win.getBoundingClientRect(); sx = e.clientX; sy = e.clientY; ox = r.left; oy = r.top; front(win);
      try { handle.setPointerCapture(e.pointerId); } catch (x) { /* noop */ }
    });
    handle.addEventListener('pointermove', function (e) {
      if (!on) return; var nx = Math.max(-win.offsetWidth + 90, Math.min(window.innerWidth - 90, ox + e.clientX - sx)), ny = Math.max(0, Math.min(window.innerHeight - 40, oy + e.clientY - sy));
      win.style.left = nx + 'px'; win.style.top = ny + 'px';
    });
    function end() { on = false; }
    handle.addEventListener('pointerup', end); handle.addEventListener('pointercancel', end);
    win.addEventListener('mousedown', function () { front(win); });
  }
  function placeWin(win, w, h) {
    if (window.innerWidth <= 700 || win.classList.contains('maxwin')) return;
    var vw = window.innerWidth, vh = window.innerHeight; w = Math.min(w, vw - 20); h = Math.min(h, vh - 60);
    win.style.width = w + 'px'; win.style.height = h + 'px';
    if (!win.style.left || win.hidden) { win.style.left = Math.max(10, Math.round((vw - w) / 2 + 40)) + 'px'; win.style.top = Math.max(10, Math.round((vh - h) / 3)) + 'px'; }
  }

  /* ----- velocidad de pasos ----- */
  var DELAYS = [1600, 1150, 850, 600, 420, 280, 170, 90, 40, 8];
  function stepDelay() { return DELAYS[Math.max(0, Math.min(9, S.speed - 1))]; }

  /* ----- ejecución ----- */
  function lineMap(prog) {
    var map = {};
    function walk(list) {
      (list || []).forEach(function (n) {
        if (!map[n.line]) map[n.line] = n;
        if (n.k === 'rp' && n.condLine) map[n.condLine] = n;
        ['a', 'b', 'body', 'def'].forEach(function (k) { if (n[k] && n[k].forEach) walk(n[k]); });
        if (n.cases) n.cases.forEach(function (c) { walk(c.body); });
      });
    }
    if (prog.main) { map[prog.main.line] = prog.main; walk(prog.main.body); }
    prog.subs.forEach(function (s) { map[s.line] = s; walk(s.body); });
    return map;
  }
  function predefInputs() { if (!S.usePredef || !S.predef) return []; var l = S.predef.replace(/\r\n?/g, '\n').split('\n'); while (l.length && l[l.length - 1] === '') l.pop(); return l; }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function stopRun() {
    if (!running) return;
    var r = running; r.stopping = true; if (r.rt) r.rt.stop(); if (r.next) { var n = r.next; r.next = null; n(); }
    if (r.keyRes) { var k = r.keyRes; r.keyRes = null; k(); }
    $('conIn').style.display = 'none';
  }

  function startRun(mode) {
    // mode: 'run' | 'auto' (paso a paso automático) | 'manual' (primer paso) | 'explain'
    ed.save(); stopRun();
    var debug = mode !== 'run', prof = getProfile(), text = ta.value;
    var comp = PSC.compile(text, prof, debug);
    if (!comp.ok) {
      ed.setErrors(comp.errors.map(function (e) { return e.line; }));
      var list = $('rList'); list.innerHTML = '';
      list.appendChild(el('div', 'rrow', ic('err') + '<span><b>' + H(tabTitle(curTab()).replace(/[<>]/g, '')) + ': Sintaxis Incorrecta: ' + comp.errors.length + ' error' + (comp.errors.length > 1 ? 'es' : '') + '.</b></span>'));
      comp.errors.forEach(function (e) { list.appendChild(errRow(e)); });
      showHelp(comp.errors[0]); rTab = 'res'; showResults(true); ed.goLine(comp.errors[0].line);
      status('El programa tiene errores de sintaxis. Corríjalos para poder ejecutar.', 6000); return;
    }
    ed.setErrors([]); showResults(false);
    var name = comp.prog.main ? comp.prog.main.name.toUpperCase() : 'PROCESO';
    var lmap = lineMap(comp.prog), win = $('conWin');
    var R = { mode: mode, paused: mode === 'manual', next: null, rt: null, snap: [], desk: [], deskCols: [], deskMap: {}, stopping: false, name: name };
    running = R;
    win.hidden = false; placeWin(win, 640, 440); front(win); conClear();
    $('conTitle').innerHTML = ic('run') + H('PSeInt - Ejecutando proceso ' + name);
    $('conKeep').checked = !!S.keep; $('conIn').style.display = 'none';
    conWrite('*** Ejecución Iniciada. ***\n', 'sys');
    var wasExplain = S.explain; if (mode === 'explain') { S.explain = true; }
    if (debug && !isNarrow()) { showPanel('right', 'step'); }
    setStepUI();
    $('stExp').textContent = '';
    if (S.desk && debug) { $('rDesk').innerHTML = ''; }

    var io = {
      inputs: predefInputs(),
      out: function (s, nl, kind) { conWrite(s + (nl ? '\n' : ''), kind === 'in' ? 'in' : kind === 'warn' ? 'warn' : ''); },
      clear: conClear,
      read: function (nm, ty) {
        return new Promise(function (resolve) {
          var box = $('conIn'), inp = $('conInput');
          box.style.display = 'flex'; inp.value = ''; inp.placeholder = 'Valor para ' + nm + (ty === 'I' ? ' (entero)' : ty === 'R' ? ' (número)' : ty === 'L' ? ' (Verdadero/Falso)' : '');
          R.reader = function (v) { box.style.display = 'none'; R.reader = null; conWrite(v + '\n', 'in'); resolve(v); };
          setTimeout(function () { try { inp.focus(); } catch (e) { /* noop */ } }, 30);
          var o = conEl(); o.scrollTop = o.scrollHeight;
        });
      },
      key: function () { return new Promise(function (resolve) { conWrite('(presione una tecla o toque la consola para continuar)\n', 'sys'); R.keyRes = function () { R.keyRes = null; resolve(); }; conEl().focus(); }); },
      step: debug ? function (line, snapFn, depth) {
        if (!S.stepInto && depth > 1) return null;
        var snap = []; try { snap = snapFn ? snapFn() : []; } catch (e) { snap = []; }
        R.snap = snap; ed.setRunLine(line); flowHighlight(line); updateVars(snap, R.rt);
        if (S.desk) recordDesk(R, line, snap);
        var node = lmap[line]; $('stExp').textContent = S.explain && node ? PSC.explain(node) : '';
        if (S.explain && mode === 'explain') { if (node) status('Línea ' + line + ': ' + PSC.explain(node)); }
        if (R.paused) return waitStep(R);
        return sleep(mode === 'explain' ? Math.max(stepDelay(), 900) : stepDelay()).then(function () { if (R.paused) return waitStep(R); });
      } : null
    };
    var r = PSC.run(comp, io, prof); R.rt = r.rt;
    status(debug ? 'El pseudocódigo está siendo ejecutado paso a paso.' : 'El pseudocódigo está siendo ejecutado.');
    updateUI();
    r.done.then(function (res) {
      if (running !== R) return;
      var o = $('conIn'); o.style.display = 'none';
      if (res.ok) { conWrite('*** Ejecución Finalizada. ***\n', 'sys'); status('La ejecución ha finalizado sin errores.', 8000); }
      else if (res.stopped) { conWrite('\n*** Ejecución Interrumpida. ***\n', 'sys'); status('La ejecución fue interrumpida.', 8000); }
      else if (res.error) {
        var e = res.error; conWrite('\nLin ' + e.line + ': ERROR ' + e.code + ': ' + e.msg + '\n', 'err'); conWrite('*** Ejecución Interrumpida. ***\n', 'sys');
        ed.setErrors([e.line]); ed.goLine(e.line);
        var list = $('rList'); list.innerHTML = ''; list.appendChild(el('div', 'rrow', ic('err') + '<span><b>Error en tiempo de ejecución</b></span>'));
        var er = { code: e.code, line: e.line, inst: 1, msg: e.msg, help: e.help }; list.appendChild(errRow(er)); showHelp(er); rTab = 'res'; showResults(true);
        status('La ejecución terminó con un error. ' + e.msg, 10000);
      }
      S.explain = wasExplain;
      try { updateVars(R.rt.snapshot(), R.rt); } catch (x) { /* noop */ }
      ed.setRunLine(0); flowHighlight(0); running = null; setStepUI(); updateUI();
      if (S.desk && R.desk.length) { renderDesk(R); rTab = 'desk'; showResults(true); }
    });
  }
  function waitStep(R) {
    var p = new Promise(function (res) { R.next = res; });
    setStepUI(); return p.then(function () { setStepUI(); });
  }
  function recordDesk(R, line, snap) {
    var row = { line: line, v: {} };
    snap.forEach(function (p) { if (!R.deskMap[p[0]]) { R.deskMap[p[0]] = 1; R.deskCols.push(p[0]); } row.v[p[0]] = R.rt.show(p[1]); });
    if (R.desk.length < 800) R.desk.push(row);
  }
  function renderDesk(R) {
    var h = '<table class="dt"><tr><th>Paso</th><th>Línea</th>' + R.deskCols.map(function (c) { return '<th>' + H(c) + '</th>'; }).join('') + '</tr>';
    R.desk.forEach(function (r, i) { h += '<tr><td>' + (i + 1) + '</td><td>' + r.line + '</td>' + R.deskCols.map(function (c) { return '<td>' + (r.v[c] === undefined ? '' : H(r.v[c])) + '</td>'; }).join('') + '</tr>'; });
    $('rDesk').innerHTML = h + '</table>';
  }
  function updateVars(snap, rt) {
    var box = $('pVars'); if (!snap || !snap.length) { box.innerHTML = '<div class="empty">No hay variables para mostrar.<br>Ejecute el programa para ver sus valores.</div>'; return; }
    var h = '<table class="vlist"><tr><th>Variable</th><th>Valor</th></tr>';
    snap.forEach(function (p) { h += '<tr><td class="vn">' + H(p[0]) + '</td><td>' + H(rt ? rt.show(p[1]) : String(p[1])) + '</td></tr>'; });
    box.innerHTML = h + '</table>';
  }

  /* ----- panel Paso a Paso ----- */
  function buildStepPanel() {
    var p = $('pStep');
    p.innerHTML =
      '<button class="sbtn" id="sbStart" type="button">' + ic('run') + '<span>Comenzar</span></button>' +
      '<button class="sbtn" id="sbFirst" type="button">' + ic('next') + '<span>Primer Paso</span></button>' +
      '<button class="sbtn" id="sbStop" type="button">' + ic('stop') + '<span>Detener</span></button>' +
      '<button class="sbtn" id="sbPause" type="button">' + ic('pause') + '<span>Pausar</span></button>' +
      '<button class="sbtn" id="sbNext" type="button">' + ic('next') + '<span>Siguiente Paso</span></button>' +
      '<button class="sbtn" id="sbEval" type="button"><span style="margin-left:26px">Evaluar…</span></button>' +
      '<div style="margin:8px 2px 2px;font-size:13px">Velocidad:</div><input type="range" id="sbSpeed" min="1" max="10" step="1" aria-label="Velocidad">' +
      '<label class="sopt"><input type="checkbox" id="sbInto"> Entrar en subprocesos</label>' +
      '<label class="sopt"><input type="checkbox" id="sbTrace"> Mostrar trazado</label>' +
      '<label class="sopt"><input type="checkbox" id="sbDesk"> Prueba de escritorio</label>' +
      '<label class="sopt"><input type="checkbox" id="sbExp"> Explicar en detalle c/paso</label>' +
      '<div class="sexp" id="stExp" aria-live="polite"></div>' +
      '<button class="sbtn" id="sbHelp" type="button" style="justify-content:center;margin-top:10px">Ayuda…</button>';
    $('sbSpeed').value = S.speed; $('sbInto').checked = !!S.stepInto; $('sbTrace').checked = !!S.trace; $('sbDesk').checked = !!S.desk; $('sbExp').checked = !!S.explain;
    $('sbStart').onclick = function () { startRun('auto'); };
    $('sbFirst').onclick = function () { startRun('manual'); };
    $('sbStop').onclick = stopRun;
    $('sbPause').onclick = function () { if (!running) return; running.paused = !running.paused; if (!running.paused && running.next) { var n = running.next; running.next = null; n(); } setStepUI(); };
    $('sbNext').onclick = function () { if (running && running.next) { var n = running.next; running.next = null; n(); } };
    $('sbEval').onclick = evalDialog;
    $('sbSpeed').oninput = function () { S.speed = +this.value; saveSettings(); };
    $('sbInto').onchange = function () { S.stepInto = this.checked; saveSettings(); };
    $('sbTrace').onchange = function () { S.trace = this.checked; saveSettings(); };
    $('sbDesk').onchange = function () { S.desk = this.checked; saveSettings(); };
    $('sbExp').onchange = function () { S.explain = this.checked; saveSettings(); };
    $('sbHelp').onclick = function () { helpIndex('ejec'); };
    setStepUI();
  }
  function setStepUI() {
    var r = running, dbg = r && r.mode !== 'run';
    function sh(id, v) { var e = $(id); if (e) e.style.display = v ? '' : 'none'; }
    sh('sbStart', !r); sh('sbFirst', !r); sh('sbStop', !!r); sh('sbPause', !!dbg); sh('sbNext', !!dbg);
    var pb = $('sbPause'); if (pb) pb.querySelector('span').textContent = r && r.paused ? 'Continuar' : 'Pausar';
    var nb = $('sbNext'); if (nb) nb.disabled = !(r && r.next);
    var ev = $('sbEval'); if (ev) ev.disabled = !dbg;
    var sbs = $('conStop'); if (sbs) sbs.disabled = !r;
    var cp = $('conPause'), cn = $('conNext');
    if (cp) { cp.style.display = dbg ? '' : 'none'; cp.textContent = r && r.paused ? 'Continuar' : 'Pausar'; }
    if (cn) { cn.style.display = dbg ? '' : 'none'; cn.disabled = !(r && r.next); }
    updateUI();
  }
  function evalDialog() {
    if (!running || !running.snap) return;
    var R = running, inp;
    dialog({
      title: 'Evaluar expresión', body: '<label>Escriba una expresión con las variables actuales:</label><input type="text" id="evIn" autocomplete="off" autocapitalize="off" spellcheck="false"><div id="evOut" style="margin-top:12px;font-family:Consolas,monospace"></div>',
      buttons: [{ t: 'Cerrar' }, { t: 'Evaluar', pri: true, f: function (d) { doEval(d); return false; } }],
      onOpen: function (d) { inp = d.el.querySelector('#evIn'); setTimeout(function () { inp.focus(); }, 30); inp.onkeydown = function (e) { if (e.key === 'Enter') doEval(d); }; }
    });
    function doEval(d) {
      var ex = inp.value.trim(), out = d.el.querySelector('#evOut'); if (!ex) return;
      var src = 'Algoritmo __eval\n';
      R.snap.forEach(function (p) {
        var v = p[1]; if (v === undefined || (v && typeof v === 'object')) return;
        var lit = typeof v === 'string' ? '"' + v.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n') + '"' : typeof v === 'boolean' ? (v ? 'Verdadero' : 'Falso') : String(v);
        src += '  ' + p[0] + ' <- ' + lit + '\n';
      });
      src += '  Escribir ' + ex + '\nFinAlgoritmo\n';
      var c = PSC.compile(src, PSC.PROFILES.flexible);
      if (!c.ok) { out.style.color = 'var(--errfg)'; out.textContent = 'Error: ' + c.errors[0].msg; return; }
      var res = '';
      PSC.run(c, { out: function (s) { res += s; } }).done.then(function (x) { out.style.color = x.ok ? 'var(--okfg)' : 'var(--errfg)'; out.textContent = x.ok ? ex + ' = ' + res : 'Error: ' + (x.error ? x.error.msg : ''); });
    }
  }

  /* ===================================================================== diagrama de flujo */
  var flowState = { zoom: 1, unit: 0, theme: null, timer: 0, last: null };
  function buildFlow(forExport) {
    var c = PSC.check(ta.value, getProfile());
    if (c.errors.length) {
      ed.setErrors(c.errors.map(function (e) { return e.line; }));
      var list = $('rList'); list.innerHTML = ''; list.appendChild(el('div', 'rrow', ic('err') + '<span><b>Corrija los errores de sintaxis para generar el diagrama.</b></span>'));
      c.errors.forEach(function (e) { list.appendChild(errRow(e)); }); showHelp(c.errors[0]); rTab = 'res'; showResults(true);
      status('No se puede generar el diagrama: el programa tiene errores de sintaxis.', 6000); return null;
    }
    if (!forExport) ed.setErrors([]);
    var units = Flow.units(c.an); if (!units.length) return null;
    var idx = Math.min(flowState.unit, units.length - 1), th = flowState.theme || (document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light');
    if (forExport) th = 'light';
    var r = Flow.build(units[idx].unit, th); r.units = units; r.idx = idx; return r;
  }
  function openFlow() {
    var r = buildFlow(); if (!r) return;
    var w = $('flowWin'); w.hidden = false; flowOpen = true; placeWin(w, 900, 620); front(w); flowState.zoom = 1; renderFlow(true); flowFit();
  }
  function renderFlowSoon() { if (flowState.timer) clearTimeout(flowState.timer); flowState.timer = setTimeout(function () { renderFlow(false); }, 650); }
  function renderFlow(first) {
    if (!flowOpen) return; var r = buildFlow(); if (!r) return;
    var box = $('flowBox'), sl = box.scrollLeft, st = box.scrollTop; flowState.last = r;
    $('flowTitle').innerHTML = ic('flow') + H('PSDraw - ' + (r.units[r.idx].name || 'sin_titulo'));
    box.innerHTML = r.svg; applyZoom(); if (!first) { box.scrollLeft = sl; box.scrollTop = st; }
    var sel = $('flowSel'); if (sel) { sel.innerHTML = r.units.map(function (u, i) { return '<option value="' + i + '"' + (i === r.idx ? ' selected' : '') + '>' + H((u.main ? 'Algoritmo ' : 'SubProceso ') + u.name) + '</option>'; }).join(''); }
  }
  function applyZoom() {
    var svg = $('flowBox').querySelector('svg'), r = flowState.last; if (!svg || !r) return;
    svg.style.width = Math.round(r.w * flowState.zoom) + 'px'; svg.style.height = Math.round(r.h * flowState.zoom) + 'px';
    var z = $('flowZoom'); if (z) z.textContent = Math.round(flowState.zoom * 100) + '%';
  }
  function setZoom(z) { flowState.zoom = Math.max(0.2, Math.min(3, z)); applyZoom(); }
  function flowFit() { var r = flowState.last, box = $('flowBox'); if (!r) return; setZoom(Math.min(1.3, (box.clientWidth - 24) / r.w)); }
  function flowHighlight(line) {
    if (!flowOpen) return; var box = $('flowBox'), old = box.querySelectorAll('.fl.hl'), i; for (i = 0; i < old.length; i++) old[i].setAttribute('class', 'fl');
    if (!line) return; var n = box.querySelector('.fl[data-l="' + line + '"]'); if (n) { n.setAttribute('class', 'fl hl'); try { var b = n.getBoundingClientRect(), bb = box.getBoundingClientRect(); if (b.top < bb.top + 20 || b.bottom > bb.bottom - 20) box.scrollTop += (b.top - bb.top) - bb.height / 3; } catch (e) { /* noop */ } }
  }
  function buildFlowBar() {
    var bar = $('flowBar');
    bar.innerHTML = '<select id="flowSel" aria-label="Diagrama"></select>' +
      '<button class="tb" id="flZo" type="button" title="Alejar">' + ic('zoomout') + '</button><span id="flowZoom" style="min-width:44px;text-align:center;font-size:13px">100%</span><button class="tb" id="flZi" type="button" title="Acercar">' + ic('zoomin') + '</button><button class="tb" id="flFit" type="button" title="Ajustar al ancho">' + ic('fit') + '</button><span class="sep"></span>' +
      '<button class="tb" id="flTheme" type="button" title="Claro / oscuro">' + ic('moon') + '</button><button class="tb" id="flSvg" type="button" title="Exportar SVG">' + ic('export') + '<span style="font-size:10px;margin-left:1px">SVG</span></button><button class="tb" id="flPng" type="button" title="Exportar PNG" style="width:auto;padding:0 6px">' + ic('export') + '<span style="font-size:10px;margin-left:1px">PNG</span></button><span class="sep"></span>' +
      '<button class="tb" id="flRun" type="button" title="Ejecutar (F9)">' + ic('run') + '</button><button class="tb" id="flStep" type="button" title="Paso a paso">' + ic('step') + '</button>';
    $('flowSel').onchange = function () { flowState.unit = +this.value; renderFlow(true); flowFit(); };
    $('flZo').onclick = function () { setZoom(flowState.zoom / 1.2); }; $('flZi').onclick = function () { setZoom(flowState.zoom * 1.2); }; $('flFit').onclick = flowFit;
    $('flTheme').onclick = function () { var cur2 = flowState.theme || (document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light'); flowState.theme = cur2 === 'dark' ? 'light' : 'dark'; renderFlow(false); };
    $('flSvg').onclick = function () { exportAs('svg'); }; $('flPng').onclick = function () { exportAs('png'); };
    $('flRun').onclick = function () { startRun('run'); }; $('flStep').onclick = function () { showPanel('right', 'step'); startRun('auto'); };
    var box = $('flowBox');
    box.addEventListener('click', function (e) { var n = e.target.closest ? e.target.closest('.fl') : null; if (n) { ed.goLine(+n.getAttribute('data-l') || 1); if (window.innerWidth <= 700) closeFlow(); } });
    box.addEventListener('wheel', function (e) { if (e.ctrlKey) { e.preventDefault(); setZoom(flowState.zoom * (e.deltaY < 0 ? 1.1 : 0.9)); } }, { passive: false });
    var d0 = 0, z0 = 1;
    box.addEventListener('touchstart', function (e) { if (e.touches.length === 2) { d0 = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY); z0 = flowState.zoom; } }, { passive: true });
    box.addEventListener('touchmove', function (e) { if (e.touches.length === 2 && d0) { e.preventDefault(); var d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY); setZoom(z0 * d / d0); } }, { passive: false });
    box.addEventListener('touchend', function () { d0 = 0; }, { passive: true });
  }
  function closeFlow() { $('flowWin').hidden = true; flowOpen = false; }

  /* ===================================================================== utilidades de inserción */
  function insertOp(t, back) { ed.insert(t, back || 0); }
  function insertSnippet(snip, atEnd) {
    var v = ta.value, unit = unitStr();
    snip = snip.replace(/\t/g, unit);
    var a = ta.selectionStart, ls = v.lastIndexOf('\n', a - 1) + 1, le = v.indexOf('\n', a); if (le < 0) le = v.length;
    var line = v.slice(ls, le), lead = /^[ \t]*/.exec(line)[0], base = lead;
    if (atEnd) {
      var body0 = snip, pre = v.replace(/\s+$/, '') ? '\n\n' : '', pos0 = v.length, ci0 = body0.indexOf('$0'); body0 = body0.replace('$0', '');
      var s0 = v.length; if (!/\n$/.test(v)) pre = '\n' + pre; else if (!/\n\n$/.test(v)) pre = '\n';
      ed.edit(v.length, v.length, pre + body0 + '\n', s0 + pre.length + (ci0 < 0 ? body0.length : ci0)); ed.focus(); return;
    }
    var w = /^\s*([A-Za-zÀ-ÿ]+)/.exec(line), fw = w ? ED.strip(w[1]).toUpperCase() : '';
    if (line.trim() && /^(ALGORITMO|PROCESO|SUBPROCESO|FUNCION|SI|SINO|MIENTRAS|REPETIR|PARA|SEGUN)$/.test(fw) && !(fw === 'MIENTRAS' && /que\s/i.test(line))) base = lead + unit;
    var lines = snip.split('\n'), ci = -1, off = 0, out = lines.map(function (l, i) {
      var t = base + l; var k = t.indexOf('$0'); if (k >= 0) { ci = off + k; t = t.replace('$0', ''); } off += t.length + 1; return t;
    }).join('\n');
    if (line.trim()) { ed.edit(le, le, '\n' + out, le + 1 + (ci < 0 ? out.length : ci)); }
    else { ed.edit(ls, le, out, ls + (ci < 0 ? out.length : ci)); }
    ed.focus();
  }

  /* ===================================================================== paneles */
  var OPS = [
    ['Op. Algebraicos', [['+ (suma)', ' + '], ['- (resta)', ' - '], ['* (multiplicación)', ' * '], ['/ (división)', ' / '], ['↑ (potencia)', '^'], ['MOD (resto/modulo)', ' MOD ']]],
    ['Op. Lógicos', [['Y (conjunción)', ' Y '], ['O (disyunción)', ' O '], ['NO (negación)', 'NO ']]],
    ['Op. Relacionales', [['= (igual)', ' = '], ['≠ (distinto)', ' <> '], ['< (menor)', ' < '], ['≤ (menor o igual)', ' <= '], ['> (mayor)', ' > '], ['≥ (mayor o igual)', ' >= ']]],
    ['Func. Matemáticas', [['abs (valor absoluto)', 'abs()'], ['trunc (valor truncado)', 'trunc()'], ['redon (valor redondeado)', 'redon()'], ['raiz (raíz cuadrada)', 'raiz()'], ['sen (seno)', 'sen()'], ['cos (coseno)', 'cos()'], ['tan (tangente)', 'tan()'], ['asen (arcoseno)', 'asen()'], ['acos (arcocoseno)', 'acos()'], ['atan (arcotangente)', 'atan()'], ['ln (logaritmo natural)', 'ln()'], ['exp (func. exponencial)', 'exp()'], ['azar (número al azar)', 'azar()'], ['aleatorio (entre dos valores)', 'aleatorio(,)']]],
    ['Func. de Texto', [['longitud (cantidad de letras)', 'longitud()'], ['subcadena (extraer)', 'subcadena(,,)'], ['mayusculas', 'mayusculas()'], ['minusculas', 'minusculas()'], ['concatenar', 'concatenar(,)'], ['convertiranumero', 'convertiranumero()'], ['convertiratexto', 'convertiratexto()']]],
    ['Constantes', [['PI', 'PI'], ['Verdadero', 'Verdadero'], ['Falso', 'Falso']]]
  ];
  function buildOps() {
    var box = $('pOps'); box.innerHTML = '';
    OPS.forEach(function (g) {
      var d = el('div', 'grp'), h = el('div', 'gh', H(g[0])), items = el('div', 'gi');
      h.onclick = function () { d.classList.toggle('closed'); };
      g[1].forEach(function (it) {
        var b = el('button', 'opb', H(it[0])); b.type = 'button';
        b.onclick = function () { var t = it[1], back = /\)$/.test(t) ? (t === 'aleatorio(,)' ? 2 : t === 'subcadena(,,)' ? 3 : t === 'concatenar(,)' ? 2 : 1) : 0; insertOp(t, back); if (isNarrow()) closePanels(); };
        items.appendChild(b);
      });
      d.appendChild(h); d.appendChild(items); box.appendChild(d);
    });
  }
  var MS = 'stroke="#8b1a1a" stroke-width="1.5" fill="#fff1c2" stroke-linejoin="round"', TX = 'font-family="Consolas,monospace" font-size="9.5" text-anchor="middle" fill="#10105a"';
  var MINI = {
    out: '<path d="M14 12h54l-6 24H8z" ' + MS + '/><text x="38" y="28" ' + TX + '>\'Hola !\'</text>',
    inp: '<path d="M14 12h54l-6 24H8z" ' + MS + '/><text x="38" y="28" ' + TX + '>Dato1</text>',
    asg: '<rect x="8" y="12" width="58" height="24" ' + MS + '/><text x="37" y="28" ' + TX + '>A←B+i</text>',
    iff: '<path d="M37 3L62 17L37 31L12 17Z" ' + MS + '/><text x="37" y="20" ' + TX + ' font-size="8">A&gt;B</text><rect x="3" y="38" width="26" height="12" ' + MS + '/><rect x="45" y="38" width="26" height="12" ' + MS + '/><path d="M12 17H16V38M62 17H58V38" stroke="#8b1a1a" fill="none" stroke-width="1.3"/>',
    sw: '<path d="M37 3L60 14L37 25L14 14Z" ' + MS + '/><rect x="4" y="32" width="19" height="9" ' + MS + '/><rect x="27" y="32" width="19" height="9" ' + MS + '/><rect x="50" y="32" width="19" height="9" ' + MS + '/><rect x="4" y="44" width="19" height="8" ' + MS + '/><rect x="27" y="44" width="19" height="8" ' + MS + '/><rect x="50" y="44" width="19" height="8" ' + MS + '/>',
    wh: '<path d="M37 3L62 15L37 27L12 15Z" ' + MS + '/><text x="37" y="18" ' + TX + ' font-size="8">N&lt;10</text><rect x="20" y="34" width="34" height="14" ' + MS + '/><path d="M37 27V34M20 41H8V15H12" stroke="#8b1a1a" fill="none" stroke-width="1.3"/>',
    rp: '<rect x="18" y="3" width="38" height="14" ' + MS + '/><path d="M37 25L62 37L37 49L12 37Z" ' + MS + '/><text x="37" y="40" ' + TX + ' font-size="8">N=10</text><path d="M37 17V25M12 37H6V10H18" stroke="#8b1a1a" fill="none" stroke-width="1.3"/>',
    fr: '<path d="M8 6H44L50 14L44 22H8L2 14Z" ' + MS + '/><text x="26" y="17" ' + TX + ' font-size="8">1..N</text><rect x="16" y="30" width="38" height="14" ' + MS + '/><path d="M26 22V30M16 37H4V14H4" stroke="#8b1a1a" fill="none" stroke-width="1.3"/>',
    fn: '<rect x="6" y="14" width="62" height="22" rx="11" ' + MS + '/><text x="37" y="29" ' + TX + '>y←f(x)</text>'
  };
  var CMDS = [
    ['Escribir', 'out', 'Escribir $0'], ['Leer', 'inp', 'Leer $0'], ['Asignar', 'asg', 'variable <- $0'],
    ['Si-Entonces', 'iff', 'Si $0 Entonces\n\t\nSiNo\n\t\nFinSi'], ['Según', 'sw', 'Segun $0 Hacer\n\t1:\n\t\t\n\t2:\n\t\t\n\tDe Otro Modo:\n\t\t\nFinSegun'],
    ['Mientras', 'wh', 'Mientras $0 Hacer\n\t\nFinMientras'], ['Repetir', 'rp', 'Repetir\n\t\nHasta Que $0'], ['Para', 'fr', 'Para i <- 1 Hasta $0 Con Paso 1 Hacer\n\t\nFinPara'],
    ['Función', 'fn', 'Funcion resultado <- NombreFuncion(argumento)\n\tresultado <- $0\nFinFuncion', true]
  ];
  function buildCmds() {
    var box = $('pCmd'); box.innerHTML = '';
    CMDS.forEach(function (c) {
      var b = el('button', 'cmdb', '<svg viewBox="0 0 74 54" aria-hidden="true">' + MINI[c[1]] + '</svg><span>' + H(c[0]) + '</span>'); b.type = 'button';
      b.onclick = function () { insertSnippet(c[2], c[3]); if (isNarrow()) closePanels(); }; box.appendChild(b);
    });
    var extra = [['Definir variable', 'Definir $0 Como Entero'], ['Dimension (arreglo)', 'Dimension $0[10]'], ['Esperar', 'Esperar $0 Segundos'], ['Retornar', 'Retornar $0']];
    var sep = el('div', '', '<div style="margin:10px 4px 2px;font-size:12px;color:var(--muted)">Otros</div>'); box.appendChild(sep);
    extra.forEach(function (c) { var b = el('button', 'opb', H(c[0])); b.type = 'button'; b.onclick = function () { insertSnippet(c[1]); if (isNarrow()) closePanels(); }; box.appendChild(b); });
  }
  function setPanelTab(side, which) {
    if (side === 'left') {
      var op = which === 'ops'; $('pOps').hidden = !op; $('pVars').hidden = op;
      var t = $('left').querySelectorAll('.ptab'), i; for (i = 0; i < t.length; i++) t[i].classList.toggle('on', t[i].getAttribute('data-p') === which);
    } else {
      var cm = which === 'cmd'; $('pCmd').hidden = !cm; $('pStep').hidden = cm;
      var t2 = $('right').querySelectorAll('.ptab'), j; for (j = 0; j < t2.length; j++) t2[j].classList.toggle('on', t2[j].getAttribute('data-p') === which);
    }
  }
  function showPanel(side, which) {
    setPanelTab(side, which);
    var p = $(side); if (isNarrow()) { p.classList.add('open'); $('bd').classList.add('on'); } else { p.style.display = ''; if (side === 'left') S.showLeft = true; else S.showRight = true; applyPanels(); }
  }
  function togglePanel(side, which) {
    var p = $(side), visible = isNarrow() ? p.classList.contains('open') : p.style.display !== 'none';
    var shown = side === 'left' ? ($('pOps').hidden ? 'vars' : 'ops') : ($('pCmd').hidden ? 'step' : 'cmd');
    if (visible && shown === which) {
      if (isNarrow()) { p.classList.remove('open'); $('bd').classList.remove('on'); } else { if (side === 'left') S.showLeft = false; else S.showRight = false; applyPanels(); saveSettings(); }
    } else showPanel(side, which);
    updateUI();
  }
  function closePanels() { $('left').classList.remove('open'); $('right').classList.remove('open'); $('bd').classList.remove('on'); }
  function applyPanels() {
    if (isNarrow()) { $('left').style.display = ''; $('right').style.display = ''; return; }
    $('left').style.display = S.showLeft ? '' : 'none'; $('right').style.display = S.showRight ? '' : 'none';
  }

  /* ===================================================================== opciones (diálogos) */
  function profileDialog() {
    var pr = getProfile(), c = { implicitVars: pr.implicitVars, eqAssign: pr.eqAssign, optKw: pr.optKw, strictTypes: pr.strictTypes, base: pr.base };
    var body = '<label>Perfil:</label><select id="pfSel"><option value="flexible">Flexible (recomendado para aprender)</option><option value="estricto">Estricto (variables declaradas, sintaxis completa)</option><option value="custom">Personalizado</option></select>' +
      '<div style="margin-top:12px">' +
      '<label class="row"><input type="checkbox" id="pfImp"> Permitir variables sin declarar con Definir (implícitas)</label>' +
      '<label class="row"><input type="checkbox" id="pfEq"> Permitir "=" como asignación (además de &lt;-)</label>' +
      '<label class="row"><input type="checkbox" id="pfOpt"> Palabras opcionales: "Entonces" y "Hacer" pueden omitirse</label>' +
      '<label class="row"><input type="checkbox" id="pfTy"> Validar estrictamente los tipos (Entero no admite decimales)</label>' +
      '<label class="row" style="margin-top:12px">Los arreglos comienzan en:&nbsp;<select id="pfBase" style="width:auto"><option value="1">1</option><option value="0">0</option></select></label></div>';
    dialog({
      title: 'Opciones del Lenguaje (perfiles)', body: body,
      buttons: [{ t: 'Cancelar' }, {
        t: 'Aceptar', pri: true, f: function (d) {
          var sel = d.el.querySelector('#pfSel').value;
          if (sel === 'custom') { S.custom = { implicitVars: d.el.querySelector('#pfImp').checked, eqAssign: d.el.querySelector('#pfEq').checked, optKw: d.el.querySelector('#pfOpt').checked, strictTypes: d.el.querySelector('#pfTy').checked, base: +d.el.querySelector('#pfBase').value }; }
          S.profile = sel; saveSettings(); status(defaultStatus(), 5000); liveCheck();
        }
      }],
      onOpen: function (d) {
        var q = function (s) { return d.el.querySelector(s); };
        function fill(p) { q('#pfImp').checked = p.implicitVars; q('#pfEq').checked = p.eqAssign; q('#pfOpt').checked = p.optKw; q('#pfTy').checked = p.strictTypes; q('#pfBase').value = String(p.base); }
        function lock(on) { ['#pfImp', '#pfEq', '#pfOpt', '#pfTy', '#pfBase'].forEach(function (s) { q(s).disabled = !on; }); }
        q('#pfSel').value = S.profile; fill(pr); lock(S.profile === 'custom');
        q('#pfSel').onchange = function () { var v = this.value; fill(v === 'custom' ? c : PSC.PROFILES[v]); lock(v === 'custom'); };
      }
    });
  }
  function predefDialog() {
    dialog({
      title: 'Predefinir entrada', body: '<p style="margin-top:0">Escriba un valor por línea. Se usarán en orden para cada instrucción <code>Leer</code>; si se acaban, el programa le pedirá los demás.</p><textarea id="pdTx" spellcheck="false" placeholder="5&#10;10&#10;Ana"></textarea><label class="row" style="margin-top:10px"><input type="checkbox" id="pdOn"> Usar estas entradas al ejecutar</label>',
      buttons: [{ t: 'Cancelar' }, { t: 'Aceptar', pri: true, f: function (d) { S.predef = d.el.querySelector('#pdTx').value; S.usePredef = d.el.querySelector('#pdOn').checked && !!S.predef.trim(); saveSettings(); status(S.usePredef ? 'Se usarán entradas predefinidas.' : 'Entradas predefinidas desactivadas.', 3000); } }],
      onOpen: function (d) { d.el.querySelector('#pdTx').value = S.predef || ''; d.el.querySelector('#pdOn').checked = !!S.usePredef; }
    });
  }
  function applyTheme() {
    var t = S.theme, dark = t === 'dark' || (t === 'auto' && window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    try { localStorage.setItem('pseint.theme', t); } catch (e) { /* noop */ }
    var m = document.querySelector('meta[name=theme-color]'); if (m) m.setAttribute('content', dark ? '#12141d' : '#ffffff');
    var tb = $('tbTheme'); if (tb) tb.innerHTML = ic(dark ? 'sun' : 'moon');
    if (flowOpen) { flowState.theme = null; renderFlow(false); }
  }
  function setFont(sz) { S.fontSize = Math.max(11, Math.min(32, sz)); saveSettings(); ed.applySettings(); status('Tamaño de letra: ' + S.fontSize + ' px', 2000); }
  function applyAll() { ed.applySettings(); applyPanels(); applyTheme(); }
  function toggleFull() {
    var d = document, de = d.documentElement;
    if (d.fullscreenElement || d.webkitFullscreenElement) { (d.exitFullscreen || d.webkitExitFullscreen).call(d); }
    else { var f = de.requestFullscreen || de.webkitRequestFullscreen; if (f) f.call(de); else status('Su navegador no permite pantalla completa. Instale la app para usarla a pantalla completa.', 5000); }
  }

  /* ===================================================================== ayuda */
  function code(t) { return '<pre class="code">' + H(t) + '</pre>'; }
  function helpIndex(section) {
    var h = '';
    h += '<h3 id="h-estructura">Estructura de un programa</h3><p>Todo programa tiene un único <code>Algoritmo</code> (o <code>Proceso</code>) principal. Las instrucciones terminan con salto de línea o con punto y coma. Los comentarios empiezan con <code>//</code> o van entre <code>/* ... */</code>. No se distingue entre mayúsculas y minúsculas ni se exigen tildes.</p>' + code('Algoritmo Saludo\n  Escribir "Hola"   // comentario\nFinAlgoritmo');
    h += '<h3>Variables y tipos</h3><p>Los tipos son <code>Entero</code>, <code>Real</code> (o <code>Numero</code>), <code>Logico</code> y <code>Caracter</code> (o <code>Texto</code>/<code>Cadena</code>). Se declaran con <code>Definir</code>; en el perfil Flexible también se pueden usar sin declarar. La asignación es <code>&lt;-</code> (también <code>=</code> o <code>:=</code> en el perfil Flexible).</p>' + code('Definir edad Como Entero\nDefinir nombre Como Caracter\nedad <- 18\nnombre <- "Ana"');
    h += '<p><b>Cuidado:</b> las palabras reservadas (<code>Y</code>, <code>O</code>, <code>NO</code>, <code>MOD</code>, <code>Si</code>, <code>Para</code>…) no pueden usarse como nombres de variable.</p>';
    h += '<h3>Operadores</h3><table class="ref"><tr><th>Tipo</th><th>Operadores</th></tr><tr><td>Algebraicos</td><td><code>+ - * / ^ MOD</code> (también <code>%</code>)</td></tr><tr><td>Relacionales</td><td><code>= &lt;&gt; &lt; &gt; &lt;= &gt;=</code></td></tr><tr><td>Lógicos</td><td><code>Y</code> (<code>&amp;</code>), <code>O</code> (<code>|</code>), <code>NO</code> (<code>~</code>)</td></tr><tr><td>Texto</td><td><code>+</code> concatena textos y números con texto</td></tr></table>';
    h += '<h3>Entrada y salida</h3>' + code('Escribir "Suma: ", a + b      // muestra y baja de línea\nEscribir Sin Saltar "Dato: "   // no baja de línea\nLeer a, b                      // pide valores al usuario') + '<p>Si <code>Leer</code> espera un Entero o Real y el usuario escribe otra cosa, el programa vuelve a pedir el dato.</p>';
    h += '<h3>Condicionales</h3>' + code('Si x > 0 Entonces\n  Escribir "positivo"\nSiNo\n  Escribir "no positivo"\nFinSi\n\nSegun opcion Hacer\n  1: Escribir "uno"\n  2, 3: Escribir "dos o tres"\n  De Otro Modo: Escribir "otro"\nFinSegun');
    h += '<h3>Ciclos</h3>' + code('Mientras i <= 10 Hacer\n  i <- i + 1\nFinMientras\n\nRepetir\n  Leer n\nHasta Que n > 0     // también: Mientras Que cond\n\nPara i <- 1 Hasta 10 Con Paso 2 Hacer\n  Escribir i\nFinPara            // Con Paso es opcional (puede ser negativo)');
    h += '<h3>Arreglos</h3>' + code('Dimension v[5]          // vector de 5 posiciones (1 a 5)\nDimension m[3, 4]       // matriz 3x4\nv[1] <- 10\nm[2, 3] <- v[1] * 2') + '<p>Las posiciones empiezan en 1 (se puede cambiar a 0 en Configurar &gt; Opciones del Lenguaje).</p>';
    h += '<h3>Funciones y subprocesos</h3>' + code('Funcion r <- Doble(n)\n  r <- n * 2\nFinFuncion\n\nSubProceso Mostrar(texto)\n  Escribir texto\nFinSubProceso\n\nSubProceso Cambiar(a Por Referencia)\n  a <- 0\nFinSubProceso\n\nAlgoritmo Principal\n  Escribir Doble(21)\n  Mostrar("Hola")\nFinAlgoritmo') + '<p>Los argumentos se pasan por valor, salvo que se indique <code>Por Referencia</code>. Las funciones pueden ser recursivas.</p>';
    h += '<h3>Otras instrucciones</h3><p><code>Esperar 2 Segundos</code>, <code>Esperar Tecla</code>, <code>Limpiar Pantalla</code> y <code>Retornar valor</code>.</p>';
    h += '<h3>Funciones incluidas</h3><table class="ref"><tr><th>Función</th><th>Descripción</th></tr><tr><td><code>abs(x)</code></td><td>valor absoluto</td></tr><tr><td><code>trunc(x)</code>, <code>redon(x)</code></td><td>parte entera / redondeo</td></tr><tr><td><code>raiz(x)</code>, <code>rc(x)</code></td><td>raíz cuadrada</td></tr><tr><td><code>sen cos tan asen acos atan</code></td><td>trigonometría (radianes)</td></tr><tr><td><code>ln(x)</code>, <code>exp(x)</code></td><td>logaritmo natural / exponencial</td></tr><tr><td><code>azar(n)</code></td><td>entero entre 0 y n-1</td></tr><tr><td><code>aleatorio(a,b)</code></td><td>entero entre a y b</td></tr><tr><td><code>longitud(t)</code></td><td>cantidad de caracteres</td></tr><tr><td><code>subcadena(t,desde,hasta)</code></td><td>extrae texto (posiciones desde 0)</td></tr><tr><td><code>mayusculas(t)</code>, <code>minusculas(t)</code></td><td>cambia la capitalización</td></tr><tr><td><code>concatenar(a,b)</code></td><td>une dos textos</td></tr><tr><td><code>convertiranumero(t)</code>, <code>convertiratexto(x)</code></td><td>conversiones</td></tr><tr><td><code>PI</code></td><td>constante 3.14159…</td></tr></table>';
    h += '<h3 id="h-ejec">Ejecución, paso a paso y diagramas</h3><p><b>Ejecutar (F9)</b> abre la consola. <b>Paso a Paso (F5)</b> resalta cada línea, muestra las variables y permite pausar, avanzar de a un paso y evaluar expresiones. Con <b>Prueba de escritorio</b> se arma una tabla con los valores de las variables en cada paso. <b>Verificar Sintaxis (Shift+F9)</b> lista los errores. El <b>Diagrama de Flujo (F7)</b> se genera automáticamente a partir del código, se puede ampliar, exportar a SVG/PNG, y al tocar una figura el editor salta a su línea.</p>';
    h += '<h3>Atajos de teclado</h3><table class="ref"><tr><td>Ctrl+N / O / S</td><td>Nuevo / Abrir / Guardar</td></tr><tr><td>Ctrl+Shift+S</td><td>Guardar como</td></tr><tr><td>Ctrl+Z / Ctrl+Shift+Z</td><td>Deshacer / Rehacer</td></tr><tr><td>Ctrl+F / F3 / Shift+F3 / Ctrl+R</td><td>Buscar / Siguiente / Anterior / Reemplazar</td></tr><tr><td>Ctrl+D / Ctrl+Shift+D</td><td>Comentar / Descomentar líneas</td></tr><tr><td>Ctrl+L / Ctrl+Shift+L</td><td>Duplicar / Eliminar líneas</td></tr><tr><td>Ctrl+T / Ctrl+Shift+T</td><td>Mover línea arriba / abajo</td></tr><tr><td>Ctrl+I</td><td>Corregir indentado</td></tr><tr><td>F9 / F5 / Shift+F9 / Ctrl+F9</td><td>Ejecutar / Paso a paso / Verificar / Predefinir entrada</td></tr><tr><td>F7 / F1</td><td>Diagrama de flujo / Ayuda</td></tr><tr><td>Ctrl + / Ctrl -</td><td>Tamaño de letra</td></tr></table>';
    dialog({ title: 'Ayuda - Índice', body: h, wide: true, buttons: [{ t: 'Cerrar', pri: true }], onOpen: function (d) { if (section) { var t = d.el.querySelector('#h-' + section); if (t) setTimeout(function () { t.scrollIntoView(); }, 30); } } });
  }
  function quickHelp() {
    dialog({
      title: 'Ayuda Rápida', buttons: [{ t: 'Cerrar', pri: true }], body:
        '<h3>Ejemplo mínimo</h3>' + code('Algoritmo Suma\n  Definir a, b Como Real\n  Leer a, b\n  Escribir "Resultado: ", a + b\nFinAlgoritmo') +
        '<h3>Estructuras</h3>' + code('Si cond Entonces ... SiNo ... FinSi\nMientras cond Hacer ... FinMientras\nRepetir ... Hasta Que cond\nPara i <- 1 Hasta n Hacer ... FinPara\nSegun x Hacer  1: ...  De Otro Modo: ...  FinSegun') +
        '<p>Use el panel <b>Comandos</b> para insertar cualquier estructura y el panel <b>Operadores y Funciones</b> para los símbolos. Para más detalle abra <b>Ayuda &gt; Índice</b>.</p>'
    });
  }
  function examplesDialog() {
    var box = el('div'); box.innerHTML = '<p style="margin-top:0">Elija un ejemplo; se abrirá en una pestaña nueva.</p>';
    EXAMPLES.forEach(function (ex) {
      var r = el('div', 'exl', '<b>' + H(ex.name) + '</b><small>' + H(ex.level) + '</small>');
      r.onclick = function () {
        var d = openDialogs[openDialogs.length - 1]; if (d) d.close();
        newTab(ex.code, safeName(ex.name.replace(/\s+/g, '_'), '.psc')); ed.focus();
        status('Ejemplo abierto: ' + ex.name + (ex.inputs.length ? '. Entradas sugeridas: ' + ex.inputs.join(', ') : ''), 9000);
      };
      box.appendChild(r);
    });
    dialog({ title: 'Ejemplos', body: box, buttons: [{ t: 'Cerrar' }] });
  }
  function aboutDialog() {
    dialog({
      title: 'Acerca de ' + APP.name, buttons: [{ t: 'Cerrar', pri: true }], body:
        '<div style="text-align:center;margin-bottom:10px"><img src="img/logo.png" width="72" height="72" alt="" style="vertical-align:middle"> <span style="font-size:26px;font-weight:700;color:var(--accent);vertical-align:middle;font-family:Consolas,monospace">PSeInt Web</span><div style="color:var(--muted)">versión ' + APP.version + ' · por El Tauro Mods</div></div>' +
        '<p>Editor, intérprete de pseudocódigo y generador de diagramas de flujo que funciona completamente en el navegador (sin instalar nada y sin conexión una vez cargado). Funciona en PC, Mac, Android e iOS y puede instalarse como aplicación.</p>' +
        '<h3>Créditos</h3><p><b>PSeInt Web</b> fue desarrollado por <b>El Tauro Mods</b>. Es una implementación web independiente, <b>inspirada en PSeInt</b> (el programa de escritorio libre para aprender programación). Para obtener el programa original visite <a href=\"https://pseint.sourceforge.net\" target=\"_blank\" rel=\"noopener\">pseint.sourceforge.net</a>.</p>' +
        '<p style="color:var(--muted);font-size:13px">El analizador, el intérprete y el generador de diagramas de este proyecto son implementaciones independientes escritas en JavaScript. Los iconos de la interfaz son dibujos propios.</p>'
    });
  }

  /* ===================================================================== menús */
  function chk(f) { return function () { return !!f(); }; }
  var MENUS = [
    {
      t: 'Archivo', items: function () {
        var rec = lsGet('pseint.recent', []), arr = [
          { l: 'Nuevo', ic: 'new', k: 'Ctrl+N', f: newFile }, { l: 'Abrir…', ic: 'open', k: 'Ctrl+O', f: openDlg }, { l: 'Guardar', ic: 'save', k: 'Ctrl+S', f: save }, { l: 'Guardar Como…', ic: 'saveas', k: 'Ctrl+Shift+S', f: saveAs },
          { l: 'Editar Diagrama de Flujo…', ic: 'flow', k: 'F7', f: openFlow }, { l: 'Imprimir…', ic: 'print', k: 'Ctrl+P', f: doPrint },
          { l: 'Exportar', ic: 'export', sub: [{ l: 'Pseudocódigo como texto (.txt)', f: function () { exportAs('txt'); } }, { l: 'Código con colores (.html)', f: function () { exportAs('html'); } }, { l: 'Diagrama de flujo (.svg)', f: function () { exportAs('svg'); } }, { l: 'Diagrama de flujo (.png)', f: function () { exportAs('png'); } }] },
          { l: 'Cerrar…', ic: 'closeX', k: 'Ctrl+W', f: function () { closeTab(); } }, { sep: 1 }, { l: 'Salir', ic: 'close', k: 'Alt+F4', f: exitApp }
        ];
        if (rec.length) { arr.push({ sep: 1 }); rec.forEach(function (r) { arr.push({ l: r.name, f: function () { newTab(r.text, r.name); ed.focus(); } }); }); }
        return arr;
      }
    },
    {
      t: 'Editar', items: function () {
        return [
          { l: 'Deshacer', ic: 'undo', k: 'Ctrl+Z', f: function () { ed.undo(); ed.focus(); }, dis: !ed.canUndo() }, { l: 'Rehacer', ic: 'redo', k: 'Ctrl+Shift+Z', f: function () { ed.redo(); ed.focus(); }, dis: !ed.canRedo() }, { sep: 1 },
          { l: 'Cortar', ic: 'cut', k: 'Ctrl+X', f: function () { clipCopy(true); } }, { l: 'Copiar', ic: 'copy', k: 'Ctrl+C', f: function () { clipCopy(false); } }, { l: 'Pegar', ic: 'paste', k: 'Ctrl+V', f: clipPaste },
          { l: 'Mover Hacia Arriba', ic: 'up', k: 'Ctrl+T', f: function () { ed.moveLines(-1); ed.focus(); } }, { l: 'Mover Hacia Abajo', ic: 'down', k: 'Ctrl+Shift+T', f: function () { ed.moveLines(1); ed.focus(); } }, { sep: 1 },
          { l: 'Buscar…', ic: 'find', k: 'Ctrl+F', f: function () { showFind(false); } }, { l: 'Buscar Anterior', ic: 'findprev', k: 'Shift+F3', f: function () { findGo(-1); } }, { l: 'Buscar Siguiente', ic: 'findnext', k: 'F3', f: function () { findGo(1); } }, { l: 'Reemplazar…', ic: 'replace', k: 'Ctrl+R', f: function () { showFind(true); } }, { sep: 1 },
          { l: 'Seleccionar Todo', ic: 'selall', k: 'Ctrl+A', f: function () { ed.selectAll(); } }, { l: 'Duplicar Líneas', ic: 'dup', k: 'Ctrl+L', f: function () { ed.duplicate(); ed.focus(); } }, { l: 'Eliminar Líneas', ic: 'del', k: 'Ctrl+Shift+L', f: function () { ed.deleteLines(); ed.focus(); } },
          { l: 'Comentar Líneas', ic: 'comment', k: 'Ctrl+D', f: function () { ed.comment(true); ed.focus(); } }, { l: 'Descomentar Líneas', ic: 'uncomment', k: 'Ctrl+Shift+D', f: function () { ed.comment(false); ed.focus(); } }, { sep: 1 },
          { l: 'Corregir Indentado', ic: 'indent', k: 'Ctrl+I', f: function () { if (!ed.reindent()) status('El código ya está correctamente indentado.', 2500); ed.focus(); } }
        ];
      }
    },
    {
      t: 'Configurar', items: function () {
        function ind(v, lb) { return { l: lb, chk: function () { return S.indent === v; }, f: function () { S.indent = v; saveSettings(); } }; }
        function thm(v, lb) { return { l: lb, chk: function () { return S.theme === v; }, f: function () { S.theme = v; saveSettings(); applyTheme(); } }; }
        return [
          { l: 'Asistencias', sub: [{ l: 'Autoindentar al presionar Enter', chk: function () { return S.autoIndent; }, f: function () { S.autoIndent = !S.autoIndent; saveSettings(); } }, { l: 'Autocompletar palabras y mostrar ayuda al escribir', chk: function () { return S.autoComplete !== false; }, f: function () { S.autoComplete = S.autoComplete === false; saveSettings(); } }, { l: 'Completar estructuras (FinSi, FinPara…)', chk: function () { return S.autoClose; }, f: function () { S.autoClose = !S.autoClose; saveSettings(); } }, { sep: 1 }, ind(2, 'Sangría de 2 espacios'), ind(4, 'Sangría de 4 espacios'), ind('tab', 'Sangría con tabulación')] },
          { l: 'Presentación', sub: [thm('light', 'Tema claro'), thm('dark', 'Tema oscuro'), thm('auto', 'Tema automático (del sistema)'), { sep: 1 },
            { l: 'Aumentar tamaño de letra', k: 'Ctrl +', f: function () { setFont(S.fontSize + 1); }, keep: 1 }, { l: 'Disminuir tamaño de letra', k: 'Ctrl -', f: function () { setFont(S.fontSize - 1); }, keep: 1 }, { l: 'Restablecer tamaño de letra', k: 'Ctrl 0', f: function () { setFont(DEF.fontSize); } }, { sep: 1 },
            { l: 'Panel de operadores y funciones', chk: function () { return isNarrow() ? $('left').classList.contains('open') : S.showLeft; }, f: function () { togglePanel('left', 'ops'); } },
            { l: 'Panel de comandos y estructuras', chk: function () { return isNarrow() ? $('right').classList.contains('open') : S.showRight; }, f: function () { togglePanel('right', 'cmd'); } },
            { l: 'Números de línea', chk: function () { return S.lineNumbers; }, f: function () { S.lineNumbers = !S.lineNumbers; saveSettings(); ed.applySettings(); } }, { sep: 1 }, { l: 'Pantalla completa', f: toggleFull }] },
          { l: 'Opciones del Lenguaje (perfiles)…', ic: 'settings', f: profileDialog }
        ];
      }
    },
    {
      t: 'Ejecutar', items: function () {
        return [
          { l: 'Ejecutar', ic: 'run', k: 'F9', f: function () { startRun('run'); } }, { l: 'Ejecutar Paso a Paso', ic: 'step', k: 'F5', f: function () { showPanel('right', 'step'); } }, { l: 'Ejecución Explicada', ic: 'explain', f: function () { showPanel('right', 'step'); startRun('explain'); } },
          { l: 'Verificar Sintaxis', ic: 'check', k: 'Shift+F9', f: function () { doCheck(false); } }, { l: 'Predefinir Entrada…', ic: 'input', k: 'Ctrl+F9', f: predefDialog },
          { sep: 1 }, { l: 'Detener ejecución', ic: 'stop', f: stopRun, dis: !running }
        ];
      }
    },
    {
      t: 'Ayuda', items: function () {
        var a = [{ l: 'Índice…', ic: 'help', k: 'F1', f: function () { helpIndex(); } }, { l: 'Ayuda Rápida', ic: 'book', k: 'Shift+F1', f: quickHelp }, { l: 'Ejemplos…', ic: 'open', f: examplesDialog }, { sep: 1 }];
        if (deferredInstall) a.push({ l: 'Instalar aplicación…', ic: 'export', f: installApp });
        a.push({ l: 'Acerca de…', ic: 'info', f: aboutDialog });
        return a;
      }
    }
  ];
  var openMenu = -1;
  function closeMenus() { $('menus').innerHTML = ''; $('shade').style.display = 'none'; openMenu = -1; var m = $('menubar').querySelectorAll('.mi'), i; for (i = 0; i < m.length; i++) m[i].classList.remove('on'); }
  function renderItems(items, box, depth) {
    items.forEach(function (it) {
      if (it.sep) { box.appendChild(el('div', 'ln')); return; }
      var row = el('div', 'it' + (it.dis ? ' dis' : '')), pad = depth ? 'style="padding-left:' + (10 + depth * 18) + 'px"' : '';
      var checked = it.chk ? it.chk() : null;
      row.innerHTML = (it.chk ? '<span class="ck">' + (checked ? ic('check2').replace('width="22" height="22"', 'width="14" height="14"') : '') + '</span>' : '') + '<span class="ico">' + (it.ic ? ic(it.ic) : '') + '</span><span class="lb">' + H(it.l) + '</span>' + (it.k ? '<span class="sc">' + H(it.k) + '</span>' : '') + (it.sub ? '<span class="ar">' + ic('chev') + '</span>' : '');
      if (depth) row.style.paddingLeft = (10 + depth * 16) + 'px';
      if (it.sub) {
        var subBox = el('div', ''); subBox.style.display = 'none'; renderItems(it.sub, subBox, depth + 1);
        row.onclick = function (e) { e.stopPropagation(); subBox.style.display = subBox.style.display === 'none' ? '' : 'none'; };
        box.appendChild(row); box.appendChild(subBox);
      } else {
        row.onclick = function (e) {
          e.stopPropagation();
          if (it.keep) { it.f(); return; }
          var mi = openMenu; closeMenus(); if (it.f) setTimeout(function () { it.f(); }, 10);
        };
        box.appendChild(row);
      }
    });
  }
  function showMenu(i, anchor) {
    closeMenus(); openMenu = i; anchor.classList.add('on');
    var dd = el('div', 'dd'); renderItems(MENUS[i].items(), dd, 0); $('menus').appendChild(dd); $('shade').style.display = 'block';
    var r = anchor.getBoundingClientRect(), vw = window.innerWidth;
    dd.style.top = r.bottom + 'px'; dd.style.left = Math.max(4, Math.min(r.left, vw - dd.offsetWidth - 4)) + 'px';
    dd.style.maxHeight = (window.innerHeight - r.bottom - 10) + 'px';
  }
  function buildMenubar() {
    var bar = $('menubar'); bar.innerHTML = '<div class="brand"><img src="img/logo.png" alt=""><span>PSeInt</span></div>';
    MENUS.forEach(function (m, i) {
      var d = el('div', 'mi', H(m.t)); d.setAttribute('role', 'button'); d.tabIndex = 0;
      d.onclick = function () { if (openMenu === i) closeMenus(); else showMenu(i, d); };
      d.onmouseenter = function () { if (openMenu >= 0 && openMenu !== i && window.matchMedia && matchMedia('(hover:hover)').matches) showMenu(i, d); };
      d.onkeydown = function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); d.click(); } };
      bar.appendChild(d);
    });
    $('shade').onclick = closeMenus;
  }

  /* ===================================================================== barra de herramientas */
  var TB = {};
  function buildToolbar() {
    var bar = $('toolbar'); bar.innerHTML = '';
    function add(id, icon, title, f, cls) { var b = el('button', 'tb' + (cls ? ' ' + cls : ''), ic(icon)); b.type = 'button'; b.title = title; b.setAttribute('aria-label', title); b.onclick = f; bar.appendChild(b); TB[id] = b; return b; }
    function sep(cls) { bar.appendChild(el('span', 'sep' + (cls ? ' ' + cls : ''))); }
    add('new', 'new', 'Nuevo (Ctrl+N)', newFile); add('open', 'open', 'Abrir (Ctrl+O)', openDlg); add('save', 'save', 'Guardar (Ctrl+S)', function () { save(); }); add('saveas', 'saveas', 'Guardar como (Ctrl+Shift+S)', function () { saveAs(); }); sep();
    add('undo', 'undo', 'Deshacer (Ctrl+Z)', function () { ed.undo(); ed.focus(); }); add('redo', 'redo', 'Rehacer (Ctrl+Shift+Z)', function () { ed.redo(); ed.focus(); });
    add('cut', 'cut', 'Cortar (Ctrl+X)', function () { clipCopy(true); }); add('copy', 'copy', 'Copiar (Ctrl+C)', function () { clipCopy(false); }); add('paste', 'paste', 'Pegar (Ctrl+V)', clipPaste); sep();
    add('find', 'find', 'Buscar y reemplazar (Ctrl+F)', function () { showFind(false); }); add('fprev', 'findprev', 'Buscar anterior (Shift+F3)', function () { findGo(-1); }); add('fnext', 'findnext', 'Buscar siguiente (F3)', function () { findGo(1); });
    add('indent', 'indent', 'Corregir indentado (Ctrl+I)', function () { if (!ed.reindent()) status('El código ya está correctamente indentado.', 2500); ed.focus(); }, 'hide-s'); sep();
    add('run', 'run', 'Ejecutar (F9)', function () { startRun('run'); }); add('step', 'step', 'Ejecutar paso a paso (F5)', function () { togglePanel('right', 'step'); });
    add('check', 'check', 'Verificar sintaxis (Shift+F9)', function () { doCheck(false); }); add('flow', 'flow', 'Diagrama de flujo (F7)', openFlow);
    add('stop', 'stop', 'Detener la ejecución', stopRun); TB.stop.style.display = 'none'; sep();
    add('help', 'help', 'Ayuda (F1)', function () { helpIndex(); });
    var sp = el('span', ''); sp.style.flex = '1'; bar.appendChild(sp);
    add('theme', 'moon', 'Cambiar tema claro/oscuro', function () { S.theme = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark'; saveSettings(); applyTheme(); }); TB.theme.id = 'tbTheme';
    add('vars', 'vars', 'Lista de variables', function () { togglePanel('left', 'vars'); }); add('ops', 'ops', 'Operadores y funciones', function () { togglePanel('left', 'ops'); }); add('cmd', 'cmd', 'Comandos y estructuras', function () { togglePanel('right', 'cmd'); });
  }
  function updateUI() {
    if (!ed || !TB.undo) return;
    TB.undo.disabled = !ed.canUndo(); TB.redo.disabled = !ed.canRedo();
    TB.stop.style.display = running ? '' : 'none'; TB.run.disabled = !!(running && running.mode === 'run');
  }

  /* ===================================================================== teclas rápidas (móvil) */
  function buildQKeys() {
    var q = $('qkeys'); q.className = 'can'; q.innerHTML = '';
    [['Tab', 'tab'], ['←', '<- '], ['"', '"'], ['(', '('], [')', ')'], ['[', '['], [']', ']'], [',', ', '], [';', ';'], ['=', ' = '], ['<>', ' <> '], ['<=', ' <= '], ['>=', ' >= '], ['+', ' + '], ['-', ' - '], ['*', ' * '], ['/', ' / '], ['^', '^']].forEach(function (k) {
      var b = el('button', '', H(k[0])); b.type = 'button';
      b.addEventListener('mousedown', function (e) { e.preventDefault(); });
      b.onclick = function () { if (k[1] === 'tab') { var u = unitStr(); ed.insert(u); } else ed.insert(k[1]); ed.focus(); };
      q.appendChild(b);
    });
  }

  /* ===================================================================== instalar (PWA) */
  function installApp() { if (!deferredInstall) { status('Use el menú del navegador: "Instalar aplicación" o "Añadir a pantalla de inicio".', 6000); return; } deferredInstall.prompt(); deferredInstall = null; }

  /* ===================================================================== atajos globales */
  function onKey(e) {
    var k = e.key, ctrl = e.ctrlKey || e.metaKey, shift = e.shiftKey, lk = (k || '').toLowerCase();
    if (k === 'Escape') { if (openDialogs.length) { openDialogs[openDialogs.length - 1].close(); return; } if (openMenu >= 0) { closeMenus(); return; } if (!$('findbar').hidden) { $('findbar').hidden = true; ed.focus(); return; } }
    var inDlg = openDialogs.length > 0, inCon = e.target && e.target.id === 'conInput';
    if (inDlg) return;
    if (running && running.keyRes && !inCon) { running.keyRes(); return; }
    var handled = true;
    if (k === 'F9' && !ctrl) { if (shift) doCheck(false); else startRun('run'); }
    else if (k === 'F9' && ctrl) predefDialog();
    else if (k === 'F5') { showPanel('right', 'step'); }
    else if (k === 'F7') openFlow();
    else if (k === 'F1') { if (shift) quickHelp(); else helpIndex(); }
    else if (k === 'F3') findGo(shift ? -1 : 1);
    else if (ctrl && !e.altKey) {
      if (lk === 's') { if (shift) saveAs(); else save(); }
      else if (lk === 'o') openDlg();
      else if (lk === 'n') newFile();
      else if (lk === 'p') doPrint();
      else if (lk === 'w') closeTab();
      else if (lk === 'f') showFind(false);
      else if (lk === 'r') showFind(true);
      else if (lk === '+' || lk === '=') { if (document.activeElement === ta) setFont(S.fontSize + 1); else handled = false; }
      else if (lk === '-') { if (document.activeElement === ta) setFont(S.fontSize - 1); else handled = false; }
      else if (lk === '0') { if (document.activeElement === ta) setFont(DEF.fontSize); else handled = false; }
      else handled = false;
    } else handled = false;
    if (handled) { e.preventDefault(); e.stopPropagation(); }
  }

  /* ===================================================================== inicialización */
  function setupConsole() {
    $('conMax').innerHTML = ic('full'); $('conClose').innerHTML = ic('close');
    $('conMax').onclick = function () { $('conWin').classList.toggle('maxwin'); };
    function closeCon() { stopRun(); $('conWin').hidden = true; ed.setRunLine(0); }
    $('conClose').onclick = closeCon;
    $('conStop').onclick = stopRun;
    $('conPause').onclick = function () { $('sbPause').click(); }; $('conNext').onclick = function () { $('sbNext').click(); };
    $('conRestart').onclick = function () { var m = running ? running.mode : (lastMode || 'run'); startRun(m); };
    $('conKeep').onchange = function () { S.keep = this.checked; saveSettings(); };
    function submit() { var inp = $('conInput'); if (running && running.reader) running.reader(inp.value); }
    $('conInput').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); submit(); } });
    $('conSend').onclick = submit;
    $('conOut').addEventListener('click', function () { if (running && running.keyRes) running.keyRes(); else if (running && running.reader) $('conInput').focus(); });
    drag($('conWin'), $('conHead'));
  }
  var lastMode = 'run';
  var origStart = startRun; startRun = function (m) { lastMode = m; origStart(m); };

  function setupFlow() {
    $('flowMax').innerHTML = ic('full'); $('flowClose').innerHTML = ic('close');
    $('flowMax').onclick = function () { $('flowWin').classList.toggle('maxwin'); setTimeout(flowFit, 50); };
    $('flowClose').onclick = closeFlow;
    buildFlowBar(); drag($('flowWin'), $('flowHead'));
  }
  function setupFind() {
    $('fq').oninput = function () { findCount(); };
    $('fq').onkeydown = function (e) { if (e.key === 'Enter') { e.preventDefault(); findGo(e.shiftKey ? -1 : 1); } };
    $('fr').onkeydown = function (e) { if (e.key === 'Enter') { e.preventDefault(); $('fRep').click(); } };
    $('fPrev').onclick = function () { findGo(-1); }; $('fNext').onclick = function () { findGo(1); };
    $('fRep').onclick = function () { var q = $('fq').value; if (q) { ed.replaceCurrent(q, $('fr').value, fOpts()); findCount(); } };
    $('fAll').onclick = function () { var q = $('fq').value; if (q) { var n = ed.replaceAll(q, $('fr').value, fOpts()); status(n + ' reemplazo' + (n === 1 ? '' : 's') + ' realizado' + (n === 1 ? '' : 's') + '.', 3500); findCount(); } };
    $('fCase').onchange = $('fWord').onchange = findCount;
    $('fClose').onclick = function () { $('findbar').hidden = true; ed.focus(); };
  }
  function setupPanelTabs() {
    var i, pt = document.querySelectorAll('#left .ptab, #right .ptab');
    for (i = 0; i < pt.length; i++) (function (b) { b.onclick = function () { var side = $('left').contains(b) ? 'left' : 'right'; showPanel(side, b.getAttribute('data-p')); }; })(pt[i]);
    var rt = document.querySelectorAll('#results .ptab');
    for (i = 0; i < rt.length; i++) (function (b) { b.onclick = function () { selectRTab(b.getAttribute('data-r')); }; })(rt[i]);
    $('rClose').innerHTML = ic('close'); $('rClose').onclick = function () { showResults(false); };
    var cl = document.querySelectorAll('.pclose[data-close]');
    for (i = 0; i < cl.length; i++) { cl[i].innerHTML = ic('close'); cl[i].onclick = closePanels; }
    $('bd').onclick = closePanels;
    ['toolbar', 'left', 'right', 'tabs'].forEach(function (id) { $(id).addEventListener('mousedown', function (e) { var t = e.target.tagName; if (t !== 'INPUT' && t !== 'SELECT' && t !== 'TEXTAREA') e.preventDefault(); }); });
  }
  function fitViewport() {
    var vv = window.visualViewport, h = vv ? vv.height : window.innerHeight;
    document.documentElement.style.setProperty('--appH', Math.round(h) + 'px');
    document.body.style.top = vv ? Math.round(vv.offsetTop) + 'px' : '0px';
    if (window.scrollY) window.scrollTo(0, 0);
  }

  function init() {
    ta = $('ta');
    ed = ED.create({
      ta: ta, hl: $('hl'), layer: $('layer'), gutterIn: $('gin'), gutter: $('gutter'), gutterMarks: $('gmarks'), wrap: $('code'), marks: $('marks'), cursorMark: $('curmark'), settings: S,
      callbacks: { change: onEditorChange, cursor: function (l, c) { $('stPos').textContent = 'Lín ' + l + ', Col ' + c; } }
    });
    buildMenubar(); buildToolbar(); buildOps(); buildCmds(); buildStepPanel(); buildQKeys(); setupPanelTabs(); setupFind(); setupConsole(); setupFlow();
    updateVars([], null);
    // sesión previa
    var sess = lsGet('pseint.session', null);
    if (sess && sess.tabs && sess.tabs.length) {
      sess.tabs.forEach(function (t) { var tab = { id: ++tabSeq, name: t.name || null, text: t.text || '', savedText: t.savedText === undefined ? (t.text || '') : t.savedText, undo: [], redo: [], sel: t.sel || [0, 0], fh: null }; tab.dirty = tab.text !== tab.savedText; tabs.push(tab); });
      cur = Math.min(sess.cur || 0, tabs.length - 1); ed.applySettings(); ed.load(tabs[cur]); renderTabs();
    } else { ed.applySettings(); newTab(blankText()); }
    applyAll(); status(defaultStatus()); setPanelTab('left', 'ops'); setPanelTab('right', 'cmd');
    if (isNarrow()) closePanels(); else applyPanels();
    $('fileIn').onchange = function () { openFiles(this.files); };
    document.addEventListener('keydown', onKey, true);
    // arrastrar y soltar
    var dc = 0, dh = $('dropHint');
    window.addEventListener('dragenter', function (e) { if (e.dataTransfer && Array.prototype.indexOf.call(e.dataTransfer.types || [], 'Files') >= 0) { dc++; dh.style.display = 'flex'; } });
    window.addEventListener('dragleave', function () { dc = Math.max(0, dc - 1); if (!dc) dh.style.display = 'none'; });
    window.addEventListener('dragover', function (e) { e.preventDefault(); });
    window.addEventListener('drop', function (e) { e.preventDefault(); dc = 0; dh.style.display = 'none'; if (e.dataTransfer && e.dataTransfer.files.length) openFiles(e.dataTransfer.files); });
    window.addEventListener('resize', function () { fitViewport(); applyPanels(); if (isNarrow()) { $('left').style.display = ''; $('right').style.display = ''; } ed.refresh(); });
    if (window.visualViewport) { window.visualViewport.addEventListener('resize', fitViewport); window.visualViewport.addEventListener('scroll', fitViewport); }
    document.addEventListener('visibilitychange', function () { if (document.hidden) persist(); });
    window.addEventListener('pagehide', persist);
    if (window.matchMedia) { try { matchMedia('(prefers-color-scheme: dark)').addListener(function () { if (S.theme === 'auto') applyTheme(); }); } catch (e) { /* noop */ } }
    window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); deferredInstall = e; });
    window.addEventListener('error', function (e) { status('Error inesperado: ' + (e.message || e), 8000); });
    fitViewport(); liveCheckSoon();
  }

  /* ===================================================================== arranque + pantalla de inicio */
  function boot() {
    var t0 = Date.now(), bar = $('splashBar'), p = 0, MIN = 2400;
    var iv = setInterval(function () { p = Math.min(100, ((Date.now() - t0) / MIN) * 100); bar.style.width = p + '%'; }, 80);
    function done() {
      clearInterval(iv); bar.style.width = '100%'; $('splash').classList.add('out');
      setTimeout(function () { var s = $('splash'); if (s && s.parentNode) s.parentNode.removeChild(s); if (ed) { ed.refresh(); ed.applySettings(); if (!isNarrow()) ed.focus(); } }, 520);
    }
    if (!window.__ok) { $('splash').style.display = 'none'; $('nosupport').style.display = 'block'; return; }
    $('app').hidden = false; // se construye debajo de la pantalla de inicio
    try { init(); } catch (e) { $('app').hidden = false; status('Error al iniciar: ' + e.message); if (window.console) console.error(e); }
    var wait = Math.max(300, MIN - (Date.now() - t0));
    setTimeout(done, wait);
    if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) { window.addEventListener('load', function () { navigator.serviceWorker.register('sw.js').catch(function () { /* sin modo sin conexión */ }); }); }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.PSeIntWeb = { version: APP.version, run: function (m) { startRun(m || 'run'); }, getText: function () { return ta.value; }, setText: function (t) { ed.setText(t); } };
})();
